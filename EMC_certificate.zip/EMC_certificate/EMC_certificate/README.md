# Machine-checkable certificates for the 19-board layer

This package contains the two computer-assisted components used in the leading
19-board layer of the manuscript *The Erdős Matching Conjecture for 4-uniform
hypergraphs*:

1. an exact integer-scaled Farkas verification for the **top-star** branch;
2. deterministic finite up-set searches for the **no-top-star** branch.

The package does **not** numerically test the theorem for particular values of
`n` or `s`.  After Lemma 3.2 has supplied the fixed coefficients
`300`, `144`, and `625`, the computer-assisted part is a finite calculation on
`[4]^4`.  The 15-board and 11-board inequalities are proved directly in the
manuscript and therefore have no ancillary programs here.

No certificate datum has been changed in this annotated version.  Only
comments, docstrings, and this explanatory README have been expanded.  The two
proof-data files have the following SHA-256 digests:

```text
0d0b558b924a9474e288663f03cd3940dc1a10596c1bc99e87f71c38c0e06dea  certificates/topstar_farkas.json
de06bd4f9daaab367ed94ebdeda310dd58846d2e8e36dff66d7e714f96f88774  certificates/no_topstar_threshold.json
```

## 1. Mathematical dictionary

The notation below is exactly the notation of Sections 4 and Appendix A of the
manuscript.

| Code notation | Mathematical meaning |
|---|---|
| `COLUMNS = (1,2,3,4)` | the four selected matching edges/columns `E_1,...,E_4` |
| `LEVELS = (1,2,3,4)` | the four vertices `e_{i,1},...,e_{i,4}` in one selected column |
| `SEED_LEVELS = (1,2)` | the two levels whose seeds `R_F ∪ {e_{i,u}}` are guaranteed by Lemma 3.3 |
| `V4 = [4]^4` | all 256 wide quads, represented by their four column-level coordinates |
| `Q4` | the missing wide-quad up-set `\mathcal Q_4` |
| `U = {2,3,4}^4` | the upper cube |
| `C = U \ Q4` | the present upper wide quads |
| `Ctop` | present quads in the fourth-coordinate top slice `(x,4)` |
| `N` | missing quads in the lower slices `(x,t)`, `t=1,2,3` |
| `y_x` | indicator that `(x,4)` is present, i.e. `x ∈ Ctop` |
| `m_{x,t}` | indicator that `(x,t)` is missing, i.e. `(x,t) ∈ N` |
| `t_{I,v}` | indicator that the supported wide triple `H_I(v)` is present |
| `p_{J,u}` | indicator that the supported wide pair `H_J(u)` is present |
| `c` | `|Ctop| = Σ_x y_x` |
| `ell` | `|N| = Σ_{x,t} m_{x,t}` |
| `R_ab` | the 64-point rectangle `{q ∈ [4]^4 : q_a,q_b ≥ 3}` |

In `src/topstar.py`, the variable vector is ordered as

```text
X = ( y[64], m[192], t[4·64], p[6·16] ),
```

so it has `64 + 192 + 256 + 96 = 608` coordinates.  Its objective vector is

```text
d = (625 on y, -625 on m, 300 on t, 144 on p),
```

which is the integer form of

```text
625 c - 625 ell + 300 |T3| + 144 |P2| <= 40000.
```

## 2. File-to-proof map

| File | Role in the manuscript |
|---|---|
| `run_all.py` | compiles/runs every proof-critical check and prints the two success markers |
| `src/topstar.py` | reconstructs the top-star system from (R1)–(R10) and verifies (F1)–(F2) in exact integer arithmetic |
| `certificates/topstar_farkas.json` | the 63 branches of Farkas multiplier data `D_beta, lambda_beta, mu_beta`; it does not store `A_beta`, `b_beta`, or `d` |
| `src/no_topstar_upper_blocker.cpp` | verifies Conclusion A.1: `|Q4 ∩ U| >= 33` |
| `src/no_topstar_search.cpp` | exact target-bounded up-set solver used for the 30 trace thresholds and 9 critical patterns |
| `certificates/no_topstar_threshold.json` | the 10 pair-orbit records, 20 triple-orbit records, and 9 critical-pattern commands/expectations |
| `src/no_topstar.py` | validates the JSON coverage, invokes the C++ searches, reconstructs Table 1, classifies equality shapes, and audits the 72 rectangle extensions |

## 3. Running the complete audit

Requirements:

- Python 3.10 or later;
- a C++17 compiler, by default `g++` (set environment variable `CXX` to use a
  different compiler);
- no third-party Python packages.

From the package directory, run

```bash
python3 run_all.py
```

Use

```bash
python3 run_all.py --verbose
```

to display every threshold/pattern command and its principal solver result.
The proof-critical final line is

```text
topstar_no_topstar_certificate_ok=True
```

A complete submitted run also reports

```text
topstar_certificate_ok=True branches=63 variables=608 rows=68058 min_gap=0 min_rhs_gap=386598099
no_topstar_certificate_ok=True min_Q4U=33 trace_threshold_checks=30 critical_pattern_checks=9 extremal_pair_shapes=3 extremal_triple_shapes=4 critical_pair_shapes=1 rectangle_cases=72 rectangle_max_case=(64, 96, 4, -10624)
```

The exact elapsed time is machine-dependent and is not a mathematical input.

## 4. Top-star verifier: detailed pseudocode

The fourth selected column is fixed as the top-star direction, exactly as in
Lemma 4.6.  Column permutations in the proof justify this normalization.

```text
BUILD-TOPSTAR-SYSTEM:
    create the 608 variables y, m, t, p in a fixed deterministic order

    add (R1): Ctop is a down-set and is contained in
              Z = {x ∈ [4]^3 : some coordinate of x equals 1}
    add (R2): lower missing quads form an up-set and are compatible with Ctop
    add (R3): ell - c <= 2
    add (R4): each supported pair/triple level family is a down-set
    add (R5): every wide-quad completion of a present pair/triple is present
    add (R6): forbidden pair configurations from Claim 4.3
    add (R7): forbidden bad triple matchings from Lemma 4.4
    add valid (R8) seed-hitting rows
    add (R9): |P_J| <= 4 and |T_I| <= 32

FOR EACH OF THE 63 BRANCHES beta:
    add the branch equations and principal ideal/filter consequences in (R10)
    read only D_beta, lambda_beta, mu_beta from topstar_farkas.json
    reconstruct the weighted row sum using Python integers
    check every multiplier is nonnegative
    check every stored row index, row type, and optional right-hand side
    compute g_beta = A_beta^T lambda_beta + mu_beta - D_beta d
    compute h_beta = 40000 D_beta - b_beta^T lambda_beta - 1^T mu_beta
    accept the branch iff every coordinate of g_beta and h_beta is nonnegative

ACCEPT iff all 63 branches are accepted.
```

### Important implementation note about (R8)

For a fixed trace, seed, and choice of three available levels in each column,
the source orders the three residual quads by the first coordinate and uses the
`3^3` cyclic alignments in the remaining coordinates.  Thus the submitted
certificate uses a **fixed subfamily** of the valid (R8) inequalities, rather
than all `6^3` alignments.

This is proof-safe: every generated row is a genuine instance of (R8), and
omitting other valid rows only enlarges the feasible linear relaxation.  The
Farkas certificate proves the desired objective bound even for that weaker
relaxation, so it certainly proves it for every genuine board.  This detail is
also essential for reproducing the stored row indices; changing the residual
row generator would require a new certificate file.

The fields such as `exact_rhs_num`, `exact_margin_num`, `min_gap_num`, and
`row_type_counts` in the JSON are audit metadata.  The proof does not trust
those summaries: it reconstructs the row sum from the multiplier lists.  The
stored summaries can then be compared with the recomputed values.

## 5. No-top-star verifier: detailed pseudocode

### 5.1 Conclusion A.1: upper-cube blocker

A present upper down-set `C ⊆ {2,3,4}^4` is encoded by a monotone `3×3×3`
height array.  For fixed `(a,b,c)`, the height is the number of permitted fourth
coordinates beginning at level 2.

```text
UPPER-BLOCKER:
    construct all 216 upper 3-matching templates
        (order the quads by first coordinate 2,3,4;
         use one permutation of 2,3,4 in each of the other three coordinates)

    verify an explicit admissible height array of size 48
        containing all four forced unit-top points
        and containing no upper 3-matching

    recursively enumerate every monotone height array that could have size >=49
        enforce the four unit-top inclusions forced by the no-top-star condition
        prune only when the maximum possible size of every completion is <=48
        at each completed array of size >=49, test all 216 matching masks
        fail immediately if one contains no upper 3-matching

    conclude max |C| = 48 and hence min |Q4 ∩ U| = 81 - 48 = 33.
```

The certified count is `3,116,823` completed candidates of size at least 49.
All operations are integer comparisons and bit-mask containment tests.

### 5.2 Conclusion A.2: individual trace thresholds and Table 1

For one pair or triple trace `H`, `src/no_topstar_search.cpp` forms a hitting-set
problem on the 256 points of `[4]^4`:

```text
TRACE-THRESHOLD(H, target B):
    begin with the 216 clauses saying that Q4 hits every upper 3-matching (N2)
    forbid the four minimal full-top-star points (N3)
    forbid every wide-quad extension of H from Q4 (completion closure in N5)
    for every seed disjoint from H:
        generate every residual three-quad matching disjoint from H and the seed
        add a clause requiring Q4 to hit that matching (remaining seed hitting)

    search over up-sets Q4 only:
        choose an unhit clause
        branch on a point q of that clause by adding the full up-closure of q
        use exact unit propagation
        use a valid cardinality lower bound from pairwise disjoint unhit clauses
        prune a branch only if it cannot produce a solution of size < B

    return the smallest solution found below B;
    if none exists below B, the final displayed value remains B.
```

This last convention is important when reading the log:

- for an `exact` record, the JSON sets `target = threshold + 1`; finding
  `best = threshold` supplies a witness and exhaustion proves optimality;
- for a lower-bound record, the JSON sets `target = threshold`; an output
  `best = threshold` may mean “no solution exists below the target,” not that a
  witness of exactly that size was found;
- `initial_infeasible best=None` means the forced-present completions already
  make the finite system infeasible, which is stronger than the requested
  target-bounded lower bound.

The JSON contains exactly the 10 pair-level multisets and 20 triple-level
multisets.  Coordinate symmetry turns each sorted multiset record into the
threshold for all ordered levels in its orbit.  The Python verifier then:

```text
    enumerate all legal pair down-sets satisfying (N4): exactly 10
    enumerate all legal triple down-sets satisfying (N4): exactly 26,893
    for each m=33,...,63:
        retain only levels whose individual threshold is <=m
        maximize a legal down-set on one support
        obtain p(m), t(m)
        check 300·4·t(m) + 144·6·p(m) <= 625m.
```

This is deliberately a one-sided relaxation: individual feasibility is only a
necessary condition.  Allowing all individually feasible traces together can
only increase the computed maxima, so the resulting values remain rigorous
upper bounds for genuine boards.

### 5.3 Conclusion A.3: equality patterns and rectangle audit

```text
CRITICAL-RANGE-AUDIT (64 <= |Q4| <= 66):
    enumerate all legal size-4 pair down-sets
        verify the three equality shapes
        use the individual thresholds to eliminate the two long row/column shapes
        retain only {1,2}×{1,2}

    enumerate all legal size-32 triple down-sets
        verify exactly three slabs and the mixed diagram

    run 9 pattern searches:
        pair square: minimum 64 and, below 67, force R_12
        each triple slab: minimum 64 and, below 67, force the corresponding R_i4
        mixed triple pattern: exact minimum 80

    for each of the six 64-point rectangles R_ab:
        enumerate every up-set extension of total size at most 66
        remove duplicates
        retain only cases satisfying no full top-star and all upper matching clauses
    obtain exactly 72 cases

    for each retained Q4:
        test (N5) for every pair/triple level
        maximize independently over the 10 legal pair down-sets
        maximize independently over the 26,893 legal triple down-sets
        check 300|T3| + 144|P2| - 625|Q4| <= 0.
```

The worst relaxed case is

```text
(|Q4|, |T3|, |P2|, objective) = (64, 96, 4, -10624).
```

Because supports are maximized independently, this final step can only enlarge
the set of globally compatible trace configurations and is therefore again a
safe upper-bound relaxation.

## 6. Data that must not be edited independently

- `topstar_farkas.json` is tied to the exact variable order and row order in
  `src/topstar.py`.  Reordering row generation, even without changing the
  mathematical system, invalidates its stored row indices.
- `no_topstar_threshold.json` stores search specifications and claimed
  thresholds.  Any change to a target, mode, trace orbit, pattern, or rectangle
  must be accompanied by a fresh complete run and a new mathematical audit.
- Renaming levels from `{1,2,3,4}` or changing the meaning of `Q4` would require
  simultaneous changes to the manuscript, all generators, and both data files.

