#!/usr/bin/env python3
"""Run the two proof-critical certificate checks used by the paper.

Mathematical scope
------------------
The script verifies only the computer-assisted part of the leading 19-board
inequality.  It does not sample hypergraphs and it does not use particular
values of ``n`` or ``s``.  The manuscript has already reduced the problem to
the fixed coefficients 300, 144, and 625 before this package is invoked.

Execution order
---------------
1. ``verify_topstar`` reconstructs the finite linear system from (R1)--(R10)
   and checks all 63 exact integer-scaled Farkas certificates.
2. ``verify_no_topstar`` compiles the two C++ finite-search helpers, checks
   Conclusions A.1--A.3, reconstructs Table 1, and audits all 72 rectangle
   extensions.
3. The final success marker is printed only after both calls return normally.

The certificate files are read-only mathematical inputs.  The temporary C++
executables are placed in ``.build`` and are not part of the certificate data.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from topstar import verify_topstar  # noqa: E402
from no_topstar import verify_no_topstar  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Verify the top-star and no-top-star certificates."
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="show individual branch/search commands",
    )
    args = parser.parse_args()

    # Appendix A.1: verify (F1) and (F2) for every branch beta.  Failure of any
    # branch raises an exception, so the line below is printed only after the
    # full top-star certificate has passed.
    top = verify_topstar(
        ROOT / "certificates" / "topstar_farkas.json",
        verbose=args.verbose,
    )
    print(
        "topstar_certificate_ok=True "
        f"branches={top['branches']} variables={top['variables']} "
        f"rows={top['rows_reconstructed']} min_gap={top['min_gap']} "
        f"min_rhs_gap={top['min_rhs_gap']}"
    )

    # Appendix A.2: compile and run the exact upper-cube blocker and the
    # target-bounded up-set solver, then perform the Python arithmetic and
    # rectangle-extension audits.  Again, any failed assertion aborts here.
    no = verify_no_topstar(
        ROOT / "certificates" / "no_topstar_threshold.json",
        ROOT / ".build",
        echo=args.verbose,
    )
    print(
        "no_topstar_certificate_ok=True "
        f"min_Q4U={no['upper_cube_min_missing']} "
        f"trace_threshold_checks={no['trace_threshold_checks']} "
        f"critical_pattern_checks={no['critical_pattern_checks']} "
        f"extremal_pair_shapes={no['extremal_pair_shapes']} "
        f"extremal_triple_shapes={no['extremal_triple_shapes']} "
        f"critical_pair_shapes={no['critical_pair_shapes']} "
        f"rectangle_cases={no['rectangle_cases']} "
        f"rectangle_max_case={no['rectangle_max_case'][:4]}"
    )

    # This is the single top-level marker quoted in the README.  It is reached
    # only if every proof-critical subcheck above has succeeded.
    print("topstar_no_topstar_certificate_ok=True")


if __name__ == "__main__":
    main()
