#!/usr/bin/env python3
"""Exact verifier for the no-top-star certificate in Appendix A.2.

Mathematical universe
---------------------
``Q4`` is the missing wide-quad up-set in ``V4=[4]^4``.  Columns and levels use
the manuscript labels ``1,2,3,4`` throughout.  The upper cube is
``U={2,3,4}^4`` and its complement inside the present wide quads is
``C=U\\Q4``.  The guaranteed seed levels are 1 and 2 (Lemma 3.3), and the
high-level rectangles are

    R_ab = {q in [4]^4 : q_a >= 3 and q_b >= 3}.

Proof pipeline
--------------
This module orchestrates and independently audits the three conclusions used
in Lemma 4.8:

``A.1``
    compile/run ``no_topstar_upper_blocker.cpp`` and verify exactly that every
    admissible present upper down-set has size at most 48, equivalently
    ``|Q4 intersect U| >= 33``;
``A.2``
    run 10 pair-orbit and 20 triple-orbit target-bounded searches, enumerate
    every legal supported down-set from (N4), reconstruct Table 1 for
    ``33 <= |Q4| <= 63``, and check the integer inequality;
``A.3``
    run the 9 equality-pattern searches, verify the complete equality-shape
    classifications, enumerate all 72 up-set extensions of a forced rectangle
    of size at most 66, and maximize the relaxed trace contribution.

The C++ search is an exact finite hitting-set search over 256 points; it uses
only up-closures, unit propagation, and logically valid cardinality lower
bounds.  No LP/MILP solver, randomness, floating-point feasibility tolerance,
or heuristic acceptance criterion occurs.  Floating point is used only for a
wall-clock timeout supplied by the runner.

The JSON file is a search specification/certificate index.  This module checks
that all required trace orbits and critical patterns occur exactly once before
running them.  Final arithmetic is performed with Python integers.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
from functools import lru_cache
from itertools import combinations, combinations_with_replacement, permutations, product
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Set, Tuple

# Exact manuscript labels.  In particular, no legacy {0,1,2,3} data are used.
COLUMNS = (1, 2, 3, 4)
LEVELS = (1, 2, 3, 4)
SEED_LEVELS = (1, 2)
UPPER_LEVELS = (2, 3, 4)
HIGH_LEVELS = (3, 4)
TOP_LEVEL = 4

# Level universes on one pair support, one triple support, and the four-column
# wide-quad universe.  The lexicographic index maps are used only for compact
# bit masks; tuple entries remain 1-based mathematical levels.
V2 = list(product(LEVELS, repeat=2))
V3 = list(product(LEVELS, repeat=3))
V4 = list(product(LEVELS, repeat=4))
IDX2 = {p: i for i, p in enumerate(V2)}
IDX3 = {p: i for i, p in enumerate(V3)}
IDX4 = {p: i for i, p in enumerate(V4)}
TSUPPS = list(combinations(COLUMNS, 3))
PSUPPS = list(combinations(COLUMNS, 2))


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise RuntimeError(msg)


def leq(a: Sequence[int], b: Sequence[int]) -> bool:
    """Coordinatewise order: present trace families are down-sets, Q4 an up-set."""
    return all(x <= y for x, y in zip(a, b))


def is_downset2(points: Iterable[Tuple[int, int]]) -> bool:
    """Test whether a pair-level family is a down-set in ``[4]^2``."""

    points = set(points)
    for x, y in points:
        for a in range(1, x + 1):
            for b in range(1, y + 1):
                if (a, b) not in points:
                    return False
    return True


def pair_bad(a: Tuple[int, int], b: Tuple[int, int]) -> bool:
    """The forbidden two-pair configuration of Claim 4.3/(N4)."""

    return (
        a[0] != b[0]
        and a[1] != b[1]
        and any(not set(SEED_LEVELS).issubset({a[i], b[i]}) for i in range(2))
    )


def legal_pair_downsets() -> List[Set[Tuple[int, int]]]:
    """Enumerate all pair down-sets satisfying the pair obstruction in (N4).

    The universe has only 16 points, so all subsets can be tested directly.
    The certified count is 10; the caller checks this count rather than assuming
    it from the implementation.
    """

    out: List[Set[Tuple[int, int]]] = []
    for mask in range(1 << len(V2)):
        points = {V2[i] for i in range(len(V2)) if (mask >> i) & 1}
        if is_downset2(points) and not any(pair_bad(a, b) for a, b in combinations(points, 2)):
            out.append(points)
    return out


def is_bad_triple_matching(points: Sequence[Tuple[int, int, int]]) -> bool:
    """Test the bad 3-matching obstruction from Lemma 4.4/(N4)."""

    if any(len({p[j] for p in points}) < 3 for j in range(3)):
        return False
    for j in range(3):
        unused = set(LEVELS) - {p[j] for p in points}
        if len(unused) == 1 and next(iter(unused)) in SEED_LEVELS:
            return True
    return False


def generate_heights():
    """Generate every monotone 4x4 height matrix with entries in {0,...,4}.

    Such a matrix uniquely represents a down-set in ``[4]^3``: at horizontal
    position ``(x,y)``, height ``h`` includes exactly ``z=1,...,h``.  The
    recursion fills positions in row-major order; limiting a new height by its
    upper and left predecessors enforces monotonicity and gives each matrix
    exactly once.
    """
    heights = [[0] * 4 for _ in range(4)]

    def rec(pos: int):
        if pos == 16:
            yield tuple(tuple(row) for row in heights)
            return
        i, j = divmod(pos, 4)
        max_value = 4
        if i > 0:
            max_value = min(max_value, heights[i - 1][j])
        if j > 0:
            max_value = min(max_value, heights[i][j - 1])
        for value in range(max_value, -1, -1):
            heights[i][j] = value
            yield from rec(pos + 1)

    yield from rec(0)


def mask_from_height(heights) -> int:
    """Encode {(x,y,z): 1 <= z <= h[x-1][y-1]} as a 64-bit mask."""
    mask = 0
    for ix in range(4):
        for iy in range(4):
            x, y = ix + 1, iy + 1
            for z in range(1, heights[ix][iy] + 1):
                mask |= 1 << IDX3[(x, y, z)]
    return mask


def mask_from_points3(points: Iterable[Tuple[int, int, int]]) -> int:
    mask = 0
    for point in points:
        mask |= 1 << IDX3[point]
    return mask


def closure_mask(points: Sequence[Tuple[int, int, int]]) -> int:
    """Return the smallest triple-level down-set containing ``points``."""

    mask = 0
    for x, y, z in points:
        for a in range(1, x + 1):
            for b in range(1, y + 1):
                for c in range(1, z + 1):
                    mask |= 1 << IDX3[(a, b, c)]
    return mask


def legal_triple_downsets() -> List[Tuple[int, int, tuple]]:
    """Enumerate all triple down-sets avoiding every bad 3-matching.

    A down-set contains a bad matching exactly when it contains the down-closure
    of that matching.  Only inclusion-minimal forbidden closure masks are kept;
    removing a nonminimal mask changes neither the accepted families nor the
    proof.  The certified number of accepted down-sets is 26,893.
    """

    bad_matchings = [c for c in combinations(V3, 3) if is_bad_triple_matching(c)]
    forbidden = sorted(set(closure_mask(c) for c in bad_matchings))
    minimal: List[int] = []
    for forbidden_mask in forbidden:
        if not any(
            other != forbidden_mask and (forbidden_mask & other) == other
            for other in forbidden
        ):
            minimal.append(forbidden_mask)

    out: List[Tuple[int, int, tuple]] = []
    for heights in generate_heights():
        mask = mask_from_height(heights)
        if not any((mask & forbidden_mask) == forbidden_mask for forbidden_mask in minimal):
            out.append((sum(map(sum, heights)), mask, heights))
    return out


@lru_cache(maxsize=None)
def residual_matchings_key(
    key: Tuple[Tuple[int, ...], ...],
) -> Tuple[Tuple[Tuple[int, int, int, int], ...], ...]:
    """Generate all residual three-quad matchings for one trace/seed pair.

    ``key[j]`` is the set of levels already occupied in column ``j+1`` by the
    supported trace H and the chosen disjoint seed.  Three residual wide quads
    are pairwise disjoint precisely when, in each column, they use three
    distinct available levels.  The first-coordinate levels are kept in
    increasing order to label the three quads, while all permutations are used
    in coordinates 2--4.  Hence every unordered residual matching is covered.
    """

    avail = [[v for v in LEVELS if v not in key[j]] for j in range(4)]
    if any(len(values) < 3 for values in avail):
        return tuple()

    out = []
    for vals0 in combinations(avail[0], 3):
        for vals1 in combinations(avail[1], 3):
            for vals2 in combinations(avail[2], 3):
                for vals3 in combinations(avail[3], 3):
                    for p1 in permutations(vals1):
                        for p2 in permutations(vals2):
                            for p3 in permutations(vals3):
                                out.append(
                                    tuple(
                                        (vals0[t], p1[t], p2[t], p3[t])
                                        for t in range(3)
                                    )
                                )
    return tuple(out)


def trace_allowed(
    Q4: Set[Tuple[int, int, int, int]],
    supp: Tuple[int, ...],
    vals: Tuple[int, ...],
) -> bool:
    """Check the individual (N5) conditions for one proposed present trace.

    This function does not assert that traces on different supports are jointly
    realizable.  It checks only necessary conditions for the fixed trace:

    1. completion closure: no wide-quad extension of H is in the missing set;
    2. remaining seed hitting: for every seed disjoint from H, Q4 hits every
       residual matching of three wide quads.

    Using individual feasibility independently on each support is a relaxation
    and can only increase the final maximum, which is the safe direction for
    proving the required upper bound.
    """

    trace = dict(zip(supp, vals))
    remaining_columns = [j for j in COLUMNS if j not in trace]

    # Completion closure (Lemma 2.9 / first part of N5): every wide-quad
    # extension of a present trace must lie outside the missing up-set Q4.
    for add_vals in product(LEVELS, repeat=len(remaining_columns)):
        q = [None] * 4
        for j, value in trace.items():
            q[j - 1] = value
        for j, value in zip(remaining_columns, add_vals):
            q[j - 1] = value
        if tuple(q) in Q4:
            return False

    # Residual seed hitting (second part of N5): if H and a guaranteed seed are
    # disjoint, three further pairwise disjoint present quads would create the
    # forbidden five-trace configuration, so every such matching meets Q4.
    for j in COLUMNS:
        for seed_level in SEED_LEVELS:
            if trace.get(j) == seed_level:
                continue
            occupied = {column: {value} for column, value in trace.items()}
            occupied.setdefault(j, set()).add(seed_level)
            key = tuple(tuple(sorted(occupied.get(k, set()))) for k in COLUMNS)
            for matching in residual_matchings_key(key):
                if all(q not in Q4 for q in matching):
                    return False
    return True


def rect(a: int, b: int) -> Set[Tuple[int, int, int, int]]:
    """The high-level rectangle R_ab with levels {3,4} in columns a,b."""
    return {q for q in V4 if q[a - 1] >= 3 and q[b - 1] >= 3}


def upclosure(q: Tuple[int, int, int, int]) -> Set[Tuple[int, int, int, int]]:
    """The principal up-set generated by a wide quad q in ``[4]^4``."""
    return {p for p in V4 if leq(q, p)}


def is_upset(Q4: Set[Tuple[int, int, int, int]]) -> bool:
    """Check (N1) directly on the 256-point universe."""
    return all((not leq(q, p)) or p in Q4 for q in Q4 for p in V4)


def no_full_topstar(Q4: Set[Tuple[int, int, int, int]]) -> bool:
    """Check (N3) using the four minimal points of the possible top-stars.

    Since Q4 is checked to be an up-set, a full top-star in direction j is
    contained in Q4 exactly when its minimal point (coordinate j equal to 4,
    all other coordinates equal to 2) belongs to Q4.
    """

    for j in COLUMNS:
        minimal_topstar_point = [2, 2, 2, 2]
        minimal_topstar_point[j - 1] = TOP_LEVEL
        if tuple(minimal_topstar_point) in Q4:
            return False
    return True


def hits_upper_matchings(Q4: Set[Tuple[int, int, int, int]]) -> bool:
    """Check (N2): Q4 hits all 6^3=216 upper 3-matching templates."""

    for perms in product(permutations(UPPER_LEVELS), repeat=3):
        points = [
            (t, perms[0][i], perms[1][i], perms[2][i])
            for i, t in enumerate(UPPER_LEVELS)
        ]
        if all(point not in Q4 for point in points):
            return False
    return True


def enumerate_rectangle_extensions() -> List[Set[Tuple[int, int, int, int]]]:
    """Enumerate every relevant up-set extending one of the six rectangles.

    A rectangle R_ab already has 64 points.  If an up-set Q4 contains R_ab and
    has size at most 66, then its extra part has size at most two and is a union
    of principal up-closures modulo R_ab.  The routine enumerates all one- and
    two-generator unions of size at most two, verifies the up-set condition,
    filters by (N2)--(N3), and removes duplicates across the six rectangles.
    The complete certified list has 72 members.
    """

    cases: Dict[
        Tuple[Tuple[int, int, int, int], ...],
        Set[Tuple[int, int, int, int]],
    ] = {}
    for a, b in combinations(COLUMNS, 2):
        rectangle = rect(a, b)
        closures = []
        for q in V4:
            if q not in rectangle:
                closure = frozenset(upclosure(q) - rectangle)
                if 1 <= len(closure) <= 2:
                    closures.append(closure)
        closures = sorted(set(closures), key=lambda s: (len(s), sorted(s)))

        extras = {frozenset()}
        extras.update(closure for closure in closures if len(closure) <= 2)
        for closure1, closure2 in combinations(closures, 2):
            union = closure1 | closure2
            if len(union) <= 2:
                extras.add(frozenset(union))

        for extra in extras:
            Q4 = rectangle | set(extra)
            if (
                len(Q4) <= 66
                and is_upset(Q4)
                and no_full_topstar(Q4)
                and hits_upper_matchings(Q4)
            ):
                cases[tuple(sorted(Q4))] = Q4
    return [cases[key] for key in sorted(cases)]


def max_counts_for_Q4(Q4, pairs, triples) -> Tuple[int, int, list]:
    """Compute the relaxed maximum trace counts for a fixed rectangle case.

    For each of the four triple supports and six pair supports, first determine
    all individually (N5)-allowed levels, then choose the largest legal (N4)
    down-set contained in them.  Supports are maximized independently; this can
    only overestimate a globally realizable trace family.
    """

    triple_sum = 0
    pair_sum = 0
    details = []
    for supp in TSUPPS:
        allowed_mask = 0
        for vals in V3:
            if trace_allowed(Q4, supp, vals):
                allowed_mask |= 1 << IDX3[vals]
        best = max(
            (size for size, mask, _heights in triples if (mask & ~allowed_mask) == 0),
            default=0,
        )
        triple_sum += best
        details.append(("T", supp, best))

    for supp in PSUPPS:
        allowed = {vals for vals in V2 if trace_allowed(Q4, supp, vals)}
        best = max((len(points) for points in pairs if points <= allowed), default=0)
        pair_sum += best
        details.append(("P", supp, best))
    return triple_sum, pair_sum, details


def compile_cpp(src: Path, out: Path) -> None:
    """Compile one exact finite-search helper as a C++17 executable."""

    out.parent.mkdir(parents=True, exist_ok=True)
    compiler = os.environ.get("CXX", "g++")
    subprocess.run(
        [
            compiler,
            "-O2",
            "-std=c++17",
            "-Wall",
            "-Wextra",
            "-pedantic",
            str(src),
            "-o",
            str(out),
        ],
        check=True,
    )


def run_cmd(cmd: Sequence[str | Path], log_lines: list[str], echo: bool = True) -> str:
    """Run one helper command, retain its full log, and reject nonzero exit.

    The selected echoed lines are only progress information.  Acceptance is
    decided later by parsing the result and comparing it with the JSON
    expectation; merely printing a success-looking string is not sufficient.
    """

    if echo:
        print("run " + " ".join(map(str, cmd[1:])), flush=True)
    proc = subprocess.run([str(x) for x in cmd], text=True, capture_output=True, check=False)
    text = proc.stdout + proc.stderr
    log_lines.append("$ " + " ".join(map(str, cmd)))
    log_lines.append(text.rstrip())
    if proc.returncode != 0:
        raise RuntimeError(f"command failed: {cmd}\n{text}")
    if echo:
        for line in text.splitlines():
            if (
                line.startswith("result best=")
                or line.startswith("initial_infeasible")
                or line.startswith("exact_upper")
                or line.startswith("min_Q4U=")
            ):
                print("  " + line, flush=True)
    return text


def parse_best(text: str) -> int | None:
    """Read the target-bounded solver result.

    ``None`` denotes an initially infeasible finite system.  A numerical value
    equal to the requested target need not be an attained solution: the solver
    initializes ``best`` at the target and searches exhaustively only below it.
    This convention is exactly what lower-bound records require.
    """

    if "initial_infeasible" in text:
        return None
    match = re.search(r"result best=(-?\d+)", text)
    if not match:
        raise RuntimeError("no result best line in solver output:\n" + text)
    return int(match.group(1))


def validate_certificate_structure(cert: dict) -> None:
    """Check complete and nonduplicated JSON coverage before any search.

    The 10 pair records and 20 triple records are orbit representatives under
    permutations of the selected coordinates, hence their keys are sorted
    multisets of levels.  The 9 named pattern records are the full critical
    list used in Conclusion A.3.
    """

    require(
        set(cert) >= {"pair_thresholds_sorted", "triple_thresholds_sorted", "critical_patterns"},
        "missing no-top-star certificate fields",
    )

    expected_pairs = {
        ",".join(map(str, vals))
        for vals in combinations_with_replacement(LEVELS, 2)
    }
    actual_pairs = set(cert["pair_thresholds_sorted"])
    require(
        actual_pairs == expected_pairs,
        f"pair threshold coverage mismatch: missing={sorted(expected_pairs-actual_pairs)} "
        f"extra={sorted(actual_pairs-expected_pairs)}",
    )

    expected_triples = {
        ",".join(map(str, vals))
        for vals in combinations_with_replacement(LEVELS, 3)
    }
    actual_triples = set(cert["triple_thresholds_sorted"])
    require(
        actual_triples == expected_triples,
        f"triple threshold coverage mismatch: missing={sorted(expected_triples-actual_triples)} "
        f"extra={sorted(actual_triples-expected_triples)}",
    )

    allowed_modes = {
        "exact",
        "lower_bound_for_m_le_66",
        "infeasible_or_lower_bound_for_m_le_66",
        "lower_bound_for_m_le_63",
        "infeasible_or_lower_bound_for_m_le_63",
        "conservative_lower_bound_sufficient_for_arithmetic",
    }
    for kind, entries in [
        ("pair", cert["pair_thresholds_sorted"]),
        ("triple", cert["triple_thresholds_sorted"]),
    ]:
        for key, rec in entries.items():
            vals = tuple(map(int, key.split(",")))
            require(tuple(sorted(vals)) == vals, f"{kind} key is not sorted: {key}")
            require(all(value in LEVELS for value in vals), f"{kind} key is outside [4]: {key}")
            require(rec.get("mode") in allowed_modes, f"{kind} {key}: invalid mode {rec.get('mode')}")
            threshold = int(rec["threshold"])
            target = int(rec["target"])
            require(threshold > 0 and target > 0, f"{kind} {key}: threshold and target must be positive")
            if rec["mode"] == "exact":
                require(target == threshold + 1, f"{kind} {key}: exact mode should use target=threshold+1")
            else:
                require(target == threshold, f"{kind} {key}: lower-bound mode should use target=threshold")

    patterns = cert["critical_patterns"]
    require(isinstance(patterns, list), "critical_patterns must be a list")
    names = [rec.get("name") for rec in patterns]
    require(len(names) == len(set(names)), f"duplicate critical pattern names: {names}")
    expected_names = {
        "pair_square_min",
        "pair_square_forces_R12_for_m_le_66",
        "triple_slab1_min",
        "triple_slab1_forces_R14",
        "triple_slab2_min",
        "triple_slab2_forces_R24",
        "triple_slab3_min",
        "triple_slab3_forces_R34",
        "triple_mixed_min80",
    }
    require(
        set(names) == expected_names,
        f"critical pattern coverage mismatch: missing={sorted(expected_names-set(names))} "
        f"extra={sorted(set(names)-expected_names)}",
    )
    allowed_patterns = {
        "pair_square",
        "triple_slab1",
        "triple_slab2",
        "triple_slab3",
        "triple_mixed",
    }
    allowed_expect = {
        "best=64",
        "best=80",
        "no_best_below_target",
        "infeasible_or_no_best_below_target",
    }
    for rec in patterns:
        args = rec.get("args", [])
        require("--pattern" in args and "--target" in args, f"{rec.get('name')}: missing --pattern/--target args")
        pattern = args[args.index("--pattern") + 1]
        target = int(args[args.index("--target") + 1])
        require(pattern in allowed_patterns, f"{rec.get('name')}: invalid pattern {pattern}")
        require(rec.get("expect") in allowed_expect, f"{rec.get('name')}: invalid expectation {rec.get('expect')}")
        if "--forbid-rect" in args:
            pos = args.index("--forbid-rect")
            a, b = int(args[pos + 1]), int(args[pos + 2])
            require(a in COLUMNS and b in COLUMNS and a != b, f"{rec.get('name')}: invalid rectangle coordinates")
        if rec.get("name") == "triple_mixed_min80":
            require(
                pattern == "triple_mixed" and target == 81 and rec.get("expect") == "best=80",
                "mixed pattern must certify best=80 using target 81",
            )


def check_trace_thresholds(cert: dict, search_bin: Path, log_lines: list[str], echo: bool) -> int:
    """Execute and validate all 30 pair/triple orbit searches.

    In exact mode, ``target=threshold+1`` and the solver must exhibit optimum
    ``threshold``.  In every lower-bound mode, ``target=threshold`` and it is
    enough that no solution below the target is returned (initial
    infeasibility is also acceptable).
    """

    checked = 0
    for kind, entries in [
        ("pair", cert["pair_thresholds_sorted"]),
        ("triple", cert["triple_thresholds_sorted"]),
    ]:
        for key, rec in entries.items():
            vals = key.split(",")
            target = int(rec["target"])
            text = run_cmd(
                [search_bin, *vals, "--target", str(target), "--time", "300"],
                log_lines,
                echo=echo,
            )
            best = parse_best(text)
            mode = rec["mode"]
            threshold = int(rec["threshold"])
            if mode == "exact":
                require(best == threshold, f"{kind} {key}: expected exact best {threshold}, got {best}\n{text}")
            else:
                require(best is None or best >= target, f"{kind} {key}: found best below target {target}: {best}\n{text}")
            checked += 1
    return checked


def check_patterns(cert: dict, search_bin: Path, log_lines: list[str], echo: bool) -> int:
    """Execute the nine equality-pattern and rectangle-forcing searches."""

    checked = 0
    for rec in cert["critical_patterns"]:
        text = run_cmd([search_bin, *rec["args"], "--time", "300"], log_lines, echo=echo)
        best = parse_best(text)
        expectation = rec["expect"]
        if expectation.startswith("best="):
            expected = int(expectation.split("=", 1)[1])
            require(best == expected, f"{rec['name']}: expected best={expected}, got {best}\n{text}")
        elif expectation in {"no_best_below_target", "infeasible_or_no_best_below_target"}:
            target = int(rec["args"][rec["args"].index("--target") + 1])
            require(best is None or best >= target, f"{rec['name']}: found best below target {target}: {best}\n{text}")
        else:
            raise RuntimeError("unknown critical pattern expectation " + expectation)
        checked += 1
    return checked


def conservative_threshold_tables(cert: dict):
    """Expand sorted orbit thresholds to all ordered level tuples.

    Conditions (N1)--(N3) and the trace constraints are invariant under column
    permutations, so an ordered tuple has the threshold of its sorted multiset.
    """

    pair_sorted = {
        tuple(map(int, key.split(","))): int(rec["threshold"])
        for key, rec in cert["pair_thresholds_sorted"].items()
    }
    triple_sorted = {
        tuple(map(int, key.split(","))): int(rec["threshold"])
        for key, rec in cert["triple_thresholds_sorted"].items()
    }
    pair = {vals: pair_sorted[tuple(sorted(vals))] for vals in product(LEVELS, repeat=2)}
    triple = {vals: triple_sorted[tuple(sorted(vals))] for vals in product(LEVELS, repeat=3)}
    return pair, triple


def check_extremal_shape_classification(pairs, triples, pair_thresholds) -> dict:
    """Check the complete equality-shape classification in the critical range.

    The code does not assume the equality cases from the manuscript: it derives
    them from the exhaustively generated legal down-sets and compares the result
    with the three pair shapes and four triple shapes used by Conclusion A.3.
    """
    pair_extremals = {frozenset(points) for points in pairs if len(points) == 4}
    expected_pair_extremals = {
        frozenset((1, value) for value in LEVELS),
        frozenset((value, 1) for value in LEVELS),
        frozenset(product(SEED_LEVELS, repeat=2)),
    }
    require(
        pair_extremals == expected_pair_extremals,
        f"unexpected extremal pair down-sets: {sorted(map(sorted, pair_extremals))}",
    )

    slab_masks = {
        mask_from_points3(point for point in V3 if point[coordinate] <= 2)
        for coordinate in range(3)
    }
    mixed_heights = (
        (4, 4, 2, 2),
        (4, 4, 2, 2),
        (2, 2, 0, 0),
        (2, 2, 0, 0),
    )
    mixed_mask = mask_from_height(mixed_heights)
    expected_triple_extremals = slab_masks | {mixed_mask}
    triple_extremals = {mask for size, mask, _heights in triples if size == 32}
    require(
        triple_extremals == expected_triple_extremals,
        f"unexpected extremal triple down-set count/shapes: {len(triple_extremals)}",
    )

    # At |Q4| <= 66, the individual threshold records eliminate the two
    # one-row/one-column pair shapes, leaving only the 2x2 low-level square.
    allowed_pair_levels = {
        point for point, threshold in pair_thresholds.items() if threshold <= 66
    }
    critical_pair_extremals = {
        points for points in pair_extremals if set(points) <= allowed_pair_levels
    }
    expected_square = frozenset(product(SEED_LEVELS, repeat=2))
    require(
        critical_pair_extremals == {expected_square},
        f"critical pair equality classification failed: {critical_pair_extremals}",
    )

    return {
        "extremal_pair_shapes": len(pair_extremals),
        "extremal_triple_shapes": len(triple_extremals),
        "critical_pair_shapes": len(critical_pair_extremals),
    }


def check_arithmetic_and_rectangle(cert: dict) -> dict:
    """Reconstruct Table 1 and complete the non-search arithmetic audit.

    This routine checks:

    * exactly 10 legal pair down-sets and 26,893 legal triple down-sets;
    * every integer inequality for m=33,...,63;
    * the large-|Q4| and non-extremal estimates used before Conclusion A.3;
    * completeness and objective values of all 72 rectangle extensions.
    """

    pair_thresholds, triple_thresholds = conservative_threshold_tables(cert)
    pairs = legal_pair_downsets()
    triples = legal_triple_downsets()
    require(len(pairs) == 10, f"unexpected legal pair down-set count {len(pairs)}")
    require(len(triples) == 26893, f"unexpected legal triple down-set count {len(triples)}")

    shape_checks = check_extremal_shape_classification(pairs, triples, pair_thresholds)

    rows = []
    for m in range(33, 64):
        allowed_pairs = {point for point, threshold in pair_thresholds.items() if threshold <= m}
        pair_max = max((len(points) for points in pairs if points <= allowed_pairs), default=0)

        allowed_triple_mask = 0
        for point, threshold in triple_thresholds.items():
            if threshold <= m:
                allowed_triple_mask |= 1 << IDX3[point]
        triple_max = max(
            (size for size, mask, _heights in triples if (mask & ~allowed_triple_mask) == 0),
            default=0,
        )

        lhs = 300 * 4 * triple_max + 144 * 6 * pair_max
        rhs = 625 * m
        require(lhs <= rhs, f"low-range arithmetic failure: {(m, pair_max, triple_max, lhs, rhs)}")
        rows.append((m, pair_max, triple_max, lhs, rhs))

    require(300 * 128 + 144 * 24 < 625 * 67, "large-Q4 Ferrers arithmetic failed")
    no_extremal_lhs = 300 * (4 * 31) + 144 * (6 * 3)
    require(no_extremal_lhs <= 625 * 64, "non-extremal |Q4|=64 arithmetic failed")

    cases = enumerate_rectangle_extensions()
    max_objective = -10**18
    max_case = None
    for Q4 in cases:
        triple_sum, pair_sum, details = max_counts_for_Q4(Q4, pairs, triples)
        objective = 300 * triple_sum + 144 * pair_sum - 625 * len(Q4)
        if objective > max_objective:
            max_objective = objective
            max_case = (len(Q4), triple_sum, pair_sum, objective, details)
        require(
            objective <= 0,
            f"rectangle extension objective failure: {(len(Q4), triple_sum, pair_sum, objective, details)}",
        )

    require(len(cases) == 72, f"unexpected rectangle extension count: {len(cases)}")
    require(max_objective == -10624, f"unexpected rectangle max objective: {max_objective}")
    return {
        "low_range_rows": rows,
        "no_extremal_lhs_at_Q4_64": no_extremal_lhs,
        "rectangle_cases": len(cases),
        "rectangle_max_case": max_case,
        **shape_checks,
    }


def verify_no_topstar(cert_path: Path, build_dir: Path, echo: bool = True) -> dict:
    """Run the complete Appendix A.2 verification and return its audit data."""

    here = Path(__file__).resolve().parent
    cert = json.loads(cert_path.read_text(encoding="utf-8"))
    validate_certificate_structure(cert)

    search_bin = build_dir / "no_topstar_search"
    upper_bin = build_dir / "no_topstar_upper_blocker"
    compile_cpp(here / "no_topstar_search.cpp", search_bin)
    compile_cpp(here / "no_topstar_upper_blocker.cpp", upper_bin)

    log_lines: list[str] = []
    upper_text = run_cmd([upper_bin], log_lines, echo=echo)
    require(
        "exact_upper_blocker_branch_bound_ok=True" in upper_text,
        "upper blocker checker did not report success",
    )
    require(
        "min_Q4U=33" in upper_text,
        "upper blocker checker did not certify |Q4 intersect U| >= 33",
    )

    trace_checks = check_trace_thresholds(cert, search_bin, log_lines, echo=echo)
    pattern_checks = check_patterns(cert, search_bin, log_lines, echo=echo)
    arithmetic = check_arithmetic_and_rectangle(cert)

    return {
        "upper_blocker_ok": True,
        "upper_cube_min_missing": 33,
        "trace_threshold_checks": trace_checks,
        "critical_pattern_checks": pattern_checks,
        **arithmetic,
        "command_log": "\n".join(log_lines),
    }


def main() -> None:
    here = Path(__file__).resolve().parent
    default_cert = here.parent / "certificates" / "no_topstar_threshold.json"
    parser = argparse.ArgumentParser(description="Verify the no-top-star certificate.")
    parser.add_argument("--cert", type=Path, default=default_cert)
    parser.add_argument("--build-dir", type=Path, default=here.parent / ".build")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()
    ans = verify_no_topstar(args.cert, args.build_dir, echo=not args.quiet)

    print("no_topstar_certificate_ok=True")
    print(f"upper_blocker_ok={ans['upper_blocker_ok']}")
    print(f"min_Q4U={ans['upper_cube_min_missing']}")
    print(f"trace_threshold_checks={ans['trace_threshold_checks']}")
    print(f"critical_pattern_checks={ans['critical_pattern_checks']}")
    print(f"extremal_pair_shapes={ans['extremal_pair_shapes']}")
    print(f"extremal_triple_shapes={ans['extremal_triple_shapes']}")
    print(f"critical_pair_shapes={ans['critical_pair_shapes']}")
    print("low_range_rows: |Q4| pmax_per_support tmax_per_support lhs rhs")
    for row in ans["low_range_rows"]:
        print("  " + " ".join(map(str, row)))
    print(f"no_extremal_lhs_at_Q4_64={ans['no_extremal_lhs_at_Q4_64']} rhs={625*64}")
    print(f"rectangle_cases={ans['rectangle_cases']}")
    print(f"rectangle_max_case={ans['rectangle_max_case'][:4]}")


if __name__ == "__main__":
    main()
