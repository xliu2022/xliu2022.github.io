/*
Exact target-bounded up-set solver for Appendix A.2.

MATHEMATICAL MODEL
------------------
The universe consists of the 256 wide quads q=(q_1,q_2,q_3,q_4) in [4]^4.
Q4 is the missing-wide-quad family and must be an up-set (N1).  A supported
pair or triple H is supplied either by its level tuple or as one of the five
critical equality patterns.  The program imposes:

  * (N2) Q4 hits every upper 3-matching in {2,3,4}^4;
  * (N3) none of the four minimal full-top-star points belongs to Q4;
  * (N5a) every wide-quad extension of a declared present trace is forbidden
          from Q4 (completion closure);
  * (N5b) every residual 3-matching left by that trace and a disjoint seed is
          hit by Q4 (remaining seed hitting).

The search minimizes |Q4| below a caller-supplied target.  It represents Q4 by
the union of principal up-closures, so every explored state is automatically an
up-set.  An unhit matching clause is satisfied by branching on one of its
points and adding that point's full up-closure.

EXACTNESS AND THE MEANING OF `target`
-------------------------------------
There is no randomization, LP/MILP call, or floating-point feasibility test.
Unit propagation and the cardinality lower bound only prune branches that
cannot contain a solution smaller than the current best value.  The wall-clock
timeout uses floating point but a timeout returns a nonzero exit status and is
therefore never accepted as a certificate.

The variable `best` is initialized to `target`, and the DFS searches only for
solutions of size strictly smaller than it.  Consequently:

  * exact records use target = claimed optimum + 1;
  * lower-bound records use target = claimed lower bound;
  * output `result best=target` may mean that no solution exists below the
    target, rather than that a witness of size exactly target was found.

The Python driver validates that this convention matches every JSON record.
*/

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <exception>
#include <iostream>
#include <stdexcept>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

namespace {

constexpr int kMinLevel = 1;
constexpr int kMaxLevel = 4;
constexpr int kMinSeedLevel = 1;
constexpr int kMaxSeedLevel = 2;
constexpr int kFirstUpperLevel = 2;
constexpr int kFirstHighLevel = 3;
constexpr int kTargetUnset = 999;

struct Bits {
    // A 256-bit characteristic vector, split into four 64-bit words.  It is
    // used for Q4, principal up-closures, forbidden points, and hitting clauses.
    uint64_t w[4];
};

inline Bits zero_bits() { return Bits{{0, 0, 0, 0}}; }
inline bool empty(const Bits& a) { return !(a.w[0] | a.w[1] | a.w[2] | a.w[3]); }
inline Bits bit_or(const Bits& a, const Bits& b) {
    return Bits{{a.w[0] | b.w[0], a.w[1] | b.w[1], a.w[2] | b.w[2], a.w[3] | b.w[3]}};
}
inline Bits bit_and(const Bits& a, const Bits& b) {
    return Bits{{a.w[0] & b.w[0], a.w[1] & b.w[1], a.w[2] & b.w[2], a.w[3] & b.w[3]}};
}
inline Bits bit_minus(const Bits& a, const Bits& b) {
    return Bits{{a.w[0] & ~b.w[0], a.w[1] & ~b.w[1], a.w[2] & ~b.w[2], a.w[3] & ~b.w[3]}};
}
inline bool disjoint(const Bits& a, const Bits& b) {
    return !((a.w[0] & b.w[0]) | (a.w[1] & b.w[1]) | (a.w[2] & b.w[2]) | (a.w[3] & b.w[3]));
}
inline int popcount(const Bits& a) {
    return __builtin_popcountll(a.w[0]) + __builtin_popcountll(a.w[1])
         + __builtin_popcountll(a.w[2]) + __builtin_popcountll(a.w[3]);
}
inline bool subset(const Bits& a, const Bits& b) {
    return ((a.w[0] & ~b.w[0]) | (a.w[1] & ~b.w[1])
          | (a.w[2] & ~b.w[2]) | (a.w[3] & ~b.w[3])) == 0;
}
inline bool equal_bits(const Bits& a, const Bits& b) {
    return a.w[0] == b.w[0] && a.w[1] == b.w[1]
        && a.w[2] == b.w[2] && a.w[3] == b.w[3];
}
inline void set_bit(Bits& bits, int i) { bits.w[i >> 6] |= 1ULL << (i & 63); }

vector<int> bit_indices(Bits bits) {
    vector<int> out;
    for (int block = 0; block < 4; ++block) {
        uint64_t x = bits.w[block];
        while (x) {
            const int b = __builtin_ctzll(x);
            out.push_back(64 * block + b);
            x &= x - 1;
        }
    }
    return out;
}

// Mathematical points use levels {1,2,3,4}; enc only converts them to the
// lexicographic bit index 0,...,255.  No mathematical 0-based relabelling is
// exposed to the certificate data or command-line interface.
int enc(const array<int, 4>& q) {
    return (((q[0] - 1) * 4 + (q[1] - 1)) * 4 + (q[2] - 1)) * 4 + (q[3] - 1);
}

bool leq(const array<int, 4>& a, const array<int, 4>& b) {
    for (int i = 0; i < 4; ++i) {
        if (a[i] > b[i]) {
            return false;
        }
    }
    return true;
}

vector<array<int, 4>> V4;                 // [4]^4 in lexicographic order.
Bits up_closure[256];                     // Principal up-set of each q in V4.
vector<array<int, 3>> upper_permutations; // The six permutations of 2,3,4.
vector<Bits> base_clauses;                // 6^3 clauses encoding (N2).
Bits base_forbidden;                      // Four minimal top-star points (N3).

vector<array<array<int, 4>, 3>> residual_matchings(
    const array<vector<int>, 4>& occupied) {
    /*
    Generate every unordered residual matching of three wide quads.

    `occupied[j]` contains the levels used in column j by a declared present
    trace H and a chosen disjoint seed.  A residual 3-matching must use three
    distinct available levels in each column.  We choose the three levels in
    every coordinate, order the quads by the first-coordinate choice v0, and
    use all 3! permutations in each of coordinates 2,3,4.  Thus no residual
    matching required by (N5) is omitted.
    */

    array<vector<int>, 4> available;
    for (int j = 0; j < 4; ++j) {
        for (int level = kMinLevel; level <= kMaxLevel; ++level) {
            if (find(occupied[j].begin(), occupied[j].end(), level) == occupied[j].end()) {
                available[j].push_back(level);
            }
        }
        if (available[j].size() < 3) {
            return {};
        }
    }

    auto choose_three = [](const vector<int>& values) {
        vector<array<int, 3>> choices;
        const int n = static_cast<int>(values.size());
        for (int i = 0; i < n; ++i) {
            for (int j = i + 1; j < n; ++j) {
                for (int k = j + 1; k < n; ++k) {
                    choices.push_back({values[i], values[j], values[k]});
                }
            }
        }
        return choices;
    };

    const auto C0 = choose_three(available[0]);
    const auto C1 = choose_three(available[1]);
    const auto C2 = choose_three(available[2]);
    const auto C3 = choose_three(available[3]);

    vector<array<array<int, 4>, 3>> out;
    for (const auto& v0 : C0) {
        for (const auto& v1 : C1) {
            for (const auto& v2 : C2) {
                for (const auto& v3 : C3) {
                    vector<array<int, 3>> P1, P2, P3;
                    vector<int> b1 = {v1[0], v1[1], v1[2]};
                    vector<int> b2 = {v2[0], v2[1], v2[2]};
                    vector<int> b3 = {v3[0], v3[1], v3[2]};
                    sort(b1.begin(), b1.end());
                    sort(b2.begin(), b2.end());
                    sort(b3.begin(), b3.end());
                    do {
                        P1.push_back({b1[0], b1[1], b1[2]});
                    } while (next_permutation(b1.begin(), b1.end()));
                    do {
                        P2.push_back({b2[0], b2[1], b2[2]});
                    } while (next_permutation(b2.begin(), b2.end()));
                    do {
                        P3.push_back({b3[0], b3[1], b3[2]});
                    } while (next_permutation(b3.begin(), b3.end()));

                    for (const auto& p1 : P1) {
                        for (const auto& p2 : P2) {
                            for (const auto& p3 : P3) {
                                array<array<int, 4>, 3> matching{};
                                for (int t = 0; t < 3; ++t) {
                                    matching[t] = {v0[t], p1[t], p2[t], p3[t]};
                                }
                                out.push_back(matching);
                            }
                        }
                    }
                }
            }
        }
    }
    return out;
}

void init() {
    // Build the 256-point universe and every principal up-closure.  Later DFS
    // states are unions of these masks, which enforces (N1) by construction.
    for (int a = kMinLevel; a <= kMaxLevel; ++a) {
        for (int b = kMinLevel; b <= kMaxLevel; ++b) {
            for (int c = kMinLevel; c <= kMaxLevel; ++c) {
                for (int d = kMinLevel; d <= kMaxLevel; ++d) {
                    V4.push_back({a, b, c, d});
                }
            }
        }
    }

    for (int i = 0; i < 256; ++i) {
        Bits closure = zero_bits();
        for (int j = 0; j < 256; ++j) {
            if (leq(V4[i], V4[j])) {
                set_bit(closure, j);
            }
        }
        up_closure[i] = closure;
    }

    // All upper 3-matchings can be uniquely ordered by first coordinates
    // 2,3,4.  The remaining three coordinates are arbitrary permutations,
    // giving 6^3=216 matching clauses for (N2).
    vector<int> values = {2, 3, 4};
    do {
        upper_permutations.push_back({values[0], values[1], values[2]});
    } while (next_permutation(values.begin(), values.end()));

    for (const auto& p0 : upper_permutations) {
        for (const auto& p1 : upper_permutations) {
            for (const auto& p2 : upper_permutations) {
                Bits clause = zero_bits();
                for (int i = 0; i < 3; ++i) {
                    const int t = kFirstUpperLevel + i;
                    const array<int, 4> q = {t, p0[i], p1[i], p2[i]};
                    set_bit(clause, enc(q));
                }
                base_clauses.push_back(clause);
            }
        }
    }

    // For an up-set, containing a full top-star in direction `column` is
    // equivalent to containing its minimal point: level 4 in that coordinate
    // and level 2 in the other three.  Forbidding these four points is (N3).
    base_forbidden = zero_bits();
    for (int column = 1; column <= 4; ++column) {
        array<int, 4> q = {2, 2, 2, 2};
        q[column - 1] = 4;
        set_bit(base_forbidden, enc(q));
    }
}

void add_trace(
    vector<Bits>& clauses,
    Bits& forbidden,
    const vector<int>& support,
    const vector<int>& values) {
    /*
    Add the two parts of (N5) for one trace declared present.

    Completion closure:
        enumerate every assignment in the unsupported columns and mark each
        resulting wide-quad extension as forbidden from Q4.

    Remaining seed hitting:
        for each column and each guaranteed seed level 1 or 2 that is disjoint
        from H, generate all residual 3-matchings and add each as a clause that
        Q4 must hit.

    Multiple declared traces (the critical-pattern mode) simply accumulate
    these necessary constraints.
    */

    const int size = static_cast<int>(values.size());
    vector<int> remaining_columns;
    array<int, 5> used{};
    for (int column : support) {
        used[column] = 1;
    }
    for (int column = 1; column <= 4; ++column) {
        if (!used[column]) {
            remaining_columns.push_back(column);
        }
    }

    int total = 1;
    for (size_t i = 0; i < remaining_columns.size(); ++i) {
        total *= 4;
    }
    for (int code = 0; code < total; ++code) {
        int x = code;
        array<int, 4> q = {1, 1, 1, 1};
        for (int t = 0; t < size; ++t) {
            q[support[t] - 1] = values[t];
        }
        for (int k = static_cast<int>(remaining_columns.size()) - 1; k >= 0; --k) {
            q[remaining_columns[k] - 1] = (x % 4) + 1;
            x /= 4;
        }
        set_bit(forbidden, enc(q));
    }

    for (int column = 1; column <= 4; ++column) {
        for (int seed_level = kMinSeedLevel; seed_level <= kMaxSeedLevel; ++seed_level) {
            bool skip = false;
            for (int t = 0; t < size; ++t) {
                if (support[t] == column && values[t] == seed_level) {
                    skip = true;
                }
            }
            if (skip) {
                continue;
            }

            array<vector<int>, 4> occupied;
            for (int t = 0; t < size; ++t) {
                occupied[support[t] - 1].push_back(values[t]);
            }
            occupied[column - 1].push_back(seed_level);
            auto& column_occupied = occupied[column - 1];
            sort(column_occupied.begin(), column_occupied.end());
            column_occupied.erase(unique(column_occupied.begin(), column_occupied.end()), column_occupied.end());

            for (const auto& matching : residual_matchings(occupied)) {
                Bits clause = zero_bits();
                for (const auto& q : matching) {
                    set_bit(clause, enc(q));
                }
                clauses.push_back(clause);
            }
        }
    }
}

struct Solver {
    // `clauses` are subsets of V4 that Q4 must hit.  `forbidden` contains
    // points that Q4 may not contain.  `valid` consists of generators whose
    // entire up-closure avoids the forbidden set.
    vector<Bits> clauses;
    Bits forbidden{};
    Bits valid{};
    int best;
    Bits best_mask{};
    long long nodes = 0;
    long long pruned_by_lower_bound = 0;
    long long unit_steps = 0;
    bool infeasible = false;
    chrono::steady_clock::time_point start;
    double time_limit = 1e9;

    Solver(vector<Bits> input_clauses, Bits input_forbidden, int target)
        : forbidden(input_forbidden), best(target) {
        // A point can generate part of Q4 only if its forced up-closure is
        // disjoint from every completion/top-star point forbidden above.
        valid = zero_bits();
        for (int i = 0; i < 256; ++i) {
            if (disjoint(up_closure[i], forbidden)) {
                set_bit(valid, i);
            }
        }

        // Remove invalid cells from each clause.  If a clause becomes empty,
        // no up-set Q4 can satisfy all current mathematical requirements.
        vector<Bits> restricted;
        for (Bits clause : input_clauses) {
            Bits valid_clause = bit_and(clause, valid);
            if (empty(valid_clause)) {
                infeasible = true;
                return;
            }
            restricted.push_back(valid_clause);
        }

        // Canonicalize the clause family: sort, remove duplicates, and remove
        // any clause containing an already kept smaller clause.  Hitting the
        // smaller clause automatically hits its superset, so this reduction is
        // logically exact and affects only performance.
        sort(restricted.begin(), restricted.end(), [](const Bits& a, const Bits& b) {
            const int pa = popcount(a);
            const int pb = popcount(b);
            if (pa != pb) {
                return pa < pb;
            }
            for (int k = 0; k < 4; ++k) {
                if (a.w[k] != b.w[k]) {
                    return a.w[k] < b.w[k];
                }
            }
            return false;
        });

        vector<Bits> unique_clauses;
        for (const Bits& clause : restricted) {
            if (unique_clauses.empty() || !equal_bits(clause, unique_clauses.back())) {
                unique_clauses.push_back(clause);
            }
        }

        vector<Bits> reduced;
        for (const Bits& clause : unique_clauses) {
            bool redundant = false;
            for (const Bits& kept : reduced) {
                if (subset(kept, clause)) {
                    redundant = true;
                    break;
                }
            }
            if (!redundant) {
                reduced.push_back(clause);
            }
        }
        clauses = move(reduced);
        best_mask = zero_bits();
        start = chrono::steady_clock::now();
    }

    bool timeout() const {
        return chrono::duration<double>(chrono::steady_clock::now() - start).count() > time_limit;
    }

    Bits feasible_cells(const Bits& clause, const Bits& Q4) const {
        // A branch point q is feasible only if q is not already in Q4 and
        // adding its whole up-closure keeps the cardinality strictly below the
        // current target/best value.  Compatibility with `forbidden` is already
        // guaranteed by membership in `valid` after clause restriction.
        Bits candidates = bit_minus(clause, Q4);
        Bits out = zero_bits();
        for (int i : bit_indices(candidates)) {
            if (popcount(bit_or(Q4, up_closure[i])) < best) {
                set_bit(out, i);
            }
        }
        return out;
    }

    bool propagate(Bits& Q4) {
        // Exact unit propagation: when an unhit clause has exactly one
        // feasible point q, every solution below `best` must include q and
        // hence its full up-closure.  Empty candidate sets prove the branch
        // infeasible below `best`.
        bool changed = true;
        while (changed) {
            changed = false;
            for (const Bits& clause : clauses) {
                if (!disjoint(clause, Q4)) {
                    continue;
                }
                Bits candidates = feasible_cells(clause, Q4);
                if (empty(candidates)) {
                    return false;
                }
                if (popcount(candidates) == 1) {
                    const int i = bit_indices(candidates)[0];
                    Bits next = bit_or(Q4, up_closure[i]);
                    if (popcount(next) >= best) {
                        return false;
                    }
                    if (!equal_bits(next, Q4)) {
                        Q4 = next;
                        changed = true;
                        ++unit_steps;
                        break;
                    }
                }
            }
        }
        return true;
    }

    int lower_bound(const Bits& Q4) const {
        /*
        A cardinality lower bound for the still-missing points of Q4.

        Select greedily a family of unhit clauses whose currently feasible
        point sets are pairwise disjoint.  Any completion must add at least one
        distinct Q4 point for each selected clause, so the number selected is a
        valid lower bound.  Greediness may weaken the bound but can never make
        it unsafe.
        */

        vector<Bits> remaining;
        for (const Bits& clause : clauses) {
            if (!disjoint(clause, Q4)) {
                continue;
            }
            Bits candidates = feasible_cells(clause, Q4);
            if (empty(candidates)) {
                return 1000000;
            }
            remaining.push_back(candidates);
        }
        sort(remaining.begin(), remaining.end(), [](const Bits& a, const Bits& b) {
            return popcount(a) < popcount(b);
        });
        Bits used = zero_bits();
        int bound = 0;
        for (const Bits& candidates : remaining) {
            if (disjoint(candidates, used)) {
                used = bit_or(used, candidates);
                ++bound;
            }
        }
        return bound;
    }

    int hit_count(const Bits& closure, const Bits& Q4) const {
        // Search-order heuristic only: count how many currently unhit clauses
        // would be hit by this closure.  It never causes pruning.
        int count = 0;
        for (const Bits& clause : clauses) {
            if (disjoint(clause, Q4) && !disjoint(clause, closure)) {
                ++count;
            }
        }
        return count;
    }

    void dfs(Bits Q4) {
        /*
        Complete branch-and-bound search below `best`.

        After propagation and the rigorous cardinality bound, choose an unhit
        clause having the fewest feasible branch points.  Every valid final Q4
        must contain at least one point of this clause.  Branching on every such
        point and adding its up-closure therefore covers all up-set solutions
        of cardinality below `best`.  Candidate ordering and duplicate removal
        are performance devices only.
        */

        ++nodes;
        if ((nodes % 10000000) == 0) {
            cerr << "nodes " << nodes << " best " << best
                 << " current " << popcount(Q4)
                 << " pruned_lb " << pruned_by_lower_bound << '\n';
        }
        if (timeout()) {
            throw runtime_error("timeout");
        }
        if (!propagate(Q4)) {
            return;
        }

        const int current_size = popcount(Q4);
        if (current_size >= best) {
            return;
        }
        const int bound = lower_bound(Q4);
        if (current_size + bound >= best) {
            ++pruned_by_lower_bound;
            return;
        }

        bool done = true;
        vector<tuple<int, int, Bits, int>> best_candidates;
        int best_length = 1000000000;
        for (const Bits& clause : clauses) {
            if (!disjoint(clause, Q4)) {
                continue;
            }
            done = false;
            Bits feasible = feasible_cells(clause, Q4);
            vector<tuple<int, int, Bits, int>> candidates;
            for (int i : bit_indices(feasible)) {
                Bits closure = up_closure[i];
                Bits next = bit_or(Q4, closure);
                const int next_size = popcount(next);
                if (next_size < best) {
                    candidates.emplace_back(
                        next_size - current_size,
                        -hit_count(closure, Q4),
                        closure,
                        i);
                }
            }
            if (candidates.empty()) {
                return;
            }
            if (static_cast<int>(candidates.size()) < best_length) {
                best_length = static_cast<int>(candidates.size());
                best_candidates = move(candidates);
                if (best_length == 1) {
                    break;
                }
            }
        }

        if (done) {
            best = current_size;
            best_mask = Q4;
            cerr << "new best " << best << " nodes " << nodes
                 << " pruned_lb " << pruned_by_lower_bound << '\n';
            return;
        }

        sort(best_candidates.begin(), best_candidates.end(), [](const auto& a, const auto& b) {
            if (get<0>(a) != get<0>(b)) {
                return get<0>(a) < get<0>(b);
            }
            return get<1>(a) < get<1>(b);
        });

        vector<Bits> seen;
        for (const auto& candidate : best_candidates) {
            Bits next = bit_or(Q4, get<2>(candidate));
            bool duplicate = false;
            for (const Bits& prior : seen) {
                if (equal_bits(prior, next)) {
                    duplicate = true;
                    break;
                }
            }
            if (!duplicate) {
                seen.push_back(next);
                dfs(next);
            }
        }
    }
};

bool valid_level(int value) {
    return kMinLevel <= value && value <= kMaxLevel;
}

}  // namespace

int main(int argc, char** argv) {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    init();

    // Two input modes are supported:
    //   trace mode: two or three positional levels, for Conclusion A.2;
    //   pattern mode: --pattern ..., for the equality cases in Conclusion A.3.
    // In both modes --target B asks whether a feasible Q4 of size < B exists.
    string pattern;
    int target = kTargetUnset;
    double time_limit = 1e9;
    int forbid_a = -1;
    int forbid_b = -1;
    vector<int> values;

    for (int i = 1; i < argc; ++i) {
        const string arg = argv[i];
        if (arg == "--pattern" && i + 1 < argc) {
            pattern = argv[++i];
        } else if (arg == "--target" && i + 1 < argc) {
            target = stoi(argv[++i]);
        } else if (arg == "--time" && i + 1 < argc) {
            time_limit = stod(argv[++i]);
        } else if (arg == "--forbid-rect" && i + 2 < argc) {
            forbid_a = stoi(argv[++i]);
            forbid_b = stoi(argv[++i]);
        } else {
            values.push_back(stoi(arg));
        }
    }

    // Every run starts with (N2)--(N3); trace/pattern constraints are appended.
    vector<Bits> clauses = base_clauses;
    Bits forbidden = base_forbidden;
    string label;

    if (pattern.empty()) {
        if (values.size() != 2 && values.size() != 3) {
            cerr << "trace mode expects two or three levels\n";
            return 1;
        }
        if (!all_of(values.begin(), values.end(), valid_level)) {
            cerr << "trace levels must belong to {1,2,3,4}\n";
            return 1;
        }
        // By column-permutation symmetry, sorted pair/triple orbit
        // representatives may be placed on supports {1,2} or {1,2,3}.
        const vector<int> support = values.size() == 2
            ? vector<int>{1, 2}
            : vector<int>{1, 2, 3};
        add_trace(clauses, forbidden, support, values);
        label = "trace";
    } else {
        const vector<int> triple_support = {1, 2, 3};
        if (pattern == "pair_square") {
            // The only pair equality shape surviving the |Q4|<=66 individual
            // thresholds: {1,2} x {1,2} on support {1,2}.
            const vector<int> pair_support = {1, 2};
            for (const auto& vals : vector<vector<int>>{{1, 1}, {1, 2}, {2, 1}, {2, 2}}) {
                add_trace(clauses, forbidden, pair_support, vals);
            }
        } else if (pattern.rfind("triple_slab", 0) == 0) {
            // One of the three 32-point slabs on support {1,2,3}: the selected
            // coordinate is restricted to levels 1 or 2.
            const string suffix = pattern.substr(string("triple_slab").size());
            const int coordinate = suffix.empty() ? -1 : stoi(suffix);
            if (coordinate < 1 || coordinate > 3) {
                cerr << "triple_slab coordinate must be 1, 2, or 3\n";
                return 1;
            }
            for (int a = 1; a <= 4; ++a) {
                for (int b = 1; b <= 4; ++b) {
                    for (int c = 1; c <= 4; ++c) {
                        vector<int> vals = {a, b, c};
                        if (vals[coordinate - 1] <= 2) {
                            add_trace(clauses, forbidden, triple_support, vals);
                        }
                    }
                }
            }
        } else if (pattern == "triple_mixed") {
            // The non-slab equality pattern from Lemma 4.4, represented by its
            // 4x4 height matrix.  It contains exactly 32 triple levels.
            const int heights[4][4] = {
                {4, 4, 2, 2},
                {4, 4, 2, 2},
                {2, 2, 0, 0},
                {2, 2, 0, 0},
            };
            for (int a = 1; a <= 4; ++a) {
                for (int b = 1; b <= 4; ++b) {
                    for (int c = 1; c <= heights[a - 1][b - 1]; ++c) {
                        add_trace(clauses, forbidden, triple_support, {a, b, c});
                    }
                }
            }
        } else {
            cerr << "unknown pattern: " << pattern << '\n';
            return 1;
        }
        label = "pattern=" + pattern;
    }

    if (forbid_a >= 0 || forbid_b >= 0) {
        if (forbid_a < 1 || forbid_a > 4 || forbid_b < 1 || forbid_b > 4 || forbid_a == forbid_b) {
            cerr << "--forbid-rect expects two distinct column labels in {1,2,3,4}\n";
            return 1;
        }
        // To prove that an up-set Q4 contains R_ab, assume the negation.  Since
        // R_ab is the principal up-set generated by the point with coordinates
        // a,b equal to 3 and all others equal to 1, R_ab is not contained in Q4
        // exactly when this minimal point is forbidden from Q4.
        array<int, 4> q = {1, 1, 1, 1};
        q[forbid_a - 1] = kFirstHighLevel;
        q[forbid_b - 1] = kFirstHighLevel;
        set_bit(forbidden, enc(q));
    }

    Solver solver(clauses, forbidden, target);
    solver.time_limit = time_limit;
    if (pattern.empty()) {
        cout << label;
        for (int value : values) {
            cout << ' ' << value;
        }
        cout << " clauses_raw=" << clauses.size();
    } else {
        cout << label << " forbid_rect=" << forbid_a << ',' << forbid_b
             << " raw=" << clauses.size();
    }
    cout << " clauses_reduced=" << solver.clauses.size()
         << " forbid=" << popcount(forbidden)
         << " valid=" << popcount(solver.valid)
         << " target=" << target << '\n';

    if (solver.infeasible) {
        // Stronger than any requested lower bound: no Q4 satisfies the initial
        // clauses and forbidden-point constraints at all.
        cout << "initial_infeasible best=None\n";
        return 0;
    }

    try {
        Bits Q4 = zero_bits();
        solver.dfs(Q4);
    } catch (const exception&) {
        cout << "TIMEOUT nodes=" << solver.nodes << " best=" << solver.best << '\n';
        return 2;
    }

    // Recall that `best==target` can mean that the exhaustive search found no
    // solution below target.  The Python driver interprets this according to
    // the record mode (exact optimum versus target-bounded lower bound).
    cout << "result best=" << (solver.best >= kTargetUnset ? -1 : solver.best)
         << " nodes=" << solver.nodes
         << " prlb=" << solver.pruned_by_lower_bound
         << " unit=" << solver.unit_steps << '\n';
    return 0;
}
