/*
Exact verifier for Conclusion A.1 (the upper-cube blocker bound).

MATHEMATICAL STATEMENT
----------------------
Let U={2,3,4}^4 and let C=U\Q4 be the present upper wide quads.  Under (N1), C
is a down-set.  Under (N3), the four unit-top points

    (4,2,2,2), (2,4,2,2), (2,2,4,2), (2,2,2,4)

belong to C.  Under (N2), C contains no matching of three upper quads.  This
program proves the exact maximum |C|=48, and therefore

    |Q4 intersect U| = 81-|C| >= 33.

ENCODING
--------
A down-set C is represented uniquely by a monotone 3x3x3 height array h.  For
fixed (a,b,c) in {2,3,4}^3, h[a-2][b-2][c-2] is the number of consecutive
fourth-coordinate levels d=2,3,... that belong to C.  Each height lies in
{0,1,2,3} and is nonincreasing as a,b,c increase.

CERTIFIED SEARCH
----------------
1. Verify explicitly a legal witness of size 48 with no upper 3-matching.
2. Enumerate every monotone height array that can still reach size at least 49,
   enforcing the four unit-top points during recursion.
3. At every completed array of size at least 49, test all 6^3=216 upper
   3-matching masks.  Any candidate without a matching would be a counterexample
   and terminates the program with failure.

The only pruning compares the current size plus the largest possible monotone
completion with 48, so no candidate relevant to the assertion can be removed.
All mathematical tests are exact integer or bit-mask operations.
*/

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <utility>
#include <vector>

using namespace std;

namespace {

constexpr int kUpperMin = 2;
constexpr int kUpperMax = 4;
constexpr int kUpperSide = 3;

// h[a-2][b-2][c-2] is the number of fourth-coordinate levels, beginning at
// level 2, that belong to the present upper down-set C.  Thus h=0 includes no
// point in the vertical fibre and h=3 includes d=2,3,4.
int h[kUpperSide][kUpperSide][kUpperSide];
array<int, 3> positions[27];  // The 27 fibres, in lexicographic recursion order.
vector<pair<unsigned long long, unsigned long long>> matching_masks;  // 216 masks.
unsigned long long unit_lo = 0;
unsigned long long unit_hi = 0;
long long leaves_ge_49 = 0;
long long tested = 0;
long long unit_pass = 0;
int best = 0;

inline int index_of(int level) { return level - kUpperMin; }

inline int bit_id(int a, int b, int c, int d) {
    // Lexicographic encoding of the 81 points of U into bit ids 0,...,80.
    return (((index_of(a) * 3 + index_of(b)) * 3 + index_of(c)) * 3 + index_of(d));
}

inline void set_bit(
    unsigned long long& lo,
    unsigned long long& hi,
    int id) {
    if (id < 64) {
        lo |= 1ULL << id;
    } else {
        hi |= 1ULL << (id - 64);
    }
}

inline int& height_at(int a, int b, int c) {
    return h[index_of(a)][index_of(b)][index_of(c)];
}

void build_mask(unsigned long long& lo, unsigned long long& hi) {
    // Convert the current height array to the 81-bit characteristic mask of C.
    lo = 0;
    hi = 0;
    for (int a = kUpperMin; a <= kUpperMax; ++a) {
        for (int b = kUpperMin; b <= kUpperMax; ++b) {
            for (int c = kUpperMin; c <= kUpperMax; ++c) {
                const int height = height_at(a, b, c);
                for (int d = kUpperMin; d < kUpperMin + height; ++d) {
                    set_bit(lo, hi, bit_id(a, b, c, d));
                }
            }
        }
    }
}

bool contains_mask(
    unsigned long long lo,
    unsigned long long hi,
    unsigned long long mask_lo,
    unsigned long long mask_hi) {
    return ((lo & mask_lo) == mask_lo) && ((hi & mask_hi) == mask_hi);
}

bool has_upper_matching(unsigned long long lo, unsigned long long hi) {
    // N2 fails exactly when one of the 216 three-point matching masks is
    // contained in C.
    for (const auto& mask : matching_masks) {
        if (contains_mask(lo, hi, mask.first, mask.second)) {
            return true;
        }
    }
    return false;
}

bool validate_witness() {
    /*
    Verify the lower-bound witness |C|=48.

    The hard-coded entries are heights, not quad coordinates.  The routine
    independently checks their total, monotonicity, four forced inclusions, and
    absence of every upper 3-matching before recording best=48.
    */

    const int witness[3][3][3] = {
        {{3, 3, 2}, {3, 3, 2}, {2, 2, 0}},
        {{3, 3, 2}, {3, 3, 2}, {2, 2, 0}},
        {{2, 2, 0}, {2, 2, 0}, {0, 0, 0}},
    };

    int size = 0;
    for (int ia = 0; ia < 3; ++ia) {
        for (int ib = 0; ib < 3; ++ib) {
            for (int ic = 0; ic < 3; ++ic) {
                h[ia][ib][ic] = witness[ia][ib][ic];
                size += h[ia][ib][ic];
            }
        }
    }

    for (int ia = 0; ia < 3; ++ia) {
        for (int ib = 0; ib < 3; ++ib) {
            for (int ic = 0; ic < 3; ++ic) {
                if (ia > 0 && h[ia][ib][ic] > h[ia - 1][ib][ic]) {
                    return false;
                }
                if (ib > 0 && h[ia][ib][ic] > h[ia][ib - 1][ic]) {
                    return false;
                }
                if (ic > 0 && h[ia][ib][ic] > h[ia][ib][ic - 1]) {
                    return false;
                }
            }
        }
    }

    unsigned long long lo, hi;
    build_mask(lo, hi);
    const bool ok = size == 48
        && contains_mask(lo, hi, unit_lo, unit_hi)
        && !has_upper_matching(lo, hi);
    if (ok) {
        best = 48;
    }
    return ok;
}

int remaining_upper_bound(int pos) {
    /*
    Largest possible additional height sum after recursion position `pos`.

    Fill each unassigned fibre greedily with the maximum value allowed by the
    already fixed/temporarily maximized predecessor fibres.  This gives a true
    upper bound on the size of every monotone completion, so pruning with it is
    logically safe.
    */

    int temporary[3][3][3];
    memset(temporary, 0, sizeof(temporary));

    for (int i = 0; i < pos; ++i) {
        const auto [a, b, c] = positions[i];
        temporary[index_of(a)][index_of(b)][index_of(c)] = height_at(a, b, c);
    }

    int upper_bound = 0;
    for (int i = pos; i < 27; ++i) {
        const auto [a, b, c] = positions[i];
        int max_value = 3;
        if (a > kUpperMin) {
            max_value = min(max_value, temporary[index_of(a - 1)][index_of(b)][index_of(c)]);
        }
        if (b > kUpperMin) {
            max_value = min(max_value, temporary[index_of(a)][index_of(b - 1)][index_of(c)]);
        }
        if (c > kUpperMin) {
            max_value = min(max_value, temporary[index_of(a)][index_of(b)][index_of(c - 1)]);
        }
        temporary[index_of(a)][index_of(b)][index_of(c)] = max_value;
        upper_bound += max_value;
    }
    return upper_bound;
}

void search(int pos, int size) {
    // If even the largest monotone completion has size at most 48, this branch
    // cannot contain a counterexample of size at least 49.
    if (size + remaining_upper_bound(pos) <= 48) {
        return;
    }
    if (pos == 27) {
        if (size <= 48) {
            return;
        }
        ++leaves_ge_49;
        unsigned long long lo, hi;
        build_mask(lo, hi);
        if (!contains_mask(lo, hi, unit_lo, unit_hi)) {
            return;
        }
        ++unit_pass;
        ++tested;
        if (!has_upper_matching(lo, hi)) {
            // A completed admissible C of size >=49 without a matching would
            // refute Conclusion A.1, so print it and fail immediately.
            cerr << "counterexample_size=" << size << '\n';
            for (int a = kUpperMin; a <= kUpperMax; ++a) {
                for (int b = kUpperMin; b <= kUpperMax; ++b) {
                    for (int c = kUpperMin; c <= kUpperMax; ++c) {
                        cerr << height_at(a, b, c);
                    }
                    cerr << ' ';
                }
                cerr << '\n';
            }
            exit(1);
        }
        return;
    }

    const auto [a, b, c] = positions[pos];
    int max_value = 3;
    if (a > kUpperMin) {
        max_value = min(max_value, height_at(a - 1, b, c));
    }
    if (b > kUpperMin) {
        max_value = min(max_value, height_at(a, b - 1, c));
    }
    if (c > kUpperMin) {
        max_value = min(max_value, height_at(a, b, c - 1));
    }

    // The no-top-star condition forces the four unit-top points of C:
    // (4,2,2,2), (2,4,2,2), (2,2,4,2), (2,2,2,4).  The first three require
    // height at least 1 in their fibres; the last requires height 3 in the
    // fibre (2,2,2), because d=4 is the third upper level.
    int min_value = 0;
    if ((a == 4 && b == 2 && c == 2)
        || (a == 2 && b == 4 && c == 2)
        || (a == 2 && b == 2 && c == 4)) {
        min_value = 1;
    }
    if (a == 2 && b == 2 && c == 2) {
        min_value = 3;
    }

    for (int value = max_value; value >= min_value; --value) {
        height_at(a, b, c) = value;
        search(pos + 1, size + value);
    }
}

}  // namespace

int main() {
    int id = 0;
    for (int a = kUpperMin; a <= kUpperMax; ++a) {
        for (int b = kUpperMin; b <= kUpperMax; ++b) {
            for (int c = kUpperMin; c <= kUpperMax; ++c) {
                positions[id++] = {a, b, c};
            }
        }
    }

    set_bit(unit_lo, unit_hi, bit_id(4, 2, 2, 2));
    set_bit(unit_lo, unit_hi, bit_id(2, 4, 2, 2));
    set_bit(unit_lo, unit_hi, bit_id(2, 2, 4, 2));
    set_bit(unit_lo, unit_hi, bit_id(2, 2, 2, 4));

    // Order the three quads by first-coordinate levels 2,3,4.  Each of the
    // remaining coordinates can be any permutation of these levels, yielding
    // all 6^3=216 upper 3-matchings.
    vector<array<int, 3>> permutations3;
    array<int, 3> base = {2, 3, 4};
    do {
        permutations3.push_back(base);
    } while (next_permutation(base.begin(), base.end()));

    for (const auto& p0 : permutations3) {
        for (const auto& p1 : permutations3) {
            for (const auto& p2 : permutations3) {
                unsigned long long lo = 0;
                unsigned long long hi = 0;
                for (int i = 0; i < 3; ++i) {
                    const int t = i + 2;
                    set_bit(lo, hi, bit_id(t, p0[i], p1[i], p2[i]));
                }
                matching_masks.push_back({lo, hi});
            }
        }
    }

    const auto start = chrono::steady_clock::now();
    // The witness proves max |C|>=48; the exhaustive search below proves that
    // no admissible C has size >=49.
    if (!validate_witness()) {
        cerr << "witness_failed\n";
        return 1;
    }

    memset(h, 0, sizeof(h));
    search(0, 0);
    const auto finish = chrono::steady_clock::now();

    cout << "witness_size=48\n";
    cout << "searched_downsets_with_size_at_least_49=" << leaves_ge_49 << '\n';
    cout << "unit_top_candidates_tested=" << unit_pass << '\n';
    cout << "max_C=48\n";
    cout << "min_Q4U=33\n";
    cout << "exact_upper_blocker_branch_bound_ok=True\n";
    cerr << "time_sec=" << chrono::duration<double>(finish - start).count() << '\n';
    return 0;
}
