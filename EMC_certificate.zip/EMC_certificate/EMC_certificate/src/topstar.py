#!/usr/bin/env python3
"""Exact verifier for the top-star Farkas certificates in Appendix A.1.

Mathematical normalization
--------------------------
The four selected matching edges are the columns ``E_1,...,E_4`` and both
columns and levels are indexed by ``[4] = {1,2,3,4}``.  By permuting columns,
the proof fixes column 4 as the top-star direction.  A wide quad is therefore
written as ``(x,t)`` with ``x in [4]^3`` and fourth coordinate ``t``.

The variables are the 0--1 indicators from Lemma 4.6 and Appendix A.1:

``y_x``
    the top-slice quad ``(x,4)`` is present (``x in Ctop``);
``m_{x,t}``, ``t in {1,2,3}``
    the lower-slice quad ``(x,t)`` is missing (``(x,t) in N``);
``t_{I,v}``
    the wide triple on support ``I`` at levels ``v`` is present;
``p_{J,u}``
    the wide pair on support ``J`` at levels ``u`` is present.

Thus ``X=(y,m,t,p)`` has ``64+192+256+96=608`` coordinates and the objective
has coefficients ``625,-625,300,144``.  The desired branch inequality is

    d^T X <= 40000.

Certificate model
-----------------
For each of the 63 branches, this module reconstructs ``A_beta X <= b_beta``
from the source-level versions of (R1)--(R10).  The JSON file does *not* store
``A_beta``, ``b_beta``, or ``d``; it stores only a positive common denominator
``D_beta`` and nonnegative multipliers ``lambda_beta`` and ``mu_beta``.  Python
integers are then used to check, with no rounding,

    A_beta^T lambda_beta + mu_beta >= D_beta d,
    b_beta^T lambda_beta + 1^T mu_beta <= 40000 D_beta.

The row order is part of the certificate interface because the JSON stores row
indices.  In particular, the residual (R8) generator intentionally uses the
fixed cyclic subfamily described at ``residual_three_quads`` below.  Every such
row is a valid (R8) inequality; using only a subfamily gives a weaker relaxation
and is therefore sufficient for an upper-bound certificate.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from functools import lru_cache
from itertools import combinations, product
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

# Manuscript labels.  No 0-based mathematical relabelling is used: conversion
# to Python list indices happens only inside the small indexing dictionaries.
COLUMNS = (1, 2, 3, 4)
LEVELS = (1, 2, 3, 4)
LOWER_LEVELS = (1, 2, 3)
SEED_LEVELS = (1, 2)
TOP_LEVEL = 4

# ``V3`` indexes the first three coordinates of a wide quad.  ``VIDX`` gives
# the deterministic position of y_x in the first 64 entries of X.
V3 = list(product(LEVELS, repeat=3))
VIDX = {x: i for i, x in enumerate(V3)}

# ``Z`` is the 37-point set from (R1): at least one of the three coordinates is
# level 1.  A full top-star in direction 4 makes every top-slice point outside
# Z missing, hence Ctop is contained in Z.
#
# The certificate stores *row indices*, so the order in which the branch-only
# principal-ideal/filter rows are generated must remain fixed.  ``Z_ORDER`` is
# the exact manuscript-level (1-based) point order used when the submitted
# multipliers were produced.  Its order has no mathematical significance, but
# changing it would change row indices and would require a new certificate.
Z_ORDER = [
    (3, 1, 3), (1, 2, 1), (3, 2, 1), (1, 2, 4), (1, 4, 1),
    (1, 4, 4), (2, 4, 1), (1, 1, 2), (3, 4, 1), (1, 3, 2),
    (2, 1, 2), (2, 2, 1), (4, 1, 4), (4, 1, 1), (3, 1, 2),
    (1, 2, 3), (1, 4, 3), (4, 3, 1), (4, 1, 2), (1, 1, 4),
    (1, 3, 1), (1, 1, 1), (1, 3, 4), (2, 1, 1), (4, 1, 3),
    (2, 1, 4), (3, 1, 1), (3, 1, 4), (3, 3, 1), (1, 2, 2),
    (1, 4, 2), (2, 3, 1), (4, 2, 1), (4, 4, 1), (1, 1, 3),
    (1, 3, 3), (2, 1, 3),
]
Z = set(Z_ORDER)

# Lower-slice missing indicators m_{x,t}, followed by all supported triple and
# pair indicators.  Supports are retained explicitly: the same level tuple on
# two different supports represents two different traces.
LOWER = [(x, t) for x in V3 for t in LOWER_LEVELS]
LOWER_MIDX = {qt: i for i, qt in enumerate(LOWER)}
TSUPPS = list(combinations(COLUMNS, 3))
PSUPPS = list(combinations(COLUMNS, 2))
TRIPLES = [(tuple(s), v) for s in TSUPPS for v in product(LEVELS, repeat=3)]
PAIRS = [(tuple(s), v) for s in PSUPPS for v in product(LEVELS, repeat=2)]
TIDX = {tv: i for i, tv in enumerate(TRIPLES)}
PIDX = {pv: i for i, pv in enumerate(PAIRS)}

# Block layout of X=(y,m,t,p).  These offsets are also the variable indices
# stored in the upper-bound multiplier records of the JSON certificate.
OFF_Y = 0
OFF_LOWER_M = 64
OFF_T = OFF_LOWER_M + len(LOWER)
OFF_P = OFF_T + len(TRIPLES)
NVAR = OFF_P + len(PAIRS)

# Integer objective d.  The signs reflect |Q4|=64-c+ell:
# 300|T3|+144|P2| <= 625(64-c+ell) is equivalent to d^T X <= 40000.
TARGET = [0] * NVAR
for i in range(OFF_Y, OFF_LOWER_M):
    TARGET[i] = 625
for i in range(OFF_LOWER_M, OFF_T):
    TARGET[i] = -625
for i in range(OFF_T, OFF_P):
    TARGET[i] = 300
for i in range(OFF_P, NVAR):
    TARGET[i] = 144


def y_var(x: Sequence[int]) -> int:
    """Return the coordinate of the top-slice presence variable y_x."""
    return OFF_Y + VIDX[tuple(x)]


def m_var(x: Sequence[int], t: int) -> int:
    """Return the coordinate of the lower-slice missing variable m_{x,t}."""
    return OFF_LOWER_M + LOWER_MIDX[(tuple(x), int(t))]


def t_var(supp: Sequence[int], vals: Sequence[int]) -> int:
    """Return the coordinate of t_{I,v}, retaining the triple support I."""
    return OFF_T + TIDX[(tuple(supp), tuple(vals))]


def p_var(supp: Sequence[int], vals: Sequence[int]) -> int:
    """Return the coordinate of p_{J,u}, retaining the pair support J."""
    return OFF_P + PIDX[(tuple(supp), tuple(vals))]


def trace_dict(supp: Sequence[int], vals: Sequence[int]) -> Dict[int, int]:
    """Represent a supported trace as ``column -> occupied level``."""
    return dict(zip(tuple(supp), tuple(vals)))


@dataclass(frozen=True)
class Row:
    """One sparse integer inequality ``sum(coeff[j] X_j) <= rhs``.

    ``kind`` is not used mathematically; it is a reproducibility label checked
    against the row type stored beside each multiplier in the JSON file.
    """

    kind: str
    coeff: Dict[int, int]
    rhs: int


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise RuntimeError(msg)


def leq(a: Sequence[int], b: Sequence[int]) -> bool:
    """Coordinatewise order used for stable/down-set and missing/up-set rules."""
    return all(x <= y for x, y in zip(a, b))


def is_bad_triple_matching(points: Sequence[Tuple[int, int, int]]) -> bool:
    """Test the forbidden three-level configuration in Lemma 4.4/(R7).

    The three points must use three distinct levels in every coordinate.  The
    configuration is ``bad`` when at least one coordinate leaves seed level 1
    or 2 unused, because the corresponding seed and the unused full column
    would complete five pairwise disjoint present traces.
    """

    if any(len({p[j] for p in points}) < 3 for j in range(3)):
        return False
    for j in range(3):
        unused = set(LEVELS) - {p[j] for p in points}
        if len(unused) == 1 and next(iter(unused)) in SEED_LEVELS:
            return True
    return False


@lru_cache(maxsize=None)
def residual_three_quads(occupied_key: Tuple[Tuple[int, ...], ...]):
    """Generate the fixed certificate subfamily of residual (R8) matchings.

    ``occupied_key[j]`` lists the levels already used in column ``j+1`` by a
    supported trace H and a disjoint seed.  A residual matching consists of
    three wide quads; in every column it must use three distinct levels not in
    ``occupied_key[j]``.

    For each choice of three available levels in every column, the quads are
    ordered by the increasing first-coordinate levels.  In each of the other
    three coordinates the implementation uses the three cyclic shifts, giving
    ``3^3`` valid alignments.  The full family would have ``6^3`` alignments;
    the omitted rows are not needed by the submitted Farkas certificate.
    Because all generated rows are valid instances of (R8), certifying the
    weaker system obtained from this subfamily remains mathematically sound.
    """

    avail = [[v for v in LEVELS if v not in occupied_key[j]] for j in range(4)]
    if any(len(a) < 3 for a in avail):
        return tuple()
    out = []
    choices = [list(combinations(a, 3)) for a in avail]
    # Certificate-critical ordering: S0 orders the three quads, while alpha,
    # beta, gamma specify cyclic alignments in coordinates 2, 3, and 4.
    for S0 in choices[0]:
        for S1 in choices[1]:
            for S2 in choices[2]:
                for S3 in choices[3]:
                    S = [tuple(S0), tuple(S1), tuple(S2), tuple(S3)]
                    for alpha in range(3):
                        for beta in range(3):
                            for gamma in range(3):
                                out.append(
                                    tuple(
                                        (
                                            S[0][r],
                                            S[1][(r + alpha) % 3],
                                            S[2][(r + beta) % 3],
                                            S[3][(r + gamma) % 3],
                                        )
                                        for r in range(3)
                                    )
                                )
    return tuple(out)


def add_row(rows: List[Row], kind: str, coeff: Dict[int, int], rhs: int) -> None:
    """Append a normalized sparse row, omitting harmless zero rows.

    A zero left-hand side with nonnegative right-hand side is tautological and
    need not receive a row index.  A zero left-hand side with negative
    right-hand side would mean that the reconstructed branch is inconsistent,
    so it is rejected immediately.
    """

    clean = {int(k): int(v) for k, v in coeff.items() if v}
    if clean:
        rows.append(Row(kind, clean, int(rhs)))
    elif rhs < 0:
        raise RuntimeError("constant infeasibility while building top-star system")


def build_base_rows(include_aggregates: bool = True) -> List[Row]:
    """Reconstruct the branch-independent rows (R1)--(R9).

    Only cover relations in the product order are inserted for the down/up-set
    conditions.  Their transitive closure is the full coordinatewise condition
    stated in the manuscript, while the shorter Hasse-edge representation
    keeps the certificate system smaller and fixes the submitted row order.
    """

    rows: List[Row] = []

    # R1: the present top slice is a down-set contained in
    # Z={x in [4]^3 : at least one coordinate is 1}.  ``C_subset_Z`` encodes
    # y_x=0 off Z; ``C_down`` encodes the cover inequalities y_x<=y_{x-e_i}.
    for x in V3:
        if x not in Z:
            add_row(rows, "C_subset_Z", {y_var(x): 1}, 0)
    for x in V3:
        for j in range(3):
            if x[j] > 1:
                xx = list(x)
                xx[j] -= 1
                add_row(rows, "C_down", {y_var(x): 1, y_var(tuple(xx)): -1}, 0)

    # R2: the lower missing quads form an up-set and are compatible with the
    # present top-slice quads.  ``low_up`` and ``low_to_top`` are product-poset
    # cover relations; together they imply every coordinatewise comparison in
    # (R2).  ``compat`` is the same-x lower/top incompatibility and is harmlessly
    # redundant for some t, but is part of the submitted certificate system.
    for x, t in LOWER:
        add_row(rows, "compat", {m_var(x, t): 1, y_var(x): 1}, 1)
    for x, t in LOWER:
        full = x + (t,)
        here = m_var(x, t)
        for j in range(4):
            if full[j] < TOP_LEVEL:
                q = list(full)
                q[j] += 1
                q = tuple(q)
                if q[3] == TOP_LEVEL:
                    add_row(rows, "low_to_top", {here: 1, y_var(q[:3]): 1}, 1)
                else:
                    add_row(rows, "low_up", {here: 1, m_var(q[:3], q[3]): -1}, 0)

    # R3: ell <= c+2, obtained from |Q4|=64-c+ell<=66.
    budget = {m_var(x, t): 1 for x, t in LOWER}
    budget.update({y_var(x): -1 for x in V3})
    add_row(rows, "budget", budget, 2)

    # R4: trace down-set rows, separately on each remembered support I or J.
    for supp, vals in TRIPLES:
        v = t_var(supp, vals)
        for a in range(3):
            if vals[a] > 1:
                vv = list(vals)
                vv[a] -= 1
                add_row(rows, "T_down", {v: 1, t_var(supp, tuple(vv)): -1}, 0)
    for supp, vals in PAIRS:
        v = p_var(supp, vals)
        for a in range(2):
            if vals[a] > 1:
                vv = list(vals)
                vv[a] -= 1
                add_row(rows, "P_down", {v: 1, p_var(supp, tuple(vv)): -1}, 0)

    # R5: completion closure from Lemma 2.9.  A present pair/triple forces every
    # wide-quad extension to be present.  On the top slice this is z_H<=y_x;
    # on a lower slice this is z_H+m_{x,t}<=1.
    for supp, vals in TRIPLES:
        d = trace_dict(supp, vals)
        v = t_var(supp, vals)
        for val in LEVELS:
            q = tuple(d[j] if j in d else val for j in COLUMNS)
            if q[3] == TOP_LEVEL:
                add_row(rows, "T_cl_top", {v: 1, y_var(q[:3]): -1}, 0)
            else:
                add_row(rows, "T_cl_low", {v: 1, m_var(q[:3], q[3]): 1}, 1)
    for supp, vals in PAIRS:
        d = trace_dict(supp, vals)
        rem = [j for j in COLUMNS if j not in d]
        v = p_var(supp, vals)
        for a in LEVELS:
            for b in LEVELS:
                q = [d.get(j) for j in COLUMNS]
                q[rem[0] - 1] = a
                q[rem[1] - 1] = b
                q = tuple(q)
                if q[3] == TOP_LEVEL:
                    add_row(rows, "P_cl_top", {v: 1, y_var(q[:3]): -1}, 0)
                else:
                    add_row(rows, "P_cl_low", {v: 1, m_var(q[:3], q[3]): 1}, 1)

    # R6-R7: pair and triple obstructions from Claim 4.3 and Lemma 4.4.
    vals2 = list(product(LEVELS, repeat=2))
    for supp in PSUPPS:
        for a, b in combinations(vals2, 2):
            if a[0] != b[0] and a[1] != b[1]:
                if any(not set(SEED_LEVELS).issubset({a[i], b[i]}) for i in range(2)):
                    add_row(rows, "pair_cut", {p_var(supp, a): 1, p_var(supp, b): 1}, 1)

    vals3 = list(product(LEVELS, repeat=3))
    bads = [c for c in combinations(vals3, 3) if is_bad_triple_matching(c)]
    for supp in TSUPPS:
        for c in bads:
            add_row(
                rows,
                "bad3",
                {t_var(supp, c[0]): 1, t_var(supp, c[1]): 1, t_var(supp, c[2]): 1},
                2,
            )

    # R8: residual seed-hitting rows.  For each supported trace H and every
    # guaranteed seed disjoint from H, each generated residual 3-matching must
    # contain a missing quad.  Top-slice presence variables and lower-slice
    # missing variables have opposite signs because y=1 means present whereas
    # m=1 means missing.
    def add_residual(trace_variable: int, d: Dict[int, int]) -> None:
        """Add all certificate-selected (R8) rows for one supported trace."""

        for j in COLUMNS:
            for u in SEED_LEVELS:
                if d.get(j) == u:
                    continue
                occupied = {col: {val} for col, val in d.items()}
                occupied.setdefault(j, set()).add(u)
                key = tuple(tuple(sorted(occupied.get(k, set()))) for k in COLUMNS)
                for matching in residual_three_quads(key):
                    # Start from z_H.  For Q=(x,4), present is y_x and the row
                    # receives +y_x; for Q=(x,t), t<=3, missing is m_{x,t} and
                    # the equivalent row receives -m_{x,t}.  The right side is
                    # the number of top-slice quads in the residual matching.
                    coeff = {trace_variable: 1}
                    top_count = 0
                    for q in matching:
                        if q[3] == TOP_LEVEL:
                            coeff[y_var(q[:3])] = coeff.get(y_var(q[:3]), 0) + 1
                            top_count += 1
                        else:
                            coeff[m_var(q[:3], q[3])] = coeff.get(m_var(q[:3], q[3]), 0) - 1
                    add_row(rows, "diag", coeff, top_count)

    for supp, vals in TRIPLES:
        add_residual(t_var(supp, vals), trace_dict(supp, vals))
    for supp, vals in PAIRS:
        add_residual(p_var(supp, vals), trace_dict(supp, vals))

    # R9: aggregate Ferrers bounds |P_J|<=4 and |T_I|<=32.
    if include_aggregates:
        for supp in PSUPPS:
            add_row(rows, "P_agg", {p_var(supp, vals): 1 for vals in product(LEVELS, repeat=2)}, 4)
        for supp in TSUPPS:
            add_row(rows, "T_agg", {t_var(supp, vals): 1 for vals in product(LEVELS, repeat=3)}, 32)
    return rows


def branch_rows(c: int, ell: int | None) -> List[Row]:
    """Construct the branch-specific rows in (R10).

    Every branch fixes ``c=|Ctop|`` by two inequalities.  Only the exceptional
    value c=23 is split further by ``ell=|N|``.  Principal ideal/filter sizes
    then force or forbid individual indicators in any down-set/up-set of the
    fixed cardinality.  These are logical consequences, not heuristic cuts.
    """

    rows: List[Row] = []
    add_row(rows, "fix_c_le", {y_var(x): 1 for x in V3}, c)
    add_row(rows, "fix_c_ge", {y_var(x): -1 for x in V3}, -c)

    for x in Z_ORDER:
        down = sum(1 for z in Z if leq(z, x))
        up = sum(1 for z in Z if leq(x, z))
        if down > c:
            add_row(rows, "top_forbid", {y_var(x): 1}, 0)
        if c > len(Z) - up:
            add_row(rows, "top_force", {y_var(x): -1}, -1)

    if ell is not None:
        add_row(rows, "fix_l_le", {m_var(x, t): 1 for x, t in LOWER}, ell)
        add_row(rows, "fix_l_ge", {m_var(x, t): -1 for x, t in LOWER}, -ell)
        lower_points = [x + (t,) for x, t in LOWER]
        for q in lower_points:
            up = sum(1 for z in lower_points if leq(q, z))
            down = sum(1 for z in lower_points if leq(z, q))
            if up > ell:
                add_row(rows, "low_forbid", {m_var(q[:3], q[3]): 1}, 0)
            if ell > len(lower_points) - down:
                add_row(rows, "low_force", {m_var(q[:3], q[3]): -1}, -1)
    return rows


BASE_ROWS = build_base_rows(True)


def expected_branches() -> set[str]:
    """Return the 37 ordinary c-branches and 26 exceptional (23,ell)-branches."""

    out = {f"c{i}" for i in range(38) if i != 23}
    out.update({f"c23_ell{i}" for i in range(26)})
    return out


def expected_branch_name(c: int, ell: int | None) -> str:
    """Canonical JSON label for the branch parameters."""
    return f"c23_ell{ell}" if c == 23 else f"c{c}"


def load_records(cert_path: Path) -> list[dict]:
    """Load the multiplier records and verify exact branch coverage.

    Coverage is proof-critical: accepting a proper subset of branches would
    leave feasible values of c (or ell when c=23) untreated.
    """

    records = json.loads(cert_path.read_text(encoding="utf-8"))
    require(isinstance(records, list), "top-star certificate root must be a list")
    actual = [rec.get("branch") for rec in records]
    require(len(actual) == len(set(actual)), f"duplicate top-star branch records: {actual}")
    expected = expected_branches()
    require(
        set(actual) == expected,
        f"top-star branch coverage mismatch: missing={sorted(expected-set(actual))} "
        f"extra={sorted(set(actual)-expected)}",
    )
    return records


def check_record(rec: dict) -> Tuple[int, int]:
    """Verify one integer-scaled Farkas record.

    The returned pair is

    ``min_gap``
        the smallest coordinate of ``A^T lambda + mu - D d``;
    ``rhs_gap``
        ``40000 D - b^T lambda - 1^T mu``.

    Both must be nonnegative.  The sparse row sum is rebuilt from the source
    rules; summary numbers stored in the JSON are not substituted for this
    calculation.
    """

    branch = rec.get("branch")
    c = int(rec["c"])
    ell = rec.get("ell")
    rows = BASE_ROWS + branch_rows(c, ell)
    require(branch == expected_branch_name(c, ell), f"{branch}: branch name does not match c/ell")
    denominator = int(rec["denominator"])
    require(denominator > 0, f"{branch}: denominator must be positive")

    row_mults = rec.get("row_multipliers_common_den", [])
    upper_mults = rec.get("upper_multipliers_common_den", [])
    repairs = rec.get("repair_upper_multipliers_common_den", [])
    require(isinstance(row_mults, list), f"{branch}: row multipliers must be a list")
    require(isinstance(upper_mults, list), f"{branch}: upper multipliers must be a list")
    require(isinstance(repairs, list), f"{branch}: repair multipliers must be a list")
    if "row_support_size" in rec:
        require(int(rec["row_support_size"]) == len(row_mults), f"{branch}: row_support_size mismatch")
    if "upper_support_size_after_repair" in rec:
        require(
            int(rec["upper_support_size_after_repair"]) == len(upper_mults),
            f"{branch}: upper_support_size_after_repair mismatch",
        )
    if "repair_upper_count" in rec:
        require(int(rec["repair_upper_count"]) == len(repairs), f"{branch}: repair_upper_count mismatch")

    # Accumulate A^T lambda and b^T lambda exactly.  Python integers have
    # arbitrary precision, so even the large common-denominator numerators are
    # checked without overflow or floating-point tolerance.
    coeff = [0] * NVAR
    rhs = 0
    for rm in row_mults:
        i = int(rm["row_index"])
        weight = int(rm["numerator"])
        require(0 <= i < len(rows), f"{branch}: row index out of range: {i}")
        require(weight >= 0, f"{branch}: negative row multiplier at row {i}")
        row = rows[i]
        require(rm.get("type") == row.kind, f"{branch}: row {i} type mismatch {rm.get('type')} vs {row.kind}")
        if "rhs" in rm:
            require(int(rm["rhs"]) == row.rhs, f"{branch}: row {i} rhs mismatch")
        rhs += weight * row.rhs
        for j, aij in row.coeff.items():
            coeff[j] += weight * aij

    # Each upper multiplier corresponds to the valid indicator bound X_j<=1.
    # It contributes +mu_j to the left vector and +mu_j to the right scalar.
    for um in upper_mults:
        j = int(um["var_index"])
        weight = int(um["numerator"])
        require(0 <= j < NVAR, f"{branch}: upper-bound variable index out of range: {j}")
        require(weight >= 0, f"{branch}: negative upper-bound multiplier at variable {j}")
        coeff[j] += weight
        rhs += weight

    for um in repairs:
        # These entries are provenance metadata describing multipliers that
        # were added when the certificate was rounded/repaired.  Their values
        # are already included in ``upper_mults`` and hence are not added a
        # second time.  Only their basic index/sign well-formedness is needed
        # for the proof; the actual Farkas check uses the final upper list.
        j = int(um["var_index"])
        weight = int(um.get("added_numerator", um.get("numerator", 0)))
        require(0 <= j < NVAR, f"{branch}: repair variable index out of range: {j}")
        require(weight >= 0, f"{branch}: negative repair multiplier at variable {j}")

    min_gap = min(coeff[j] - TARGET[j] * denominator for j in range(NVAR))
    rhs_gap = 40000 * denominator - rhs
    return min_gap, rhs_gap


def verify_topstar(cert_path: Path, start: int = 0, end: int | None = None, verbose: bool = True) -> dict:
    """Verify the selected consecutive block of top-star branches.

    ``run_all.py`` uses the default full range.  The ``start``/``end`` options
    are convenience options for diagnosing an individual record; a partial run
    must not be used as the paper's top-level success check.
    """

    records = load_records(cert_path)
    subset = records[start:end]
    bad = []
    min_gap = None
    min_rhs_gap = None
    for idx, rec in enumerate(subset, start):
        if verbose:
            print(f"topstar check {idx:02d} {rec['branch']}", flush=True)
        gap, rhs_gap = check_record(rec)
        if gap < 0 or rhs_gap < 0:
            bad.append((rec["branch"], gap, rhs_gap))
        min_gap = gap if min_gap is None else min(min_gap, gap)
        min_rhs_gap = rhs_gap if min_rhs_gap is None else min(min_rhs_gap, rhs_gap)
    require(not bad, f"top-star certificate failures: {bad}")
    return {
        "branches": len(subset),
        "all_ok": True,
        "min_gap": min_gap,
        "min_rhs_gap": min_rhs_gap,
        "min_rhs_gap_float": None if min_rhs_gap is None else min_rhs_gap / 1_000_000,
        "rows_reconstructed": len(BASE_ROWS),
        "variables": NVAR,
    }


def main() -> None:
    here = Path(__file__).resolve().parent
    default_cert = here.parent / "certificates" / "topstar_farkas.json"
    parser = argparse.ArgumentParser(description="Verify the top-star exact Farkas certificate.")
    parser.add_argument("--cert", type=Path, default=default_cert)
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--end", type=int, default=None)
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()
    ans = verify_topstar(args.cert, args.start, args.end, verbose=not args.quiet)
    print(
        "topstar_certificate_ok=True "
        f"branches={ans['branches']} variables={ans['variables']} rows={ans['rows_reconstructed']} "
        f"min_gap={ans['min_gap']} min_rhs_gap={ans['min_rhs_gap']} "
        f"min_rhs_gap_float={ans['min_rhs_gap_float']:.9f}"
    )


if __name__ == "__main__":
    main()
