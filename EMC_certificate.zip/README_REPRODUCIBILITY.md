# Reproducibility guide

This guide records the proof-critical commands for the EMC4 submission package.

## Recommended proof verification

```bash
python3 -m pip install -r requirements.txt
bash run_all_proof_checks.sh
```

The top-level proof script runs the explicit threshold checker and then runs
the certificate bundle in publication-grade mode.  Internally it executes:

```bash
python3 threshold/verify_r4_explicit_threshold.py
cd certificate_bundle
bash run_all_checks.sh --full-no-topstar
bash run_all_checks.sh
```

The final fast bundle run refreshes the standard fast log after archiving the
full no-top-star rerun log.

## Full submission check

```bash
bash run_all_submission_checks.sh
```

This builds the manuscript, runs the threshold checker, runs full and fast
certificate checks, removes generated C++ executables, refreshes archived log
checksums, checks the certificate-bundle manifests, refreshes
`SHA256SUMS_ALL.txt` and `SHA256SUMS_SUBMISSION.txt`, and verifies both
top-level manifests.

## Certificate bundle modes

```bash
bash certificate_bundle/run_all_checks.sh
bash certificate_bundle/run_all_checks.sh --full-no-topstar
```

The fast mode checks recorded certificates, archived exact transcripts, and
integer/rational arithmetic.  The full no-top-star mode recompiles and reruns
the C++ branch-and-bound searches from source.

## Expected markers

- `r4_explicit_threshold_ok=True`
- `r4_symbolic_checks_ok=True`
- `pair_ferrers_ok=True`
- `Maximum legal size: 32`
- `all_ok=True`
- `status: ok`
- `exact_upper_blocker_branch_bound_ok=True`
- `exact_no_topstar_threshold_fast_ok=True`
- `exact_no_topstar_threshold_certificate_ok=True`

The release should contain source code, certificate data, archived logs, and
manifests.  Platform-specific compiled C++ executables, Python caches, and
macOS metadata are generated or local files and are not proof artifacts.
