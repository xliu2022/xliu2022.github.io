# EMC4 Mathematical Programming submission package

This package contains:

- `emc4_mathematical_programming_submission.tex` and the compiled PDF;
- `certificate_bundle/`, the proof-critical certificate data and verification scripts;
- `threshold/verify_r4_explicit_threshold.py`, the exact checker for the explicit threshold `s_4=6961`;
- `Dockerfile` and `environment.yml`, reproducible environment entry points;
- `run_all_proof_checks.sh`, the top-level proof verifier for the threshold checker and
  publication-grade certificate checks;
- `README_REPRODUCIBILITY.md`, the referee-facing run guide;
- `SHA256SUMS_ALL.txt` and `SHA256SUMS_SUBMISSION.txt`, top-level manifests covering the manuscript, bibliography,
  threshold checker, certificate bundle manifests, and verification entry points.

The certificate bundle is distributed as source code and certificate data. Platform-specific compiled C++ executables are not included as proof artifacts. The full no-top-star verifier rebuilds the C++ branch-and-bound programs from source.

Dependencies:

- Python 3;
- `numpy`, `scipy`, and `sympy` as listed in `requirements.txt`;
- a C++17 compiler available as `g++`, or via the `CXX` environment variable;
- a standard TeX installation with `pdflatex` and `bibtex`.

Docker verification:

```bash
docker build -t emc4-submission .
docker run --rm emc4-submission
```

Conda setup:

```bash
conda env create -f environment.yml
conda activate emc4-submission
bash run_all_submission_checks.sh
```

The conda file supplies the Python packages and a conda-forge C++ compiler
toolchain.  A standard TeX installation must still provide `pdflatex` and
`bibtex`; use the Dockerfile for a fully specified TeX environment.

Recommended verification commands:

```bash
python3 -m pip install -r requirements.txt
bash run_all_proof_checks.sh
```

For certificate-bundle-only checks:

```bash
bash certificate_bundle/run_all_checks.sh
bash certificate_bundle/run_all_checks.sh --full-no-topstar
```

The top-level convenience script

```bash
bash run_all_submission_checks.sh
```

builds the manuscript, runs the threshold checker, runs the full certificate
verification, removes generated C++ executables, refreshes archived log
checksums, checks the certificate-bundle hash manifests, refreshes the
top-level package manifests, and verifies `SHA256SUMS_ALL.txt` and
`SHA256SUMS_SUBMISSION.txt`.

The 15-board semantic rebuild can take several minutes on a slow machine because it regenerates 264402 labelled residual witnesses and 2016 closure rows. The full no-top-star command reruns the exact C++ up-set searches from source.
