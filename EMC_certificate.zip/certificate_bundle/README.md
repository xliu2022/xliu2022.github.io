# Certificate bundle for the journal-submission version

This bundle contains the verification scripts, certificate data, archived
checker transcripts, and consolidated run outputs for the journal-submission
version.

Dependencies:

- Python 3 with the packages listed in `requirements.txt`;
- a C++17 compiler available as `g++`, or via the `CXX` environment variable.

Standard fast verification:

```bash
bash run_all_checks.sh
```

The standard script runs the deterministic checkers and validates the archived
exact no-top-star threshold transcript.  The 11-board checker
`board11/rebuild_11board_residual_cuts.py` verifies the listed residual-cut
matching witnesses and the dual arithmetic.  The 15-board checker
`board15/rebuild_15board_certificate_from_definition.py` reconstructs the
labelled variable orbits, regenerates the labelled residual-row witnesses and
labelled closure rows from the board definition, checks that these collapse to
the advertised 239 quotient residual/closure inequalities, and verifies the
quotient arithmetic.

For a publication-grade rerun, use the same entry script with the full
no-top-star option:

```bash
bash run_all_checks.sh --full-no-topstar
```

The full verification was run successfully on macOS using a Python virtual
environment with the dependencies listed in `requirements.txt`.  The command was

```bash
PATH=/private/tmp/emc4_check_venv/bin:$PATH bash run_all_checks.sh --full-no-topstar
```

and the run ended with

```text
ALL CHECKS COMPLETED SUCCESSFULLY
Mode: full
Full no-top-star rerun: exact_no_topstar_threshold_certificate_ok=True
```

The corresponding logs are included in
`logs/run_all_checks_full_no_topstar.log` and
`logs/verification_summary_full_no_topstar.txt`.  The top-level submission
package also includes a Dockerfile and a conda environment file for reproducing
the same checks from a clean environment.

To rerun only the slower no-top-star branch-and-bound searches from source:

```bash
bash run_all_checks.sh --only-full-no-topstar
```

The standard run writes one combined log to `logs/run_all_checks.log` and one
summary file to `logs/verification_summary.txt`.  Some individual checkers also
write internal audit files next to their source data; those are retained for
inspection but are not separate top-level outputs.

No Python virtual environment or platform-specific C++ executable is included in
the bundle.  The top-level script compiles the proof-critical C++ programs from
source when they are needed.

## File roles

Proof-critical checkers:

- `pair_ferrers/verify_pair_ferrers.py`
- `triple_ferrers/verify_triple_ferrers.py`
- `topstar/topstar_final_lp_branch_verifier.py`
- `topstar/verify_topstar_common_den_certificates_fast.py`
- `board15/rebuild_15board_certificate_from_definition.py`
- `board11/rebuild_11board_residual_cuts.py`
- `no_topstar_exact/verify_no_topstar_upper_blocker_exact_enum.cpp`
- `no_topstar_exact/exact_no_topstar_hitting_solver.cpp`
- `no_topstar_exact/exact_no_topstar_pattern_solver.cpp`
- `no_topstar_exact/verify_no_topstar_exact_threshold_certificate.py`
- `no_topstar_exact/no_topstar_support_library.py`
- `no_topstar_exact/exact_no_topstar_case.py`
- `no_topstar_exact/exact_upset_hitting.py`

Standalone arithmetic cross-checkers retained for auditability:

- `board15/verify_15board_quotient_certificate_from_summary.py`
- `board11/verify_11board_residual_certificate_from_summary.py`
- `no_topstar_exact/verify_no_topstar_arithmetic_rectangle.py`
- `no_topstar_exact/verify_no_topstar_full_certificate_exact_subprocess.py`

Fast regression / archived-output checks:

- `no_topstar_exact/verify_no_topstar_exact_threshold_fast.py`
- `no_topstar_exact/verify_no_topstar_exact_threshold_archive.py`
- archived logs and checker-local transcript files

Generated files are intentionally excluded from the release bundle: Python
virtual environments, `__pycache__` directories, macOS metadata files, and
platform-specific C++ executables.  Legacy draft artifacts and diagnostic-only
scripts are also excluded from this cleaned bundle.

`SHA256SUMS_RELEASE.txt` records the released source and certificate files,
excluding run logs and generated C++ executables.  `SHA256SUMS_LOGS.txt` records
archived logs and checker-local transcript outputs, including
`logs/run_all_checks.log` and `logs/verification_summary.txt`.  A fresh run
regenerates these logs, so the log checksums are intended only for reproducing
the archived run exactly.
