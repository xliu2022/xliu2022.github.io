#!/usr/bin/env python3
"""Semantic and arithmetic verifier for the listed 11-board residual cuts.

The certificate file lists only the nonzero dual rows.  Each listed row carries
its local witness in the form

    residual pair = Q{...}, F{...}

where Q-objects are missing-quad variables and F-objects are fixed present
traces.  This checker verifies that every listed row has the advertised local
matching witness: the small trace and the two residual traces are pairwise
disjoint, the Q-objects are exactly the missing variables on the right-hand
side, and all listed variable types have the required spreads.  It then repeats
the dual arithmetic check.
"""
from __future__ import annotations

import itertools
import json
import pathlib
import re
from collections import Counter

HERE = pathlib.Path(__file__).resolve().parent
CERT = HERE / "dual_11board_certificate_corrected.txt"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise RuntimeError(msg)


def parse_set(raw: str) -> tuple[str, ...]:
    if not raw.strip():
        return tuple()
    return tuple(sorted(x.strip() for x in raw.split(",") if x.strip()))


def column_letters(points: tuple[str, ...]) -> set[str]:
    return {p[0] for p in points if p[0] in {"A", "B"}}


D = [f"D{i}" for i in range(3)]
A = [f"A{i}" for i in range(4)]
B = [f"B{i}" for i in range(4)]
PTS = D + A + B
PTS_SET = set(PTS)

Z1_TRIPLES = {
    tuple(sorted(H))
    for H in itertools.combinations(PTS, 3)
    if len(column_letters(tuple(H))) == 1
}
Z0_PAIRS = {tuple(sorted(H)) for H in itertools.combinations(D, 2)}
Z2_QUADS = {
    tuple(sorted(Q))
    for Q in itertools.combinations(PTS, 4)
    if len(column_letters(tuple(Q))) == 2
}


ROW_RE = re.compile(
    r"(\d+)\.\s+weight\s+(\d+):\s+([TP])\s+\{([^}]*)\}\s+<=\s+"
    r"(.*?);\s+residual pair\s+=\s+(.*)$"
)
WITNESS_RE = re.compile(r"([QF])\{([^}]*)\}")


def parse_rows(text: str):
    rows = []
    for line in text.splitlines():
        m = ROW_RE.match(line)
        if not m:
            continue
        row_no = int(m.group(1))
        weight = int(m.group(2))
        typ = m.group(3)
        small = parse_set(m.group(4))
        rhs = m.group(5)
        witness_raw = m.group(6)
        rhs_quads = [parse_set(x) for x in re.findall(r"m\{([^}]*)\}", rhs)]
        witnesses = [(kind, parse_set(raw)) for kind, raw in WITNESS_RE.findall(witness_raw)]
        rows.append(
            {
                "row_no": row_no,
                "weight": weight,
                "type": typ,
                "small": small,
                "rhs_quads": rhs_quads,
                "witnesses": witnesses,
            }
        )
    return rows


def check_row(row):
    row_no = row["row_no"]
    weight = row["weight"]
    typ = row["type"]
    small = row["small"]
    rhs_quads = row["rhs_quads"]
    witnesses = row["witnesses"]

    require(weight >= 0, f"row {row_no}: negative dual weight")
    require(len(set(small)) == len(small), f"row {row_no}: repeated point in small trace")
    require(set(small) <= PTS_SET, f"row {row_no}: unknown point in small trace {small}")
    if typ == "T":
        require(small in Z1_TRIPLES, f"row {row_no}: left side is not a spread-1 triple: {small}")
    elif typ == "P":
        require(small in Z0_PAIRS, f"row {row_no}: left side is not a spread-0 pair: {small}")
    else:
        raise RuntimeError(f"row {row_no}: invalid left type {typ}")

    require(len(witnesses) == 2, f"row {row_no}: expected two residual witness traces")
    witness_qs = []
    used = set(small)
    for kind, trace in witnesses:
        require(len(trace) == 4, f"row {row_no}: residual trace is not a quad: {trace}")
        require(len(set(trace)) == 4, f"row {row_no}: repeated point in residual trace {trace}")
        require(set(trace) <= PTS_SET, f"row {row_no}: unknown point in residual trace {trace}")
        require(used.isdisjoint(trace), f"row {row_no}: residual trace is not disjoint from previous traces: {trace}")
        used.update(trace)
        if kind == "Q":
            require(trace in Z2_QUADS, f"row {row_no}: Q witness is not a spread-2 missing quad: {trace}")
            witness_qs.append(trace)
        elif kind == "F":
            require(trace not in Z2_QUADS, f"row {row_no}: F witness is also a spread-2 missing quad: {trace}")
        else:
            raise RuntimeError(f"row {row_no}: invalid witness kind {kind}")

    require(sorted(rhs_quads) == sorted(witness_qs), f"row {row_no}: RHS m{{}} terms do not match Q witnesses")
    for q in rhs_quads:
        require(q in Z2_QUADS, f"row {row_no}: RHS missing variable is not a spread-2 quad: {q}")


def arithmetic(rows):
    small_coeff = Counter()
    miss_load = Counter()
    for row in rows:
        small_coeff[(row["type"], row["small"])] += row["weight"]
        for q in row["rhs_quads"]:
            miss_load[q] += row["weight"]

    small_violations = []
    for H in Z1_TRIPLES:
        if small_coeff[("T", H)] != 300:
            small_violations.append(("T", H, small_coeff[("T", H)]))
    for H in Z0_PAIRS:
        if small_coeff[("P", H)] != 144:
            small_violations.append(("P", H, small_coeff[("P", H)]))

    maxload = 0
    load_violations = []
    for Q in Z2_QUADS:
        load = miss_load[Q]
        maxload = max(maxload, load)
        if load > 625:
            load_violations.append((Q, load))
    return small_violations, load_violations, maxload


def main() -> None:
    rows = parse_rows(CERT.read_text(encoding="utf-8"))
    require(len(rows) == 84, f"expected 84 listed rows, found {len(rows)}")
    require([r["row_no"] for r in rows] == list(range(1, 85)), "row numbers are not exactly 1..84")

    for row in rows:
        check_row(row)

    small_violations, load_violations, maxload = arithmetic(rows)
    require(not small_violations, f"small-trace coefficient violations: {small_violations[:5]}")
    require(not load_violations, f"missing-load violations: {load_violations[:5]}")

    summary = {
        "checker": "board11_semantic",
        "status": "ok",
        "theorem_verified": "300*T^(11)+144*P^(11) <= 625*M^(11)",
        "objects_checked": {
            "spread1_triples": len(Z1_TRIPLES),
            "spread0_pairs": len(Z0_PAIRS),
            "spread2_quads": len(Z2_QUADS),
            "listed_rows": len(rows),
        },
        "max_missing_load": maxload,
        "local_matching_witnesses_verified": True,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
