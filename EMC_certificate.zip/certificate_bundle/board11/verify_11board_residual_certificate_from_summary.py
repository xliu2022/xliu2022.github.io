#!/usr/bin/env python3
"""Exact checker for the 11-board residual-cut certificate summary."""
import itertools, pathlib, re
path = pathlib.Path(__file__).resolve().parent / 'dual_11board_certificate_corrected.txt'
text = path.read_text(encoding='utf-8')
small_coeff = {}
miss_load = {}
rows = []
for line in text.splitlines():
    m = re.match(r'(\d+)\. weight\s+(\d+):\s+([TP])\s+\{([^}]*)\}\s+<=\s+(.*?);', line)
    if not m:
        continue
    row = int(m.group(1)); w = int(m.group(2)); typ = m.group(3)
    H = tuple(sorted(m.group(4).split(',')))
    rows.append(row)
    small_coeff[(typ, H)] = small_coeff.get((typ, H), 0) + w
    for qs in re.findall(r'm\{([^}]*)\}', m.group(5)):
        q = tuple(sorted(qs.split(',')))
        miss_load[q] = miss_load.get(q, 0) + w
D = [f'D{i}' for i in range(3)]
A = [f'A{i}' for i in range(4)]
B = [f'B{i}' for i in range(4)]
pts = D + A + B
z1_triples = []
for H in itertools.combinations(pts, 3):
    cols = set(x[0] for x in H if x[0] in {'A','B'})
    if len(cols) == 1:
        z1_triples.append(tuple(sorted(H)))
z0_pairs = [tuple(sorted(x)) for x in itertools.combinations(D, 2)]
z2_quads = []
for Q in itertools.combinations(pts, 4):
    cols = set(x[0] for x in Q if x[0] in {'A','B'})
    if len(cols) == 2:
        z2_quads.append(tuple(sorted(Q)))
small_violations = []
for H in z1_triples:
    if small_coeff.get(('T', H), 0) != 300:
        small_violations.append(('T', H, small_coeff.get(('T', H), 0)))
for H in z0_pairs:
    if small_coeff.get(('P', H), 0) != 144:
        small_violations.append(('P', H, small_coeff.get(('P', H), 0)))
load_violations = []
maxload = 0
for Q in z2_quads:
    load = miss_load.get(Q, 0)
    maxload = max(maxload, load)
    if load > 625:
        load_violations.append((Q, load))
print(f'rows={len(rows)}')
print(f'z1_triples={len(z1_triples)} z0_pairs={len(z0_pairs)} z2_quads={len(z2_quads)}')
print(f'small_violations={len(small_violations)}')
print(f'max_missing_load={maxload}')
print(f'load_violations={len(load_violations)}')
print(f'certificate_ok={not small_violations and not load_violations}')
if small_violations or load_violations:
    raise RuntimeError('11-board residual certificate has coefficient/load violations')
