#!/usr/bin/env python3
"""Rebuild the 15-board residual rows and verify the listed dual arithmetic.

This checker reconstructs the labelled variable sets, the natural symmetry
group, the residual-row witnesses, and the labelled closure rows from the
15-board definition.  For each present spread-2 triple or spread-1 pair H it
enumerates triples of residual quads R_1,R_2,R_3 which are pairwise disjoint
and disjoint from H.  The fixed residual quads are exactly the original full
columns and the seed quads D plus a low column point.  The variable residual
quads are the spread-3 missing quad variables.  Every such witness gives

    x_H <= sum_{variable residual quads Q among R_i} m_Q.

The labelled residual rows and labelled closure rows are then quotientized by
the stated symmetry group.  The script checks that every listed quotient row in
the published summary is among the regenerated residual rows, checks that the
residual and closure quotient rows have the advertised total count, and then
repeats the coefficient-domination check.
"""
from __future__ import annotations

import itertools
import json
import pathlib
import re
from collections import defaultdict

HERE = pathlib.Path(__file__).resolve().parent
SUMMARY = HERE / "15board_quotient_certificate_summary.txt"

D = [f"D{i}" for i in range(3)]
COLS = ["A", "B", "C"]
PTS = D + [f"{col}{i}" for col in COLS for i in range(4)]
PTS_SET = set(PTS)
FULL_COLUMN_QUADS = {
    tuple(sorted(f"{col}{i}" for i in range(4)))
    for col in COLS
}
SEED_QUADS = {
    tuple(sorted(D + [f"{col}{i}"]))
    for col in COLS
    for i in (0, 1)
}
FIXED_QUADS = FULL_COLUMN_QUADS | SEED_QUADS


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise RuntimeError(msg)


def parse_set(raw: str) -> tuple[str, ...]:
    return tuple(sorted(x.strip() for x in raw.split(",") if x.strip()))


def col_letters(points: tuple[str, ...]) -> set[str]:
    return {p[0] for p in points if p[0] in set(COLS)}


def vtype(obj: tuple[str, ...]) -> str | None:
    c = len(col_letters(obj))
    if len(obj) == 4 and c == 3:
        return "m"
    if len(obj) == 3 and c == 2:
        return "t"
    if len(obj) == 2 and c == 1:
        return "p"
    return None


def disjoint(a: tuple[str, ...], b: tuple[str, ...]) -> bool:
    return set(a).isdisjoint(b)


def residual_quad_type(q: tuple[str, ...]) -> str | None:
    if vtype(q) == "m":
        return "Q"
    if q in FIXED_QUADS:
        return "F"
    return None


def parse_orbits(text: str):
    orbits = {}
    for line in text.splitlines():
        m = re.match(r"\s*(\d+)\s+(m|t|p) size\s+(\d+)\s+\{([^}]*)\}", line)
        if m:
            idx = int(m.group(1))
            orbits[idx] = {
                "type": m.group(2),
                "size": int(m.group(3)),
                "rep": parse_set(m.group(4)),
            }
    return orbits


def parse_rows(text: str):
    rows = []
    for line in text.splitlines():
        m = re.match(r"\s*(\d+)\.\s+weight\s+(\d+):\s*(.*?)\s*<=\s*0", line)
        if not m:
            continue
        rows.append((int(m.group(1)), int(m.group(2)), m.group(3).strip()))
    return rows


def all_group_maps():
    d_perms = list(itertools.permutations(range(3)))
    col_perms = list(itertools.permutations(COLS))
    flip_maps = [
        {0: a0, 1: a1, 2: b2, 3: b3}
        for a0, a1 in [(0, 1), (1, 0)]
        for b2, b3 in [(2, 3), (3, 2)]
    ]
    for dp in d_perms:
        for cp in col_perms:
            cmap = dict(zip(COLS, cp))
            for flips in itertools.product(flip_maps, repeat=3):
                fmap = dict(zip(COLS, flips))

                def act_point(p, dp=dp, cmap=cmap, fmap=fmap):
                    if p[0] == "D":
                        return f"D{dp[int(p[1])]}"
                    return f"{cmap[p[0]]}{fmap[p[0]][int(p[1])]}"

                yield act_point


GROUP = list(all_group_maps())


def act_obj(obj, act_point):
    return tuple(sorted(act_point(p) for p in obj))


def labelled_variables():
    out = {"m": set(), "t": set(), "p": set()}
    for r in (2, 3, 4):
        for obj in itertools.combinations(PTS, r):
            obj = tuple(sorted(obj))
            typ = vtype(obj)
            if typ:
                out[typ].add(obj)
    return out


def compute_orbits(objects):
    unseen = set(objects)
    orbits = []
    while unseen:
        rep = min(unseen)
        orb = {act_obj(rep, g) for g in GROUP}
        require(orb <= objects, f"group action left variable type for representative {rep}")
        orbits.append(orb)
        unseen -= orb
    return orbits


def verify_orbits(summary_orbits):
    variables = labelled_variables()
    computed = {}
    by_type = {}
    for typ, objects in variables.items():
        orbs = compute_orbits(objects)
        by_type[typ] = orbs
        for orb in orbs:
            for obj in orb:
                computed[(typ, obj)] = orb

    require(len(GROUP) == 2304, f"unexpected group order {len(GROUP)}")
    require(sum(len(x) for x in by_type["m"]) == len(variables["m"]), "m-orbits do not partition labelled variables")
    require(sum(len(x) for x in by_type["t"]) == len(variables["t"]), "t-orbits do not partition labelled variables")
    require(sum(len(x) for x in by_type["p"]) == len(variables["p"]), "p-orbits do not partition labelled variables")

    orbit_id = {}
    seen_summary_orbits = set()
    covered = defaultdict(set)
    for idx, row in summary_orbits.items():
        typ = row["type"]
        rep = row["rep"]
        require(set(rep) <= PTS_SET, f"orbit {idx}: unknown point in representative {rep}")
        require(vtype(rep) == typ, f"orbit {idx}: representative has wrong variable type {rep}")
        require((typ, rep) in computed, f"orbit {idx}: representative not in computed orbit map")
        orb = computed[(typ, rep)]
        require(len(orb) == row["size"], f"orbit {idx}: size mismatch")
        frozen = (typ, frozenset(orb))
        require(frozen not in seen_summary_orbits, f"orbit {idx}: duplicate summary orbit")
        seen_summary_orbits.add(frozen)
        covered[typ].update(orb)
        for obj in orb:
            require((typ, obj) not in orbit_id, f"orbit {idx}: duplicate labelled object assignment")
            orbit_id[(typ, obj)] = idx

    summary_by_type = defaultdict(list)
    for row in summary_orbits.values():
        summary_by_type[row["type"]].append(row)
    require({k: len(v) for k, v in summary_by_type.items()} == {"m": 13, "t": 9, "p": 5}, "unexpected summary orbit counts")
    require(len(summary_orbits) == 27, "unexpected total orbit count")
    for typ, objects in variables.items():
        require(covered[typ] == objects, f"summary {typ}-orbits do not cover all labelled variables")
    return variables, by_type, orbit_id


def row_coefficients(expr: str):
    coef = defaultdict(int)
    compact = expr.replace(" ", "")
    for tok in re.findall(r"[+-]?(?:\d+\*)?[mtp]\d+", compact):
        sign = 1
        if tok.startswith("+"):
            tok = tok[1:]
        elif tok.startswith("-"):
            sign = -1
            tok = tok[1:]
        mult = 1
        if "*" in tok:
            a, var = tok.split("*")
            mult = int(a)
        else:
            var = tok
        coef[int(var[1:])] += sign * mult
    return dict(coef)


def partitions_into_three_quads(vertices: tuple[str, ...]):
    require(len(vertices) == 12, f"expected 12 vertices to partition, got {len(vertices)}")
    vertices = tuple(sorted(vertices))
    first = vertices[0]
    rest = vertices[1:]
    for tail1 in itertools.combinations(rest, 3):
        q1 = tuple(sorted((first,) + tail1))
        rem1 = tuple(v for v in vertices if v not in q1)
        first2 = rem1[0]
        for tail2 in itertools.combinations(rem1[1:], 3):
            q2 = tuple(sorted((first2,) + tail2))
            q3 = tuple(v for v in rem1 if v not in q2)
            yield (q1, q2, q3)


def residual_quad_triples(small: tuple[str, ...]):
    remaining = tuple(sorted(PTS_SET - set(small)))
    if len(small) == 3:
        for qs in partitions_into_three_quads(remaining):
            yield None, qs
    elif len(small) == 2:
        for unused in remaining:
            rest = tuple(v for v in remaining if v != unused)
            for qs in partitions_into_three_quads(rest):
                yield unused, qs
    else:
        raise RuntimeError(f"invalid small trace size: {small}")


def quotient_row_key(coeff: dict[int, int]) -> tuple[tuple[int, int], ...]:
    return tuple(sorted((idx, val) for idx, val in coeff.items() if val))


def witness_to_quotient_row(
    small_type: str,
    small: tuple[str, ...],
    residual_quads: tuple[tuple[str, ...], tuple[str, ...], tuple[str, ...]],
    orbit_id: dict[tuple[str, tuple[str, ...]], int],
) -> tuple[tuple[tuple[int, int], ...], tuple[tuple[str, tuple[str, ...]], ...]]:
    coeff = defaultdict(int)
    coeff[orbit_id[(small_type, small)]] += 1
    classified = []
    used = set(small)
    for q in residual_quads:
        require(len(q) == 4 and len(set(q)) == 4, f"invalid residual quad {q}")
        require(used.isdisjoint(q), f"residual quads are not disjoint from earlier traces: {small}, {residual_quads}")
        used.update(q)
        qtype = residual_quad_type(q)
        require(qtype is not None, f"residual quad is neither spread-3 missing nor fixed: {q}")
        classified.append((qtype, q))
        if qtype == "Q":
            coeff[orbit_id[("m", q)]] -= 1
    return quotient_row_key(coeff), tuple(classified)


def regenerate_residual_rows(variables, orbit_id):
    rows = {}
    labelled_witness_count = 0
    small_traces = [("t", h) for h in sorted(variables["t"])]
    small_traces.extend(("p", h) for h in sorted(variables["p"]))

    for small_type, small in small_traces:
        for unused, residual_quads in residual_quad_triples(small):
            if any(residual_quad_type(q) is None for q in residual_quads):
                continue
            key, classified = witness_to_quotient_row(small_type, small, residual_quads, orbit_id)
            labelled_witness_count += 1
            if key not in rows:
                rows[key] = {
                    "labelled_witnesses": 0,
                    "small_type": small_type,
                    "small": small,
                    "unused": unused,
                    "residual_quads": classified,
                }
            rows[key]["labelled_witnesses"] += 1

    return rows, labelled_witness_count


def regenerate_closure_rows(variables, orbit_id):
    rows = {}
    labelled_closure_count = 0
    small_traces = [("t", h) for h in sorted(variables["t"])]
    small_traces.extend(("p", h) for h in sorted(variables["p"]))

    for small_type, small in small_traces:
        small_set = set(small)
        for q in sorted(variables["m"]):
            if not small_set <= set(q):
                continue
            coeff = defaultdict(int)
            coeff[orbit_id[(small_type, small)]] += 1
            coeff[orbit_id[("m", q)]] += 1
            key = quotient_row_key(coeff)
            labelled_closure_count += 1
            if key not in rows:
                rows[key] = {
                    "labelled_closure_rows": 0,
                    "small_type": small_type,
                    "small": small,
                    "missing_quad": q,
                    "rhs": 1,
                }
            rows[key]["labelled_closure_rows"] += 1

    return rows, labelled_closure_count


def verify_rows_and_arithmetic(orbits, rows, regenerated_rows):
    require(len(rows) == 20, f"expected 20 listed quotient rows, found {len(rows)}")
    require([r[0] for r in rows] == list(range(1, 21)), "row numbers are not exactly 1..20")

    combined = {i: 0 for i in orbits}
    listed_keys = set()
    for row_no, weight, expr in rows:
        require(weight >= 0, f"row {row_no}: negative multiplier")
        coeff = row_coefficients(expr)
        require(coeff, f"row {row_no}: empty expression")
        key = quotient_row_key(coeff)
        listed_keys.add(key)
        require(key in regenerated_rows, f"row {row_no}: quotient row is not generated by any labelled residual witness")
        for idx, c in coeff.items():
            require(idx in orbits, f"row {row_no}: unknown orbit variable {idx}")
            typ = orbits[idx]["type"]
            if typ == "m":
                require(c <= 0, f"row {row_no}: missing orbit has positive row coefficient")
            else:
                require(c >= 0, f"row {row_no}: trace orbit has negative row coefficient")
            combined[idx] += weight * c

    objective = {}
    for idx, row in orbits.items():
        typ = row["type"]
        size = row["size"]
        objective[idx] = {"m": -625 * size, "t": 300 * size, "p": 144 * size}[typ]

    violations = []
    slacks = {}
    for idx in sorted(orbits):
        slack = combined[idx] - objective[idx]
        slacks[idx] = slack
        if slack < 0:
            violations.append((idx, combined[idx], objective[idx]))
    require(not violations, f"coefficient domination violations: {violations}")
    return slacks, listed_keys


def main() -> None:
    text = SUMMARY.read_text(encoding="utf-8")
    orbits = parse_orbits(text)
    rows = parse_rows(text)
    variables, by_type, orbit_id = verify_orbits(orbits)
    regenerated_rows, labelled_witness_count = regenerate_residual_rows(variables, orbit_id)
    closure_rows, labelled_closure_count = regenerate_closure_rows(variables, orbit_id)
    require(len(regenerated_rows) == 206, f"unexpected quotient residual-row count: {len(regenerated_rows)}")
    require(len(closure_rows) == 33, f"unexpected quotient closure-row count: {len(closure_rows)}")
    require(
        len(regenerated_rows) + len(closure_rows) == 239,
        f"unexpected quotient residual/closure row count: {len(regenerated_rows) + len(closure_rows)}",
    )
    slacks, listed_keys = verify_rows_and_arithmetic(orbits, rows, regenerated_rows)
    summary = {
        "checker": "board15_labelled_residual_rebuild",
        "status": "ok",
        "theorem_verified": "labelled residual witnesses and quotient arithmetic for 300*T_sigma+144*P_sigma <= 625*M_sigma",
        "group_order": len(GROUP),
        "labelled_variables": {k: len(v) for k, v in variables.items()},
        "fixed_residual_quads": {
            "full_columns": len(FULL_COLUMN_QUADS),
            "seed_quads": len(SEED_QUADS),
        },
        "orbit_counts": {k: len(v) for k, v in by_type.items()},
        "labelled_residual_witnesses": labelled_witness_count,
        "labelled_closure_rows": labelled_closure_count,
        "quotient_residual_rows_regenerated": len(regenerated_rows),
        "quotient_closure_rows_regenerated": len(closure_rows),
        "quotient_residual_closure_rows_regenerated": len(regenerated_rows) + len(closure_rows),
        "listed_rows": len(rows),
        "listed_rows_regenerated_from_labelled_witnesses": len(listed_keys),
        "min_slack": min(slacks.values()),
        "semantic_residual_rows_regenerated": True,
        "semantic_closure_rows_regenerated": True,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
