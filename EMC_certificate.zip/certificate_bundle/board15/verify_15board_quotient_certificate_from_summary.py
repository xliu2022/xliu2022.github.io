#!/usr/bin/env python3
"""Exact checker for the 15-board quotient certificate summary.

It parses the package-local 15board_quotient_certificate_summary.txt and verifies that
nonnegative integer combinations of the listed residual inequalities dominate
  -625*sum size(m_i)m_i + 300*sum size(t_i)t_i + 144*sum size(p_i)p_i.
"""
import pathlib, re
path = pathlib.Path(__file__).resolve().parent / '15board_quotient_certificate_summary.txt'
text = path.read_text(encoding='utf-8')
orbits = {}
for line in text.splitlines():
    m = re.match(r'\s*(\d+)\s+(m|t|p) size\s+(\d+)\s+\{', line)
    if m:
        idx = int(m.group(1)); typ = m.group(2); size = int(m.group(3))
        orbits[idx] = (typ, size)
coef = {i: 0 for i in orbits}
rows = []
for line in text.splitlines():
    m = re.match(r'\s*(\d+)\. weight\s+(\d+):\s*(.*?)\s*<=\s*0', line)
    if not m: continue
    row_no, w, expr = int(m.group(1)), int(m.group(2)), m.group(3).strip()
    rows.append((row_no, w, expr))
    for tok in re.findall(r'[+-]?(?:\d+\*)?[mtp]\d+', expr.replace(' ', '')):
        sign = 1
        if tok.startswith('+'):
            tok = tok[1:]
        elif tok.startswith('-'):
            sign = -1; tok = tok[1:]
        mult = 1
        if '*' in tok:
            a, var = tok.split('*')
            mult = int(a)
        else:
            var = tok
        idx = int(var[1:])
        coef[idx] += sign * w * mult
obj = {}
for i, (typ, size) in orbits.items():
    obj[i] = {'m': -625*size, 't': 300*size, 'p': 144*size}[typ]
violations = []
slacks = []
for i in sorted(orbits):
    if coef[i] < obj[i]:
        violations.append((i, orbits[i], coef[i], obj[i]))
    if coef[i] != obj[i]:
        slacks.append((i, orbits[i], coef[i], obj[i], coef[i]-obj[i]))
print(f'orbits={len(orbits)} rows={len(rows)}')
print(f'violations={len(violations)}')
if violations:
    print('VIOLATIONS:')
    for v in violations:
        print(v)
    raise RuntimeError('15-board quotient certificate has coefficient domination violations')
else:
    print('certificate_ok=True')
print('nonzero_safe_slacks:')
for item in slacks:
    print(item)
