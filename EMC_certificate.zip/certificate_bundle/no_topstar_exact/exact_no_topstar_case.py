#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from itertools import product
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import exact_upset_hitting as exact

def trace_from_vals(vals):
    return {i: vals[i] for i in range(len(vals))}

def run(traces, K, forbid=None):
    ef=0
    if forbid is not None:
        ef |= exact.DOWN[exact.IDX[tuple(forbid)]]
    ok, sol, st = exact.minimize_upset_hitting(traces, K, need_solution=True, extra_forbidden=ef)
    return {'ok': bool(ok), 'size': None if sol is None else int(sol.bit_count()), 'stats': st}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--kind', choices=['trace','pair_square','slab','mixed'], required=True)
    ap.add_argument('--vals')
    ap.add_argument('--K', type=int, required=True)
    ap.add_argument('--slab-index', type=int)
    ap.add_argument('--forbid')
    args=ap.parse_args()
    forbid=None
    if args.forbid:
        forbid=tuple(map(int,args.forbid.split(',')))
    if args.kind=='trace':
        vals=tuple(map(int,args.vals.split(',')))
        traces=[trace_from_vals(vals)]
    elif args.kind=='pair_square':
        traces=[trace_from_vals(v) for v in [(0,0),(0,1),(1,0),(1,1)]]
    elif args.kind=='slab':
        ci=args.slab_index
        traces=[trace_from_vals(v) for v in product(range(4), repeat=3) if v[ci] <= 1]
    elif args.kind=='mixed':
        h=((4,4,2,2),(4,4,2,2),(2,2,0,0),(2,2,0,0))
        traces=[trace_from_vals((x,y,z)) for x in range(4) for y in range(4) for z in range(h[x][y])]
    res=run(traces,args.K,forbid)
    print(json.dumps(res, sort_keys=True))
if __name__=='__main__': main()
