#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <exception>
#include <iostream>
#include <stdexcept>
#include <string>
#include <tuple>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
struct Bits{ uint64_t w[4]; };
static inline Bits bz(){ return Bits{{0,0,0,0}}; }
static inline bool empty(const Bits&a){return !(a.w[0]|a.w[1]|a.w[2]|a.w[3]);}
static inline Bits bor(const Bits&a,const Bits&b){return Bits{{a.w[0]|b.w[0],a.w[1]|b.w[1],a.w[2]|b.w[2],a.w[3]|b.w[3]}};}
static inline Bits band(const Bits&a,const Bits&b){return Bits{{a.w[0]&b.w[0],a.w[1]&b.w[1],a.w[2]&b.w[2],a.w[3]&b.w[3]}};}
static inline Bits bminus(const Bits&a,const Bits&b){return Bits{{a.w[0]&~b.w[0],a.w[1]&~b.w[1],a.w[2]&~b.w[2],a.w[3]&~b.w[3]}};}
static inline bool disjoint(const Bits&a,const Bits&b){return !((a.w[0]&b.w[0])|(a.w[1]&b.w[1])|(a.w[2]&b.w[2])|(a.w[3]&b.w[3]));}
static inline int popc(const Bits&a){return __builtin_popcountll(a.w[0])+__builtin_popcountll(a.w[1])+__builtin_popcountll(a.w[2])+__builtin_popcountll(a.w[3]);}
static inline bool subset(const Bits&a,const Bits&b){ // a subset b
    return ((a.w[0]&~b.w[0])|(a.w[1]&~b.w[1])|(a.w[2]&~b.w[2])|(a.w[3]&~b.w[3]))==0;
}
static inline bool eqb(const Bits&a,const Bits&b){return a.w[0]==b.w[0]&&a.w[1]==b.w[1]&&a.w[2]==b.w[2]&&a.w[3]==b.w[3];}
static inline void setbit(Bits&b,int i){ b.w[i>>6] |= 1ULL<<(i&63);}
static inline bool getbit(const Bits&b,int i){return (b.w[i>>6]>>(i&63))&1ULL;}
static inline vector<int> bits_indices(Bits a){ vector<int> out; for(int k=0;k<4;k++){ uint64_t x=a.w[k]; while(x){ int b=__builtin_ctzll(x); out.push_back(64*k+b); x&=x-1; }} return out;}

vector<array<int,4>> V4; unordered_map<int,int> idx4; // encode base4 integer -> index
Bits UP[256];
int enc(array<int,4> q){ return ((q[0]*4+q[1])*4+q[2])*4+q[3];}
bool leq(array<int,4>a,array<int,4>b){ for(int i=0;i<4;i++) if(a[i]>b[i]) return false; return true;}

vector<array<int,3>> perms3;
vector<Bits> baseClauses;
Bits baseForbidden;

vector<array<array<int,4>,3>> residual_matchings(const array<vector<int>,4>& occVals){
    array<vector<int>,4> avail;
    for(int j=0;j<4;j++) for(int v=0;v<4;v++) if(find(occVals[j].begin(), occVals[j].end(), v)==occVals[j].end()) avail[j].push_back(v);
    for(int j=0;j<4;j++) if(avail[j].size()<3) return {};
    auto comb3=[&](const vector<int>& a){ vector<array<int,3>> c; int n=a.size(); for(int i=0;i<n;i++) for(int j=i+1;j<n;j++) for(int k=j+1;k<n;k++) c.push_back({a[i],a[j],a[k]}); return c; };
    auto C0=comb3(avail[0]), C1=comb3(avail[1]), C2=comb3(avail[2]), C3=comb3(avail[3]);
    vector<array<array<int,4>,3>> out;
    for(auto vals0:C0) for(auto vals1:C1) for(auto vals2:C2) for(auto vals3:C3){
        vector<array<int,3>> P1, P2, P3;
        array<int,3> p;
        vector<int> b1={vals1[0],vals1[1],vals1[2]}; sort(b1.begin(),b1.end()); do{P1.push_back({b1[0],b1[1],b1[2]});}while(next_permutation(b1.begin(),b1.end()));
        vector<int> b2={vals2[0],vals2[1],vals2[2]}; sort(b2.begin(),b2.end()); do{P2.push_back({b2[0],b2[1],b2[2]});}while(next_permutation(b2.begin(),b2.end()));
        vector<int> b3={vals3[0],vals3[1],vals3[2]}; sort(b3.begin(),b3.end()); do{P3.push_back({b3[0],b3[1],b3[2]});}while(next_permutation(b3.begin(),b3.end()));
        for(auto p1:P1) for(auto p2:P2) for(auto p3:P3){
            array<array<int,4>,3> mat;
            for(int t=0;t<3;t++) mat[t]={vals0[t],p1[t],p2[t],p3[t]};
            out.push_back(mat);
        }
    }
    return out;
}

void init(){
    for(int a=0;a<4;a++)for(int b=0;b<4;b++)for(int c=0;c<4;c++)for(int d=0;d<4;d++){ array<int,4> q={a,b,c,d}; idx4[enc(q)]=V4.size(); V4.push_back(q); }
    for(int i=0;i<256;i++){ Bits m=bz(); for(int j=0;j<256;j++) if(leq(V4[i],V4[j])) setbit(m,j); UP[i]=m; }
    vector<int> vals={1,2,3}; sort(vals.begin(),vals.end()); do{ perms3.push_back({vals[0],vals[1],vals[2]}); }while(next_permutation(vals.begin(),vals.end()));
    // upper matching clauses
    for(auto p0:perms3) for(auto p1:perms3) for(auto p2:perms3){
        Bits m=bz(); for(int t=1;t<=3;t++){ array<int,4> q={t,p0[t-1],p1[t-1],p2[t-1]}; setbit(m, idx4[enc(q)]); } baseClauses.push_back(m);
    }
    baseForbidden=bz();
    for(int j=0;j<4;j++){ array<int,4> q={1,1,1,1}; q[j]=3; setbit(baseForbidden, idx4[enc(q)]); }
}

pair<vector<Bits>,Bits> build_trace(vector<int> vals){
    vector<Bits> clauses=baseClauses; Bits forbid=baseForbidden; int size=vals.size();
    vector<int> rem; for(int j=0;j<4;j++) if(j>=size) rem.push_back(j); // support first size coords
    int total=1; for(size_t k=0;k<rem.size();k++) total*=4;
    for(int code=0;code<total;code++){
        int x=code; array<int,4> q={0,0,0,0}; for(int j=0;j<size;j++) q[j]=vals[j]; for(int k=(int)rem.size()-1;k>=0;k--){ q[rem[k]]=x%4; x/=4; }
        setbit(forbid, idx4[enc(q)]);
    }
    for(int j=0;j<4;j++) for(int u=0;u<=1;u++){
        if(j<size && vals[j]==u) continue;
        array<vector<int>,4> occ;
        for(int k=0;k<size;k++) occ[k].push_back(vals[k]);
        occ[j].push_back(u); sort(occ[j].begin(),occ[j].end()); occ[j].erase(unique(occ[j].begin(),occ[j].end()),occ[j].end());
        auto mats=residual_matchings(occ);
        for(auto &mat:mats){ Bits m=bz(); for(auto&q:mat) setbit(m, idx4[enc(q)]); clauses.push_back(m); }
    }
    return {clauses,forbid};
}

struct Solver{
    vector<Bits> clauses; Bits forbidden, valid; int best; Bits bestmask; long long nodes=0, prlb=0, unit=0; bool infeas=false; chrono::steady_clock::time_point start; double timelimit=1e9;
    Solver(vector<Bits> cls, Bits forb, int target): forbidden(forb), best(target){
        valid=bz(); for(int i=0;i<256;i++) if(disjoint(UP[i],forbidden)) setbit(valid,i);
        vector<Bits> tmp; tmp.reserve(cls.size());
        for(auto c:cls){ Bits cc=band(c,valid); if(empty(cc)){ infeas=true; return;} tmp.push_back(cc); }
        // unique
        sort(tmp.begin(), tmp.end(), [](const Bits&a,const Bits&b){ int pa=popc(a), pb=popc(b); if(pa!=pb) return pa<pb; for(int k=0;k<4;k++) if(a.w[k]!=b.w[k]) return a.w[k]<b.w[k]; return false;});
        vector<Bits> uni; for(auto c:tmp){ if(uni.empty() || !eqb(c,uni.back())) uni.push_back(c); }
        vector<Bits> red;
        for(auto c:uni){ bool redundant=false; for(auto r:red){ if(subset(r,c)){ redundant=true; break; } } if(!redundant) red.push_back(c); }
        clauses=std::move(red); bestmask=bz(); start=chrono::steady_clock::now();
    }
    bool timeout(){ return chrono::duration<double>(chrono::steady_clock::now()-start).count()>timelimit; }
    bool propagate(Bits &M){
        bool changed=true;
        while(changed){ changed=false; for(auto cl:clauses){ if(!disjoint(cl,M)) continue; Bits cc=bminus(cl,M); if(empty(cc)) return false; if(popc(cc)==1){ int i=bits_indices(cc)[0]; Bits U=UP[i]; if(!disjoint(U,forbidden)) return false; Bits M2=bor(M,U); if(popc(M2)>=best) return false; if(!eqb(M2,M)){M=M2; changed=true; unit++; break;} } } }
        return true;
    }
    int lower_bound(const Bits&M){
        vector<Bits> rem; rem.reserve(clauses.size());
        for(auto cl:clauses){ if(!disjoint(cl,M)) continue; Bits cc=bminus(cl,M); if(empty(cc)) return 1000000; rem.push_back(cc); }
        sort(rem.begin(), rem.end(), [](const Bits&a,const Bits&b){return popc(a)<popc(b);});
        Bits used=bz(); int lb=0; for(auto cc:rem){ if(disjoint(cc,used)){ used=bor(used,cc); lb++; } }
        return lb;
    }
    int hit_count(const Bits&U,const Bits&M){ int h=0; for(auto cl:clauses) if(disjoint(cl,M) && !disjoint(cl,U)) h++; return h; }
    void dfs(Bits M){
        nodes++; if((nodes%10000000)==0) cerr<<"nodes "<<nodes<<" best "<<best<<" cur "<<popc(M)<<" prlb "<<prlb<<"\n";
        if(timeout()) throw runtime_error("timeout");
        if(!propagate(M)) return; int c=popc(M); if(c>=best) return; int lb=lower_bound(M); if(c+lb>=best){ prlb++; return; }
        bool done=true; Bits chosen=bz(); vector<tuple<int,int,Bits,int>> bestc; int bestlen=1e9;
        for(auto cl:clauses){ if(!disjoint(cl,M)) continue; done=false; Bits cc=bminus(cl,M); vector<tuple<int,int,Bits,int>> cands; for(int i:bits_indices(cc)){ Bits U=UP[i]; if(!disjoint(U,forbidden)) continue; Bits NM=bor(M,U); int nc=popc(NM); if(nc<best){ int hit=hit_count(U,M); cands.emplace_back(nc-c,-hit,U,i); } }
            if(cands.empty()) return; if((int)cands.size()<bestlen){ bestlen=cands.size(); bestc=std::move(cands); if(bestlen==1) break; } }
        if(done){ best=c; bestmask=M; cerr<<"new best "<<best<<" nodes "<<nodes<<" prlb "<<prlb<<"\n"; return; }
        sort(bestc.begin(), bestc.end(), [](auto&a,auto&b){ if(get<0>(a)!=get<0>(b)) return get<0>(a)<get<0>(b); return get<1>(a)<get<1>(b);});
        vector<Bits> seen;
        for(auto &tu:bestc){ Bits U=get<2>(tu); Bits NM=bor(M,U); bool dup=false; for(auto&s:seen) if(eqb(s,NM)){dup=true;break;} if(dup) continue; seen.push_back(NM); dfs(NM); }
    }
};

int main(int argc,char**argv){
    ios::sync_with_stdio(false); cin.tie(nullptr);
    init(); vector<int> vals; int target=999; double tl=1e9;
    for(int i=1;i<argc;i++){ string a=argv[i]; if(a=="--target" && i+1<argc) target=stoi(argv[++i]); else if(a=="--time" && i+1<argc) tl=stod(argv[++i]); else vals.push_back(stoi(a)); }
    auto [clauses,forbid]=build_trace(vals); Solver S(clauses,forbid,target); S.timelimit=tl;
    cout<<"trace"; for(int v:vals) cout<<" "<<v; cout<<" clauses_raw="<<clauses.size()<<" clauses_reduced="<<S.clauses.size()<<" forbid="<<popc(forbid)<<" valid="<<popc(S.valid)<<" target="<<target<<"\n";
    if(S.infeas){ cout<<"initial_infeasible best=None\n"; return 0; }
    try{ Bits M=bz(); S.dfs(M); }catch(exception&e){ cout<<"TIMEOUT nodes="<<S.nodes<<" best="<<S.best<<"\n"; return 2; }
    cout<<"result best="<<(S.best>=999?-1:S.best)<<" nodes="<<S.nodes<<" prlb="<<S.prlb<<" unit="<<S.unit<<"\n";
    return 0;
}
