#!/usr/bin/env python3
from __future__ import annotations
from itertools import product, permutations, combinations
from functools import lru_cache
from typing import Dict, Tuple, List
import sys, time
V4=list(product(range(4), repeat=4)); IDX={q:i for i,q in enumerate(V4)}
def leq(a,b): return all(x<=y for x,y in zip(a,b))
UP=[0]*256; DOWN=[0]*256
for i,q in enumerate(V4):
    um=dm=0
    for j,p in enumerate(V4):
        if leq(q,p): um|=1<<j
        if leq(p,q): dm|=1<<j
    UP[i]=um; DOWN[i]=dm
# base upper matching constraints, actual points that must contain at least one missing point
UPPER=[]
perms=list(permutations((1,2,3)))
for p0 in perms:
  for p1 in perms:
    for p2 in perms:
      pts=[(t,p0[t-1],p1[t-1],p2[t-1]) for t in (1,2,3)]
      m=0
      for q in pts: m |= 1<<IDX[q]
      UPPER.append(m)
# base forbidden actual non-missing points (then take downclosure for generators/actual M)
NO_TOP=[(3,1,1,1),(1,3,1,1),(1,1,3,1),(1,1,1,3)]
BASE_FORB=0
for q in NO_TOP: BASE_FORB |= DOWN[IDX[q]]
@lru_cache(maxsize=None)
def residual_constraints_key(key: Tuple[Tuple[int,...],...]) -> Tuple[int,...]:
    occ={j:set(key[j]) for j in range(4)}
    avail=[[v for v in range(4) if v not in occ.get(j,set())] for j in range(4)]
    if any(len(a)<3 for a in avail): return tuple()
    out=[]
    for vals0 in combinations(avail[0],3):
      for vals1 in combinations(avail[1],3):
        for vals2 in combinations(avail[2],3):
          for vals3 in combinations(avail[3],3):
            for p1 in permutations(vals1):
              for p2 in permutations(vals2):
                for p3 in permutations(vals3):
                  m=0
                  for t in range(3):
                    q=(vals0[t], p1[t], p2[t], p3[t])
                    m |= 1<<IDX[q]
                  out.append(m)
    # duplicate constraints not needed at this level
    return tuple(sorted(set(out), key=lambda x:(x.bit_count(),x)))

def build_problem(traces: List[Dict[int,int]], extra_forbidden: int = 0):
    forbidden=BASE_FORB | extra_forbidden
    constraints=list(UPPER)
    for tr in traces:
        supp=set(tr); rem=[j for j in range(4) if j not in supp]
        # closure: every extension of present trace is present, so forbidden as actual M; include downclosure
        for addvals in product(range(4), repeat=len(rem)):
            q=[0]*4
            for j,v in tr.items(): q[j]=v
            for j,v in zip(rem, addvals): q[j]=v
            forbidden |= DOWN[IDX[tuple(q)]]
        # residual seed cuts
        for j in range(4):
            for u in (0,1):
                if tr.get(j, None)==u: continue
                occ={col:{val} for col,val in tr.items()}
                occ.setdefault(j,set()).add(u)
                key=tuple(tuple(sorted(occ.get(k,set()))) for k in range(4))
                constraints.extend(residual_constraints_key(key))
    return forbidden, constraints

def minimize_upset_hitting(traces: List[Dict[int,int]], K: int, need_solution=False, verbose=False, extra_forbidden: int = 0):
    """Return (feasible, solution_mask_or_None, stats). Feasible means some up-set M of size <=K exists.
    extra_forbidden is a mask of actual points required not to be in M; down-closure is applied by caller or can be actual by passing DOWN[idx].
    """
    forbidden,constraints=build_problem(traces, extra_forbidden)
    # Valid generator p: choosing p and its upclosure does not include a forbidden point.
    valid_mask=0
    for i in range(256):
        if (UP[i] & forbidden)==0:
            valid_mask |= 1<<i
    # Remove duplicate constraints and constraints that can be ignored if already hit by forbidden? No actual M cannot include forbidden.
    cons=[]
    cand=[]
    for C in constraints:
        # actual points in C that are forbidden cannot be in M, but can be removed for hit purposes
        C2=C & ~forbidden
        # Candidate generators whose upclosure includes at least one point in C2.
        cm=0; x=C2
        while x:
            l=x & -x; qi=l.bit_length()-1; x-=l
            cm |= DOWN[qi]
        cm &= valid_mask
        if cm==0:
            return False, None, {'reason':'empty_constraint','n_constraints':len(constraints),'valid':valid_mask.bit_count()}
        cons.append(C2); cand.append(cm)
    # Deduplicate constraints by actual mask and remove constraints hit-implied by others? If C1 subset C2, hitting C1 implies hitting C2, but with generators lower maybe if M actual intersects C1 then C2. yes C2 redundant.
    items=sorted(set(cons), key=lambda c:(c.bit_count(), c))
    reduced=[]
    for c in items:
        if any((r & c)==r for r in reduced):
            continue
        reduced.append(c)
    cons=reduced
    # rebuild cand for reduced
    cand=[]
    for C2 in cons:
        cm=0; x=C2
        while x:
            l=x & -x; qi=l.bit_length()-1; x-=l
            cm |= DOWN[qi]
        cm &= valid_mask
        cand.append(cm)
    n=len(cons)
    full_hit=(1<<n)-1
    # Precompute hit-by-generator bitset for each generator.
    hit_by_gen=[0]*256
    for gi in range(256):
        if not ((valid_mask>>gi)&1): continue
        u=UP[gi]
        hm=0
        for k,C in enumerate(cons):
            if u & C: hm |= 1<<k
        hit_by_gen[gi]=hm
    t0=time.time(); nodes=0; memo=set(); solution=None
    sys.setrecursionlimit(1000000)
    # Greedy packing lower bound: choose unhit constraints with pairwise disjoint candidate actual? Simpler use one min added cost per unhit selected disjoint actual C maybe.
    def dfs(M:int, hitmask:int):
        nonlocal nodes, solution
        nodes += 1
        if M.bit_count()>K: return False
        if hitmask==full_hit:
            solution=M; return True
        key=(M,hitmask)
        if key in memo: return False
        if verbose and nodes%200000==0:
            print('nodes',nodes,'cost',M.bit_count(),'hit',hitmask.bit_count(),'/',n,'memo',len(memo),'time',time.time()-t0, file=sys.stderr, flush=True)
        # choose unhit constraint with smallest number of distinct next states
        rem=full_hit^hitmask
        best_adds=None; best_score=None
        tmp=rem
        while tmp:
            l=tmp & -tmp; k=l.bit_length()-1; tmp-=l
            cm=cand[k]
            # Generate distinct next states from candidates. Keep only states <=K.
            adds=[]; seen=set(); x=cm
            while x:
                b=x & -x; gi=b.bit_length()-1; x-=b
                newM=M | UP[gi]
                if newM==M: continue
                if newM.bit_count()>K: continue
                if newM & forbidden: continue
                if newM not in seen:
                    seen.add(newM); adds.append((newM, hit_by_gen[gi]))
            if not adds:
                memo.add(key); return False
            score=(len(adds), cons[k].bit_count())
            if best_score is None or score<best_score:
                best_score=score; best_adds=adds
                if score[0]==1: break
        cost0=M.bit_count()
        # sort by small added cost then more newly hit constraints
        best_adds.sort(key=lambda item: ((item[0].bit_count()-cost0), -((item[1]&~hitmask).bit_count()), item[0]))
        # remove dominated next states: if A subset B and hits(A)>=hits(B)? skip B. Simple pairwise for small list.
        pruned=[]
        for newM,hadd in best_adds:
            dominated=False
            nh=hitmask|hadd
            for oldM, oldh in pruned:
                if (oldM | newM)==newM and ((hitmask|oldh) | nh)==(hitmask|oldh):
                    dominated=True; break
            if not dominated:
                pruned.append((newM,hadd))
        for newM,hadd in pruned:
            if dfs(newM, hitmask|hadd): return True
        memo.add(key); return False
    ok=dfs(0,0)
    stats={'nodes':nodes,'memo':len(memo),'n_constraints':n,'valid_generators':valid_mask.bit_count(),'forbidden_points':forbidden.bit_count(),'time':time.time()-t0}
    return ok, solution if ok and need_solution else None, stats

if __name__=='__main__':
    # Usage: exact_upset_hitting.py vals_comma K, e.g. 0,0,0 33
    vals=tuple(map(int, sys.argv[1].split(',')))
    K=int(sys.argv[2])
    tr={i:vals[i] for i in range(len(vals))}
    ok, sol, st = minimize_upset_hitting([tr], K, need_solution=True, verbose=True)
    print('feasible', ok, 'vals', vals, 'K', K, 'size', None if sol is None else sol.bit_count(), 'stats', st)
