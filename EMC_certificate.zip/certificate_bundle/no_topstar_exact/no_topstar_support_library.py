#!/usr/bin/env python3
"""
Verifier for the full no-top-star branch certificate in the 19-board Layer 1 inequality.

Target certified statement.
Under the no-top-star upper-core branch hypotheses, every actual 19-board satisfies
    300*T3 + 144*P2 <= 625*M4,
where M4 is the number of all missing wide quads in [4]^4, T3 is the number of
present wide triples, and P2 is the number of present wide pairs.

This closes the previous gap: the old availability checker only considered blockers in
the upper cube, while this verifier accounts for lower missing quads through residual
seed cuts and a finite critical-case analysis.

The certificate logic is:
  1. If M >= 67, the global Ferrers bounds T3<=128, P2<=24 imply the target.
  2. If 33 <= M <= 63, the trace-minimum table in the JSON certificate bounds the
     maximum legal pair/triple down-set on each support; arithmetic gives the target.
  3. If 64 <= M <= 66 and no support is extremal, then T_support<=31 and
     P_support<=3, so the target follows.
  4. If an extremal support occurs (triple size 32 or pair size 4), the certified
     rectangular-forcing claims imply M contains a rectangle R_ab={q:q_a>=2,q_b>=2}.
     The verifier enumerates every up-set extension of such a rectangle of total
     size at most 66, computes exact trace maxima using full residual cuts, and checks
     the target in every case.

By default the verifier runs both the arithmetic skeleton and the critical MILP audit
for the rectangular-forcing claims.  Use --quick-only to skip the MILP audit.
The slower --audit-trace-minima option recomputes every individual trace minimum;
for routine archival checks use the auxiliary sorted-minima scripts instead.
"""
from __future__ import annotations

import argparse
import json
import math
import pathlib
from functools import lru_cache
from itertools import combinations, permutations, product
from typing import Dict, Iterable, List, Sequence, Set, Tuple

V2 = list(product(range(4), repeat=2))
V3 = list(product(range(4), repeat=3))
V4 = list(product(range(4), repeat=4))
IDX2 = {p: i for i, p in enumerate(V2)}
IDX3 = {p: i for i, p in enumerate(V3)}
IDX4 = {p: i for i, p in enumerate(V4)}
TSUPPS = list(combinations(range(4), 3))
PSUPPS = list(combinations(range(4), 2))
U = [q for q in V4 if all(v >= 1 for v in q)]

def require(cond: bool, msg: str) -> None:
    if not cond:
        raise RuntimeError(msg)


def leq(a: Sequence[int], b: Sequence[int]) -> bool:
    return all(x <= y for x, y in zip(a, b))


def is_downset2(S: Iterable[Tuple[int, int]]) -> bool:
    S = set(S)
    for x, y in list(S):
        for a in range(x + 1):
            for b in range(y + 1):
                if (a, b) not in S:
                    return False
    return True


def pair_bad(a: Tuple[int, int], b: Tuple[int, int]) -> bool:
    return (
        a[0] != b[0]
        and a[1] != b[1]
        and any((0 not in {a[i], b[i]} or 1 not in {a[i], b[i]}) for i in range(2))
    )


def legal_pair_downsets() -> List[Set[Tuple[int, int]]]:
    out: List[Set[Tuple[int, int]]] = []
    for mask in range(1 << 16):
        S = {V2[i] for i in range(16) if (mask >> i) & 1}
        if is_downset2(S) and not any(pair_bad(a, b) for a, b in combinations(S, 2)):
            out.append(S)
    return out


def is_bad_triple_matching(points: Sequence[Tuple[int, int, int]]) -> bool:
    if any(len({p[j] for p in points}) < 3 for j in range(3)):
        return False
    for j in range(3):
        unused = ({0, 1, 2, 3} - {p[j] for p in points})
        if len(unused) == 1 and next(iter(unused)) in {0, 1}:
            return True
    return False


def generate_heights():
    h = [[0] * 4 for _ in range(4)]

    def rec(pos: int):
        if pos == 16:
            yield tuple(tuple(row) for row in h)
            return
        i, j = divmod(pos, 4)
        maxv = 4
        if i > 0:
            maxv = min(maxv, h[i - 1][j])
        if j > 0:
            maxv = min(maxv, h[i][j - 1])
        for val in range(maxv, -1, -1):
            h[i][j] = val
            yield from rec(pos + 1)

    yield from rec(0)


def mask_from_height(h) -> int:
    m = 0
    for x in range(4):
        for y in range(4):
            for z in range(h[x][y]):
                m |= 1 << IDX3[(x, y, z)]
    return m


def closure_mask(points: Sequence[Tuple[int, int, int]]) -> int:
    m = 0
    for x, y, z in points:
        for a in range(x + 1):
            for b in range(y + 1):
                for c in range(z + 1):
                    m |= 1 << IDX3[(a, b, c)]
    return m


def legal_triple_downsets() -> List[Tuple[int, int, tuple]]:
    bad_matchings = [c for c in combinations(V3, 3) if is_bad_triple_matching(c)]
    forb = sorted(set(closure_mask(c) for c in bad_matchings))
    minimal: List[int] = []
    for f in forb:
        if not any(g != f and (f & g) == g for g in forb):
            minimal.append(f)
    out: List[Tuple[int, int, tuple]] = []
    for h in generate_heights():
        mask = mask_from_height(h)
        if not any((mask & f) == f for f in minimal):
            out.append((sum(map(sum, h)), mask, h))
    return out


def min_table(cert_entries: List[dict]) -> Dict[Tuple[int, ...], int]:
    big = 10**9
    ans: Dict[Tuple[int, ...], int] = {}
    for x in cert_entries:
        vals = tuple(x["vals"])
        ans[vals] = int(x["M"]) if x.get("ok") else big
    return ans


def threshold_maxima(pair_min: Dict[Tuple[int, int], int], tri_min: Dict[Tuple[int, int, int], int]):
    pairs = legal_pair_downsets()
    triples = legal_triple_downsets()
    pmax, tmax = {}, {}
    for m in range(33, 67):
        allowed_p = {p for p, mu in pair_min.items() if mu <= m}
        pmax[m] = max((len(S) for S in pairs if S <= allowed_p), default=0)
        allowed_t_mask = 0
        for p, mu in tri_min.items():
            if mu <= m:
                allowed_t_mask |= 1 << IDX3[p]
        tmax[m] = max((size for size, mask, _h in triples if (mask & ~allowed_t_mask) == 0), default=0)
    return pmax, tmax


@lru_cache(maxsize=None)
def residual_matchings_key(key: Tuple[Tuple[int, ...], ...]) -> Tuple[Tuple[Tuple[int, int, int, int], ...], ...]:
    occ = {j: set(key[j]) for j in range(4)}
    avail = [[v for v in range(4) if v not in occ.get(j, set())] for j in range(4)]
    if any(len(a) < 3 for a in avail):
        return tuple()
    out = []
    for vals0 in combinations(avail[0], 3):
        for vals1 in combinations(avail[1], 3):
            for vals2 in combinations(avail[2], 3):
                for vals3 in combinations(avail[3], 3):
                    for p1 in permutations(vals1):
                        for p2 in permutations(vals2):
                            for p3 in permutations(vals3):
                                out.append(
                                    tuple((vals0[t], p1[t], p2[t], p3[t]) for t in range(3))
                                )
    return tuple(out)


def trace_allowed(M: Set[Tuple[int, int, int, int]], supp: Tuple[int, ...], vals: Tuple[int, ...]) -> bool:
    d = dict(zip(supp, vals))
    rem = [j for j in range(4) if j not in d]
    # Closure: every wide extension of a present trace must be present, i.e. not in M.
    for add_vals in product(range(4), repeat=len(rem)):
        q = [None] * 4
        for j, v in d.items():
            q[j] = v
        for j, v in zip(rem, add_vals):
            q[j] = v
        if tuple(q) in M:
            return False
    # Full residual seed cuts: every residual 3-matching disjoint from H and each seed is hit by M.
    for j in range(4):
        for u in (0, 1):
            if d.get(j, None) == u:
                continue
            occ = {col: {val} for col, val in d.items()}
            occ.setdefault(j, set()).add(u)
            key = tuple(tuple(sorted(occ.get(k, set()))) for k in range(4))
            for mat in residual_matchings_key(key):
                if all(q not in M for q in mat):
                    return False
    return True


def rect(a: int, b: int) -> Set[Tuple[int, int, int, int]]:
    return {q for q in V4 if q[a] >= 2 and q[b] >= 2}


def upclosure(q: Tuple[int, int, int, int]) -> Set[Tuple[int, int, int, int]]:
    return {p for p in V4 if leq(q, p)}


def is_upset(M: Set[Tuple[int, int, int, int]]) -> bool:
    for q in M:
        for p in V4:
            if leq(q, p) and p not in M:
                return False
    return True


def no_full_topstar(M: Set[Tuple[int, int, int, int]]) -> bool:
    for j in range(4):
        q = [1, 1, 1, 1]
        q[j] = 3
        if tuple(q) in M:
            return False
    return True


def hits_upper_matchings(M: Set[Tuple[int, int, int, int]]) -> bool:
    for perms in product(permutations((1, 2, 3)), repeat=3):
        pts = [(t, perms[0][t - 1], perms[1][t - 1], perms[2][t - 1]) for t in (1, 2, 3)]
        if all(p not in M for p in pts):
            return False
    return True


def enumerate_rectangle_extensions() -> List[Set[Tuple[int, int, int, int]]]:
    cases: Dict[Tuple[Tuple[int, int, int, int], ...], Set[Tuple[int, int, int, int]]] = {}
    for a, b in combinations(range(4), 2):
        R = rect(a, b)
        closures = []
        for q in V4:
            if q not in R:
                C = frozenset(upclosure(q) - R)
                if 1 <= len(C) <= 2:
                    closures.append(C)
        closures = sorted(set(closures), key=lambda s: (len(s), sorted(s)))
        extras = {frozenset()}
        for c in closures:
            if len(c) <= 2:
                extras.add(c)
        for c1, c2 in combinations(closures, 2):
            u = c1 | c2
            if len(u) <= 2:
                extras.add(frozenset(u))
        for E in extras:
            M = R | set(E)
            if len(M) <= 66 and is_upset(M) and no_full_topstar(M) and hits_upper_matchings(M):
                cases[tuple(sorted(M))] = M
    return list(cases.values())


def max_counts_for_M(M: Set[Tuple[int, int, int, int]], pairs, triples) -> Tuple[int, int, list]:
    Tsum = 0
    Psum = 0
    details = []
    for supp in TSUPPS:
        allowed_mask = 0
        for vals in V3:
            if trace_allowed(M, supp, vals):
                allowed_mask |= 1 << IDX3[vals]
        best = max((size for size, mask, _h in triples if (mask & ~allowed_mask) == 0), default=0)
        Tsum += best
        details.append(("T", supp, best))
    for supp in PSUPPS:
        allowed = {vals for vals in V2 if trace_allowed(M, supp, vals)}
        best = max((len(S) for S in pairs if S <= allowed), default=0)
        Psum += best
        details.append(("P", supp, best))
    return Tsum, Psum, details


def quick_verify(cert_path: pathlib.Path) -> dict:
    cert = json.loads(cert_path.read_text(encoding="utf-8"))
    pair_min = min_table(cert["pair_trace_minM"])
    tri_min = min_table(cert["triple_trace_minM"])
    pairs = legal_pair_downsets()
    triples = legal_triple_downsets()
    require(len(pairs) == 10, f"unexpected pair down-set count {len(pairs)}")
    require(len(triples) == 26893, f"unexpected triple legal down-set count {len(triples)}")
    pmax, tmax = threshold_maxima(pair_min, tri_min)

    # Range M>=67: crude Ferrers bound from pair/triple certificates.
    require(300 * 128 + 144 * 24 < 625 * 67, "large-M Ferrers arithmetic failed")

    low_range_rows = []
    for m in range(33, 64):
        lhs = 300 * 4 * tmax[m] + 144 * 6 * pmax[m]
        rhs = 625 * m
        low_range_rows.append((m, pmax[m], tmax[m], lhs, rhs, lhs <= rhs))
        require(lhs <= rhs, f"low-range arithmetic failure: {(m, pmax[m], tmax[m], lhs, rhs)}")

    # Critical range without extremal supports.
    # If no triple support has size 32 and no pair support has size 4, then
    # T_support<=31 and P_support<=3 on each support.
    no_extremal_lhs = 300 * (4 * 31) + 144 * (6 * 3)
    require(no_extremal_lhs <= 625 * 64, "non-extremal M=64 arithmetic failed")

    # Critical range with an extremal support: enumerate all up-set extensions of rectangles.
    cases = enumerate_rectangle_extensions()
    max_obj = -10**18
    max_case = None
    for M in cases:
        Tsum, Psum, details = max_counts_for_M(M, pairs, triples)
        obj = 300 * Tsum + 144 * Psum - 625 * len(M)
        if obj > max_obj:
            max_obj = obj
            max_case = (len(M), Tsum, Psum, obj, details, sorted(M)[:8])
        require(obj <= 0, f"rectangle extension objective failure: {(len(M), Tsum, Psum, obj, details)}")

    expected = cert["rectangle_case_bound"]
    require(len(cases) == int(expected["cases_expected"]), f"unexpected rectangle case count: {(len(cases), expected)}")
    require(max_obj == int(expected["max_objective"]), f"unexpected rectangle max objective: {(max_obj, expected)}")
    return {
        "pair_legal_downsets": len(pairs),
        "triple_legal_downsets": len(triples),
        "threshold_rows": low_range_rows,
        "no_extremal_lhs_at_M64": no_extremal_lhs,
        "rectangle_cases": len(cases),
        "rectangle_max_case": max_case,
    }


# ---- Optional MILP audits for critical pattern claims ----

def run_milp_audit(cert_path: pathlib.Path, audit_trace_minima: bool = False):
    import numpy as np
    from scipy.optimize import Bounds, LinearConstraint, milp
    from scipy.sparse import lil_matrix

    cert = json.loads(cert_path.read_text(encoding="utf-8"))
    base_rows, base_lb, base_ub = [], [], []

    def add_base(coeff, lo=-np.inf, hi=np.inf):
        base_rows.append(coeff)
        base_lb.append(lo)
        base_ub.append(hi)

    # M up-set.
    for q in V4:
        for j in range(4):
            if q[j] < 3:
                qq = list(q)
                qq[j] += 1
                qq = tuple(qq)
                add_base({IDX4[q]: 1, IDX4[qq]: -1}, hi=0)
    # No present upper 3-matching: each upper matching is hit by M.
    for perms in product(permutations((1, 2, 3)), repeat=3):
        pts = [(t, perms[0][t - 1], perms[1][t - 1], perms[2][t - 1]) for t in (1, 2, 3)]
        add_base({IDX4[p]: 1 for p in pts}, lo=1)
    # No full top-star in M_U.
    for j in range(4):
        q = [1, 1, 1, 1]
        q[j] = 3
        add_base({IDX4[tuple(q)]: 1}, hi=0)

    def rows_for_trace(trace: Dict[int, int]):
        rows, lows, ups = [], [], []

        def add(coeff, lo=-np.inf, hi=np.inf):
            rows.append(coeff)
            lows.append(lo)
            ups.append(hi)

        supp = set(trace)
        rem = [j for j in range(4) if j not in supp]
        for vals in product(range(4), repeat=len(rem)):
            q = [None] * 4
            for j, v in trace.items():
                q[j] = v
            for j, v in zip(rem, vals):
                q[j] = v
            add({IDX4[tuple(q)]: 1}, hi=0)
        for j in range(4):
            for u in (0, 1):
                if trace.get(j, None) == u:
                    continue
                occ = {col: {val} for col, val in trace.items()}
                occ.setdefault(j, set()).add(u)
                key = tuple(tuple(sorted(occ.get(k, set()))) for k in range(4))
                for mat in residual_matchings_key(key):
                    add({IDX4[q]: 1 for q in mat}, lo=1)
        return rows, lows, ups

    def solve_trace_set(traces: List[Dict[int, int]], extra_rows=None, extra_lb=None, extra_ub=None, objective="minM"):
        rows = list(base_rows)
        lows = list(base_lb)
        ups = list(base_ub)
        for tr in traces:
            r, l, u = rows_for_trace(tr)
            rows += r
            lows += l
            ups += u
        if extra_rows:
            rows += extra_rows
            lows += extra_lb
            ups += extra_ub
        A = lil_matrix((len(rows), len(V4)), dtype=float)
        for i, row in enumerate(rows):
            for j, v in row.items():
                A[i, j] = v
        c = np.ones(len(V4))
        res = milp(
            c=c,
            integrality=np.ones(len(V4)),
            bounds=Bounds(0, 1),
            constraints=LinearConstraint(A.tocsr(), np.array(lows), np.array(ups)),
            options={"time_limit": 300, "mip_rel_gap": 0},
        )
        return res

    def total_le(m: int):
        return [{i: 1 for i in range(len(V4))}], [-np.inf], [m]

    def not_rect_row(a: int, b: int):
        return [{IDX4[q]: 1 for q in rect(a, b)}], [-np.inf], [63]

    def pair_square_traces(supp=(0, 1)):
        return [dict(zip(supp, vals)) for vals in [(0, 0), (0, 1), (1, 0), (1, 1)]]

    def tri_slab_traces(coord_index: int, supp=(0, 1, 2)):
        return [dict(zip(supp, vals)) for vals in V3 if vals[coord_index] <= 1]

    def tri_mixed_traces(supp=(0, 1, 2)):
        h = ((4, 4, 2, 2), (4, 4, 2, 2), (2, 2, 0, 0), (2, 2, 0, 0))
        return [dict(zip(supp, (x, y, z))) for x in range(4) for y in range(4) for z in range(h[x][y])]

    claims = [
        ("pair_size4_square", pair_square_traces(), (0, 1), 64),
        ("triple_size32_slab_0", tri_slab_traces(0), (0, 3), 64),
        ("triple_size32_slab_1", tri_slab_traces(1), (1, 3), 64),
        ("triple_size32_slab_2", tri_slab_traces(2), (2, 3), 64),
        ("triple_size32_mixed", tri_mixed_traces(), None, 80),
    ]
    print("MILP audit of critical rectangular-forcing claims")
    for name, traces, forced_rect, expected_min in claims:
        res = solve_trace_set(traces)
        print(f"  {name}: minM={None if res.fun is None else round(res.fun)} success={res.success}")
        require(res.success and round(res.fun) == expected_min, f"critical forcing minimum mismatch: {(name, res.fun, expected_min)}")
        er, el, eu = total_le(66)
        if forced_rect is not None:
            nr, nl, nu = not_rect_row(*forced_rect)
            res2 = solve_trace_set(traces, er + nr, el + nl, eu + nu)
            print(f"    with M<=66 and not R{forced_rect}: success={res2.success} ({res2.message})")
            require(not res2.success, f"critical forcing rectangle exclusion unexpectedly feasible: {name}")
        else:
            res2 = solve_trace_set(traces, er, el, eu)
            print(f"    with M<=66: success={res2.success} ({res2.message})")
            require(not res2.success, f"mixed critical pattern unexpectedly feasible: {name}")

    if audit_trace_minima:
        # Slow archival audit: recompute all individual trace minima and compare with JSON.
        pair_min = min_table(cert["pair_trace_minM"])
        tri_min = min_table(cert["triple_trace_minM"])
        print("Slow audit of individual trace-minimum tables")
        for size, table in [(2, pair_min), (3, tri_min)]:
            for vals in product(range(4), repeat=size):
                trace = {i: vals[i] for i in range(size)}
                res = solve_trace_set([trace])
                got = None if not res.success else round(res.fun)
                exp = None if table[vals] >= 10**9 else table[vals]
                print(f"  size={size} vals={vals} minM={got} expected={exp}")
                require(got == exp, f"trace-minimum audit mismatch: {(size, vals, got, exp)}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cert", default=str(pathlib.Path(__file__).resolve().parent / "no_topstar_full_certificate.json"))
    ap.add_argument("--quick-only", action="store_true", help="only verify the arithmetic skeleton; skip the default critical MILP audit")
    ap.add_argument("--milp-audit", action="store_true", help="kept for backward compatibility; the critical MILP audit now runs by default unless --quick-only is set")
    ap.add_argument("--audit-trace-minima", action="store_true", help="also recompute every individual trace minimum; very slow, usually replaced by the sorted-minima audit scripts")
    args = ap.parse_args()
    cert_path = pathlib.Path(args.cert)
    result = quick_verify(cert_path)
    print("quick_certificate_ok=True")
    print(f"pair_legal_downsets={result['pair_legal_downsets']}")
    print(f"triple_legal_downsets={result['triple_legal_downsets']}")
    print("low_range_rows: m pmax_per_support tmax_per_support lhs rhs ok")
    for row in result["threshold_rows"]:
        print("  ", *row)
    print(f"no_extremal_lhs_at_M64={result['no_extremal_lhs_at_M64']} rhs={625*64}")
    print(f"rectangle_cases={result['rectangle_cases']}")
    print(f"rectangle_max_case={result['rectangle_max_case']}")
    if args.quick_only:
        print("arithmetic_skeleton_ok=True")
        print("critical_milp_audit_skipped=True")
    else:
        run_milp_audit(cert_path, audit_trace_minima=args.audit_trace_minima)
        print("milp_audit_ok=True")
        print("full_no_topstar_certificate_ok=True")
        if not args.audit_trace_minima:
            print("trace_minima_audit_note=use trace_minima_sorted_pairs_audit.py and trace_minima_sorted_triples.py for the sorted-value trace-minimum audit")


if __name__ == "__main__":
    main()
