#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, pathlib
from itertools import product
HERE = pathlib.Path(__file__).resolve().parent
CERT = HERE / 'no_topstar_exact_threshold_certificate.json'
BASE = HERE / 'no_topstar_support_library.py'
spec = importlib.util.spec_from_file_location('base_no_topstar', BASE)
def require(cond, msg):
    if not cond:
        raise RuntimeError(msg)

base = importlib.util.module_from_spec(spec); require(spec.loader is not None, 'could not load support library'); spec.loader.exec_module(base)

def conservative_threshold_tables(cert):
    pair_sorted = {tuple(map(int,k.split(','))): int(v['threshold']) for k,v in cert['pair_thresholds_sorted'].items()}
    tri_sorted = {tuple(map(int,k.split(','))): int(v['threshold']) for k,v in cert['triple_thresholds_sorted'].items()}
    pair = {vals: pair_sorted[tuple(sorted(vals))] for vals in product(range(4), repeat=2)}
    tri = {vals: tri_sorted[tuple(sorted(vals))] for vals in product(range(4), repeat=3)}
    return pair, tri

def main():
    print('loading no_topstar arithmetic/rectangle verifier', flush=True)
    cert = json.loads(CERT.read_text())
    pair_thr, tri_thr = conservative_threshold_tables(cert)
    pairs = base.legal_pair_downsets()
    print(f'pair_legal_downsets={len(pairs)}', flush=True)
    triples = base.legal_triple_downsets()
    print(f'triple_legal_downsets={len(triples)}', flush=True)
    require(len(pairs) == 10, f'unexpected pair legal down-set count: {len(pairs)}')
    require(len(triples) == 26893, f'unexpected triple legal down-set count: {len(triples)}')
    rows=[]
    for m in range(33,64):
        allowed_p={p for p,t in pair_thr.items() if t<=m}
        pmax=max((len(S) for S in pairs if S <= allowed_p), default=0)
        allowed_t_mask=0
        for p,t in tri_thr.items():
            if t<=m: allowed_t_mask |= 1 << base.IDX3[p]
        tmax=max((size for size,mask,_ in triples if (mask & ~allowed_t_mask)==0), default=0)
        lhs=300*4*tmax + 144*6*pmax
        rhs=625*m
        require(lhs <= rhs, f'low-range arithmetic failure: {(m,pmax,tmax,lhs,rhs)}')
        rows.append((m,pmax,tmax,lhs,rhs))
    require(300*128+144*24 < 625*67, 'large-M Ferrers arithmetic failed')
    no_ext = 300*(4*31)+144*(6*3)
    require(no_ext <= 625*64, 'non-extremal M=64 arithmetic failed')
    print('checking low-range arithmetic', flush=True)
    cases = base.enumerate_rectangle_extensions()
    print(f'rectangle_candidate_cases={len(cases)}', flush=True)
    max_obj = -10**18; max_case=None
    for idx, M in enumerate(cases):
        if idx % 10 == 0:
            print(f'checking_rectangle_case={idx}', flush=True)
        Tsum,Psum,details = base.max_counts_for_M(M, pairs, triples)
        obj = 300*Tsum+144*Psum-625*len(M)
        if obj > max_obj:
            max_obj = obj; max_case = (len(M),Tsum,Psum,obj)
        require(obj <= 0, f'rectangle extension objective failure: {(len(M),Tsum,Psum,obj,details)}')
    expected = cert.get('rectangle_case_bound', {'cases_expected': 72, 'max_objective': -10624})
    require(len(cases) == int(expected['cases_expected']), f'unexpected rectangle case count: {len(cases)}')
    require(max_obj == int(expected['max_objective']), f'unexpected rectangle max objective: {max_obj}')
    print('no_topstar_arithmetic_rectangle')
    print('low_range_rows: m pmax_per_support tmax_per_support lhs rhs')
    for row in rows:
        print('  ' + ' '.join(map(str,row)))
    print(f'no_extremal_lhs_at_M64={no_ext} rhs={625*64}')
    print(f'rectangle_cases={len(cases)}')
    print(f'rectangle_max_case={max_case}')
    print('no_topstar_arithmetic_rectangle_ok=True')
if __name__ == '__main__':
    main()
