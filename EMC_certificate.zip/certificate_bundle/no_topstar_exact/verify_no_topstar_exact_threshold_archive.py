#!/usr/bin/env python3
"""Fast archive validator for the no-top-star exact threshold transcript.

This does not replace the slow exact branch-and-bound rerun.  It verifies that the
submitted transcript and summary contain the threshold, rectangle, and non-MILP
success markers used in the manuscript.  The slow rerun is available through
run_all_checks.sh --full-no-topstar.
"""
from pathlib import Path
import re
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
summary = ROOT / 'logs' / 'no_topstar_exact_threshold.log'
full = ROOT / 'logs' / 'no_topstar_exact_threshold_full_command.log'
if not summary.exists():
    summary = HERE / 'verify_no_topstar_exact_threshold_certificate.log'
if not full.exists():
    full = HERE / 'verify_no_topstar_exact_threshold_certificate.log'
S = summary.read_text(errors='replace')
F = full.read_text(errors='replace')
required_summary = [
    'black_box_milp_used=False',
    'trace_threshold_checks=30',
    'critical_pattern_checks=9',
    'no_extremal_lhs_at_M64=39792 rhs=40000',
    'rectangle_cases=72',
    'rectangle_max_case=(64, 96, 4, -10624)',
    'exact_no_topstar_threshold_certificate_ok=True',
]
missing = [x for x in required_summary if x not in S]
if missing:
    raise AssertionError('missing summary markers: ' + repr(missing))
# Check corrected low-range rows.
for row in [
    '  48 0 25 30000 30000',
    '  49 0 25 30000 30625',
    '  50 0 26 31200 31250',
    '  55 0 26 31200 34375',
    '  56 0 29 34800 35000',
    '  60 1 29 35664 37500',
    '  63 1 29 35664 39375',
]:
    if row not in S:
        raise AssertionError('missing low-range row: ' + row)
# The archived full transcript must include the exact search outcomes for the critical patterns.
required_full = [
    'result best=60',
    'result best=64',
    'initial_infeasible best=None',
    'pattern=pair_square',
    'pattern=triple_slab0',
    'pattern=triple_slab1',
    'pattern=triple_slab2',
    'pattern=triple_mixed',
]
missing_full = [x for x in required_full if x not in F]
if missing_full:
    raise AssertionError('missing full-transcript markers: ' + repr(missing_full))
print('no_topstar_exact_threshold_archive_ok=True')
print('summary_file=' + str(summary.relative_to(ROOT) if summary.is_relative_to(ROOT) else summary))
print('full_transcript_file=' + str(full.relative_to(ROOT) if full.is_relative_to(ROOT) else full))
