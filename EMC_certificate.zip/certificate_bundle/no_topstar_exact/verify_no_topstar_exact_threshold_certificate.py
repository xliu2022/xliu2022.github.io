#!/usr/bin/env python3
"""Exact non-MILP verifier for the repaired no-top-star residual branch.

This verifier removes the previous SciPy/HiGHS dependency from the no-top-star
branch. It compiles and runs two deterministic C++ branch-and-bound checkers.
The checkers use only integer bitsets, up-set closure, finite residual seed cuts,
and exhaustive branch-and-bound pruning. No black-box MILP solver is called.

A threshold statement `target=B` means the checker exhausts all cases with |M|<B.
If it returns `best=B`, then no feasible solution of size <B exists. If it returns
`best=A<B`, a feasible solution of size A was found and no smaller solution exists.
"""
from __future__ import annotations
import json, os, pathlib, re, subprocess, sys, importlib.util
from itertools import combinations_with_replacement, product

HERE = pathlib.Path(__file__).resolve().parent
CERT = HERE / 'no_topstar_exact_threshold_certificate.json'
TRACE_CPP = HERE / 'exact_no_topstar_hitting_solver.cpp'
PATTERN_CPP = HERE / 'exact_no_topstar_pattern_solver.cpp'
TRACE_BIN = HERE / 'exact_no_topstar_hitting_solver'
PATTERN_BIN = HERE / 'exact_no_topstar_pattern_solver'
BASE_PY = HERE / 'no_topstar_support_library.py'
if not BASE_PY.exists(): raise FileNotFoundError(BASE_PY)

def require(cond: bool, msg: str) -> None:
    if not cond:
        raise RuntimeError(msg)

def compile_cpp(src: pathlib.Path, out: pathlib.Path) -> None:
    # Platform-specific executables are not proof artifacts.  Always rebuild
    # the deterministic checker from the released C++ source before running it.
    cxx = os.environ.get('CXX', 'g++')
    print(f'compile {src.name}', flush=True)
    subprocess.run([cxx,'-O1','-std=c++17',str(src),'-o',str(out)], check=True)

def run_cmd(cmd, log_lines):
    print('run ' + ' '.join(map(str, cmd[1:])), flush=True)
    proc = subprocess.run(cmd, text=True, capture_output=True, check=False)
    text = proc.stdout + proc.stderr
    log_lines.append('$ ' + ' '.join(map(str,cmd)))
    log_lines.append(text.rstrip())
    if proc.returncode != 0:
        raise RuntimeError(f'command failed: {cmd}\n{text}')
    for line in text.splitlines():
        if line.startswith('result best=') or line.startswith('initial_infeasible'):
            print('  ' + line, flush=True)
    return text

def parse_best(text: str):
    if 'initial_infeasible' in text:
        return None
    m = re.search(r'result best=(-?\d+)', text)
    if not m:
        raise RuntimeError('no result best line in output:\n'+text)
    return int(m.group(1))

def validate_certificate_structure(cert):
    require(set(cert) >= {'pair_thresholds_sorted', 'triple_thresholds_sorted', 'critical_patterns'}, 'missing top-level threshold certificate fields')

    expected_pairs = {','.join(map(str, vals)) for vals in combinations_with_replacement(range(4), 2)}
    actual_pairs = set(cert['pair_thresholds_sorted'])
    require(actual_pairs == expected_pairs, f'pair threshold coverage mismatch: missing={sorted(expected_pairs-actual_pairs)} extra={sorted(actual_pairs-expected_pairs)}')

    expected_triples = {','.join(map(str, vals)) for vals in combinations_with_replacement(range(4), 3)}
    actual_triples = set(cert['triple_thresholds_sorted'])
    require(actual_triples == expected_triples, f'triple threshold coverage mismatch: missing={sorted(expected_triples-actual_triples)} extra={sorted(actual_triples-expected_triples)}')

    allowed_modes = {
        'exact',
        'lower_bound_for_m_le_66',
        'infeasible_or_lower_bound_for_m_le_66',
        'lower_bound_for_m_le_63',
        'infeasible_or_lower_bound_for_m_le_63',
        'conservative_lower_bound_sufficient_for_arithmetic',
    }
    for kind, entries in [('pair', cert['pair_thresholds_sorted']), ('triple', cert['triple_thresholds_sorted'])]:
        for key, rec in entries.items():
            vals = tuple(map(int, key.split(',')))
            require(tuple(sorted(vals)) == vals, f'{kind} key is not sorted orbit key: {key}')
            require(rec.get('mode') in allowed_modes, f'{kind} {key}: invalid mode {rec.get("mode")}')
            threshold = int(rec['threshold'])
            target = int(rec['target'])
            require(threshold > 0 and target > 0, f'{kind} {key}: threshold/target must be positive')
            if rec['mode'] == 'exact':
                require(target == threshold + 1, f'{kind} {key}: exact mode should test target threshold+1')
            else:
                require(target == threshold, f'{kind} {key}: lower-bound mode should test target=threshold')

    patterns = cert['critical_patterns']
    require(isinstance(patterns, list), 'critical_patterns must be a list')
    names = [rec.get('name') for rec in patterns]
    require(len(names) == len(set(names)), f'duplicate critical pattern names: {names}')
    expected_names = {
        'pair_square_min',
        'pair_square_forces_R01_for_m_le_66',
        'triple_slab0_min',
        'triple_slab0_forces_R03',
        'triple_slab1_min',
        'triple_slab1_forces_R13',
        'triple_slab2_min',
        'triple_slab2_forces_R23',
        'triple_mixed_excluded_for_m_le_66',
    }
    require(set(names) == expected_names, f'critical pattern coverage mismatch: missing={sorted(expected_names-set(names))} extra={sorted(set(names)-expected_names)}')
    allowed_patterns = {'pair_square', 'triple_slab0', 'triple_slab1', 'triple_slab2', 'triple_mixed'}
    for rec in patterns:
        args = rec.get('args', [])
        require('--pattern' in args and '--target' in args, f'{rec.get("name")}: missing --pattern/--target args')
        pat = args[args.index('--pattern') + 1]
        require(pat in allowed_patterns, f'{rec.get("name")}: invalid pattern {pat}')
        int(args[args.index('--target') + 1])
        require(rec.get('expect') in {'best=64', 'no_best_below_target', 'infeasible_or_no_best_below_target'}, f'{rec.get("name")}: invalid expectation {rec.get("expect")}')

def check_trace_thresholds(cert, log_lines):
    ok_count=0
    for kind, entries in [('pair', cert['pair_thresholds_sorted']), ('triple', cert['triple_thresholds_sorted'])]:
        for key, rec in entries.items():
            vals = key.split(',')
            target = int(rec['target'])
            text = run_cmd([str(TRACE_BIN), *vals, '--target', str(target), '--time', '300'], log_lines)
            best = parse_best(text)
            mode = rec['mode']
            threshold = int(rec['threshold'])
            if mode == 'exact':
                require(best == threshold, f'{kind} {key}: expected exact best {threshold}, got {best}\n{text}')
            else:
                # Any best equal to the target, or initial infeasibility, proves there is no solution below target.
                # If the branch-and-bound unexpectedly finds a smaller solution, the certified threshold is false.
                require(best is None or best >= target, f'{kind} {key}: found best below target {target}: {best}\n{text}')
                require(target == threshold, f'{kind} {key}: lower-bound target/threshold mismatch')
            ok_count += 1
    return ok_count

def check_patterns(cert, log_lines):
    ok=0
    for rec in cert['critical_patterns']:
        args = [str(PATTERN_BIN), *rec['args'], '--time', '300']
        text = run_cmd(args, log_lines)
        best = parse_best(text)
        exp = rec['expect']
        if exp == 'best=64':
            require(best == 64, f'{rec["name"]}: expected best=64, got {best}\n{text}')
        elif exp in ('no_best_below_target','infeasible_or_no_best_below_target'):
            target = int(rec['args'][rec['args'].index('--target')+1])
            require(best is None or best >= target, f'{rec["name"]}: found best below target {target}: {best}\n{text}')
        else:
            raise RuntimeError('unknown expectation '+exp)
        ok += 1
    return ok

def conservative_threshold_tables(cert):
    pair_sorted = {tuple(map(int,k.split(','))): int(v['threshold']) for k,v in cert['pair_thresholds_sorted'].items()}
    tri_sorted = {tuple(map(int,k.split(','))): int(v['threshold']) for k,v in cert['triple_thresholds_sorted'].items()}
    pair = {vals: pair_sorted[tuple(sorted(vals))] for vals in product(range(4), repeat=2)}
    tri = {vals: tri_sorted[tuple(sorted(vals))] for vals in product(range(4), repeat=3)}
    return pair, tri

def check_arithmetic_and_rectangle(cert):
    spec = importlib.util.spec_from_file_location('base_no_topstar', BASE_PY)
    base = importlib.util.module_from_spec(spec); require(spec.loader is not None, 'could not load support library'); spec.loader.exec_module(base)
    pair_thr, tri_thr = conservative_threshold_tables(cert)
    pairs = base.legal_pair_downsets()
    triples = base.legal_triple_downsets()
    rows=[]
    for m in range(33,64):
        allowed_p={p for p,t in pair_thr.items() if t<=m}
        pmax=max((len(S) for S in pairs if S <= allowed_p), default=0)
        allowed_t_mask=0
        for p,t in tri_thr.items():
            if t<=m: allowed_t_mask |= 1 << base.IDX3[p]
        tmax=max((size for size,mask,_ in triples if (mask & ~allowed_t_mask)==0), default=0)
        lhs=300*4*tmax + 144*6*pmax
        rhs=625*m
        require(lhs <= rhs, f'low-range arithmetic failure: {(m,pmax,tmax,lhs,rhs)}')
        rows.append((m,pmax,tmax,lhs,rhs))
    require(300*128+144*24 < 625*67, 'large-M Ferrers arithmetic failed')
    no_ext = 300*(4*31)+144*(6*3)
    require(no_ext <= 625*64, 'non-extremal M=64 arithmetic failed')
    cases = base.enumerate_rectangle_extensions()
    max_obj = -10**18; max_case=None
    for M in cases:
        Tsum,Psum,details = base.max_counts_for_M(M, pairs, triples)
        obj = 300*Tsum+144*Psum-625*len(M)
        if obj > max_obj:
            max_obj = obj; max_case = (len(M),Tsum,Psum,obj,details)
        require(obj <= 0, f'rectangle extension objective failure: {(len(M),Tsum,Psum,obj,details)}')
    require(len(cases) == 72, f'unexpected rectangle extension count: {len(cases)}')
    require(max_obj == -10624, f'unexpected rectangle max objective: {max_obj}')
    return rows, no_ext, len(cases), max_case

def main():
    cert = json.loads(CERT.read_text())
    validate_certificate_structure(cert)
    compile_cpp(TRACE_CPP, TRACE_BIN)
    compile_cpp(PATTERN_CPP, PATTERN_BIN)
    log_lines=[]
    ntrace = check_trace_thresholds(cert, log_lines)
    npat = check_patterns(cert, log_lines)
    rows, no_ext, ncases, max_case = check_arithmetic_and_rectangle(cert)
    out = []
    out.append('no_topstar_exact_threshold_certificate')
    out.append('black_box_milp_used=False')
    out.append(f'trace_threshold_checks={ntrace}')
    out.append(f'critical_pattern_checks={npat}')
    out.append('low_range_rows: m pmax_per_support tmax_per_support lhs rhs')
    for r in rows:
        out.append('  ' + ' '.join(map(str,r)))
    out.append(f'no_extremal_lhs_at_M64={no_ext} rhs={625*64}')
    out.append(f'rectangle_cases={ncases}')
    out.append(f'rectangle_max_case={max_case[:4]}')
    out.append('exact_no_topstar_threshold_certificate_ok=True')
    text='\n'.join(out)+'\n'
    (HERE/'verify_no_topstar_exact_threshold_certificate.log').write_text(text+'\n\nFULL COMMAND LOG\n'+'\n'.join(log_lines), encoding='utf-8')
    print(text)

if __name__ == '__main__':
    main()
