#!/usr/bin/env python3
"""Fast self-contained transcript/arithmetic verifier for the no-top-star certificate.

This default checker does not call numerical LP/MILP solvers and does not use absolute
paths.  It verifies the local threshold certificate data, the corrected low-range
arithmetic table, and the archived exact branch-and-bound transcript markers.

For a slower full rerun of the exact branch-and-bound threshold audit, execute
  ./run_all_checks.sh --full-no-topstar
from the bundle root.
"""
from __future__ import annotations
import json
import pathlib
import re

HERE = pathlib.Path(__file__).resolve().parent
CERT = HERE / "no_topstar_exact_threshold_certificate.json"
FULL_LOG = HERE / "verify_no_topstar_exact_threshold_certificate.log"
OUT_LOG = HERE / "verify_no_topstar_exact_threshold_certificate.out"
if not OUT_LOG.exists():
    OUT_LOG = FULL_LOG
FORCING_LOG = HERE / "exact_critical_forcing.log"

def require(cond: bool, msg: str) -> None:
    if not cond:
        raise RuntimeError(msg)

def load_text(path: pathlib.Path) -> str:
    require(path.exists(), f"missing file: {path.name}")
    return path.read_text(encoding="utf-8", errors="replace")

def parse_low_rows(out: str):
    rows = {}
    for line in out.splitlines():
        m = re.match(r"\s*(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*$", line)
        if m:
            mm, pmax, tmax, lhs, rhs = map(int, m.groups())
            if 33 <= mm <= 63:
                rows[mm] = (pmax, tmax, lhs, rhs)
    return rows

def check_json(cert):
    require("pair_thresholds_sorted" in cert, "missing pair_thresholds_sorted")
    require("triple_thresholds_sorted" in cert, "missing triple_thresholds_sorted")
    require("critical_patterns" in cert, "missing critical_patterns")
    expected_pairs = {f"{i},{j}" for i in range(4) for j in range(i, 4)}
    expected_triples = {f"{i},{j},{k}" for i in range(4) for j in range(i, 4) for k in range(j, 4)}
    require(set(cert["pair_thresholds_sorted"]) == expected_pairs, "pair threshold orbit coverage mismatch")
    require(set(cert["triple_thresholds_sorted"]) == expected_triples, "triple threshold orbit coverage mismatch")
    require(len(cert["critical_patterns"]) == 9, "unexpected critical pattern count")
    names = {x.get("name", "") for x in cert["critical_patterns"]}
    expected_names = {
        "pair_square_min",
        "pair_square_forces_R01_for_m_le_66",
        "triple_slab0_min",
        "triple_slab0_forces_R03",
        "triple_slab1_min",
        "triple_slab1_forces_R13",
        "triple_slab2_min",
        "triple_slab2_forces_R23",
        "triple_mixed_excluded_for_m_le_66",
    }
    require(names == expected_names, "critical pattern coverage mismatch")

def check_low_rows(rows):
    require(set(rows) == set(range(33,64)), f"low-range row set mismatch: {sorted(rows)}")
    expected = {
        33:(0,0,0,20625),
        34:(0,1,1200,21250),
        35:(0,1,1200,21875),
        36:(0,4,4800,22500),
        41:(0,4,4800,25625),
        42:(0,7,8400,26250),
        47:(0,7,8400,29375),
        48:(0,25,30000,30000),
        49:(0,25,30000,30625),
        50:(0,26,31200,31250),
        55:(0,26,31200,34375),
        56:(0,29,34800,35000),
        59:(0,29,34800,36875),
        60:(1,29,35664,37500),
        63:(1,29,35664,39375),
    }
    for m, exp in expected.items():
        require(rows[m] == exp, f"row mismatch m={m}: got {rows[m]}, expected {exp}")
    for m,(p,t,lhs,rhs) in rows.items():
        require(lhs == 300*4*t + 144*6*p, f"lhs arithmetic mismatch m={m}")
        require(rhs == 625*m, f"rhs arithmetic mismatch m={m}")
        require(lhs <= rhs, f"low-range inequality failure m={m}")
    require(300*128 + 144*24 < 625*67, "M>=67 Ferrers arithmetic failed")
    no_ext = 300*(4*31) + 144*(6*3)
    require(no_ext < 625*64, "non-extremal M=64 arithmetic failed")
    return no_ext

def check_transcripts(full: str, out: str, forcing: str):
    both = "\n".join([full, out, forcing])
    required = [
        "trace_threshold_checks=30",
        "critical_pattern_checks=9",
        "exact_no_topstar_threshold_certificate_ok=True",
        "black_box_milp_used=False",
        "rectangle_cases=72",
        "rectangle_max_case=(64, 96, 4, -10624)",
        "pair_square",
        "triple_slab0",
        "triple_slab1",
        "triple_slab2",
        "triple_mixed",
        "mixed_K66",
        "mixed_K79",
        "mixed_K80",
    ]
    for token in required:
        require(token in both, f"archived exact transcript missing token: {token}")

def main():
    cert = json.loads(load_text(CERT))
    out = load_text(OUT_LOG)
    full = load_text(FULL_LOG)
    forcing = load_text(FORCING_LOG)
    check_json(cert)
    rows = parse_low_rows(out)
    no_ext = check_low_rows(rows)
    check_transcripts(full, out, forcing)
    print("no_topstar_exact_threshold_fast")
    print("black_box_milp_used=False")
    print("pair_threshold_orbits=10")
    print("triple_threshold_orbits=20")
    print("low_range_rows_verified=31")
    print("corrected_support_table_verified=True")
    print(f"no_extremal_lhs_at_M64={no_ext} rhs={625*64}")
    print("archived_exact_branch_and_bound_transcript_verified=True")
    print("rectangle_cases=72")
    print("rectangle_max_case=(64, 96, 4, -10624)")
    print("exact_no_topstar_threshold_fast_ok=True")

if __name__ == "__main__":
    main()
