#!/usr/bin/env python3
"""Subprocess-isolated exact verifier for the no-top-star full residual certificate.

No numerical MILP/LP solver is used.  Each exact lower-bound check is run in a
fresh Python process to keep the branch-and-bound caches small and deterministic.
"""
from __future__ import annotations
import argparse, ast, importlib.util, json, pathlib, subprocess, sys
from itertools import product
from typing import Optional, Tuple, Dict, List
HERE=pathlib.Path(__file__).resolve().parent
BASE=HERE/'no_topstar_support_library.py'
CASE=HERE/'exact_no_topstar_case.py'
if not BASE.exists(): raise FileNotFoundError(BASE)
if not CASE.exists(): raise FileNotFoundError(CASE)
spec=importlib.util.spec_from_file_location('base_no_topstar', BASE)
def require(cond: bool, msg: str) -> None:
    if not cond:
        raise RuntimeError(msg)

base=importlib.util.module_from_spec(spec); require(spec.loader is not None, 'could not load support library'); spec.loader.exec_module(base)

def table(entries):
    return {tuple(e['vals']):(int(e['M']) if e.get('ok') else None) for e in entries}

def run_case(args: List[str]):
    proc=subprocess.run([sys.executable, str(CASE)] + args, text=True, capture_output=True, check=True)
    return json.loads(proc.stdout)

def check_orbit(tab: Dict[Tuple[int,...], Optional[int]], dim:int):
    for vals in product(range(4), repeat=dim):
        vals=tuple(vals); sv=tuple(sorted(vals))
        require(tab[vals]==tab[sv], f'orbit table mismatch: {(vals, sv, tab[vals], tab[sv])}')

def verify_trace_minima(cert):
    print('Exact subprocess trace-minimum audit', flush=True)
    for dim, name, tab in [(2,'pair',table(cert['pair_trace_minM'])), (3,'triple',table(cert['triple_trace_minM']))]:
        check_orbit(tab, dim)
        reps=sorted({tuple(sorted(v)) for v in product(range(4), repeat=dim)})
        for vals in reps:
            mu=tab[vals]
            vals_s=','.join(map(str,vals))
            if mu is None:
                res=run_case(['--kind','trace','--vals',vals_s,'--K','66'])
                print(f'  {name} {vals}: K=66 ok={res["ok"]} nodes={res["stats"].get("nodes")} reason={res["stats"].get("reason","")}', flush=True)
                require(not res['ok'], f'{name} {vals}: unexpectedly feasible below cutoff: {res}')
            else:
                res1=run_case(['--kind','trace','--vals',vals_s,'--K',str(mu-1)])
                res2=run_case(['--kind','trace','--vals',vals_s,'--K',str(mu)])
                print(f'  {name} {vals}: min={mu} below={res1["ok"]} at={res2["ok"]} nodes=({res1["stats"].get("nodes")},{res2["stats"].get("nodes")})', flush=True)
                require((not res1['ok']) and res2['ok'] and res2['size'] <= mu, f'{name} {vals}: trace-minimum mismatch {(mu, res1, res2)}')
    print('exact_trace_minima_ok=True', flush=True)

def expect(label,args,expected):
    res=run_case(args)
    print(f'  {label}: expected={expected} ok={res["ok"]} size={res["size"]} nodes={res["stats"].get("nodes")} reason={res["stats"].get("reason","")}', flush=True)
    require(res['ok']==expected, f'{label}: expected {expected}, got {res}')

def verify_critical():
    print('Exact subprocess critical-pattern audit', flush=True)
    expect('pair_square_min63',['--kind','pair_square','--K','63'],False)
    expect('pair_square_min64',['--kind','pair_square','--K','64'],True)
    expect('pair_square_not_rectangle_K66',['--kind','pair_square','--K','66','--forbid','2,2,0,0'],False)
    for ci, forbid in [(0,'2,0,0,2'),(1,'0,2,0,2'),(2,'0,0,2,2')]:
        expect(f'triple_slab_{ci}_min63',['--kind','slab','--slab-index',str(ci),'--K','63'],False)
        expect(f'triple_slab_{ci}_min64',['--kind','slab','--slab-index',str(ci),'--K','64'],True)
        expect(f'triple_slab_{ci}_not_rectangle_K66',['--kind','slab','--slab-index',str(ci),'--K','66','--forbid',forbid],False)
    expect('triple_mixed_K66',['--kind','mixed','--K','66'],False)
    expect('triple_mixed_K79',['--kind','mixed','--K','79'],False)
    expect('triple_mixed_K80',['--kind','mixed','--K','80'],True)
    print('exact_critical_pattern_audit_ok=True', flush=True)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--cert', default=str(HERE/'no_topstar_full_certificate.json'))
    args=ap.parse_args(); cert_path=pathlib.Path(args.cert)
    if not cert_path.exists(): cert_path=HERE/'no_topstar_full_certificate.json'
    cert=json.loads(cert_path.read_text())
    verify_trace_minima(cert)
    verify_critical()
    result=base.quick_verify(cert_path)
    print('arithmetic_and_rectangle_enumeration_ok=True', flush=True)
    print(f'pair_legal_downsets={result["pair_legal_downsets"]}', flush=True)
    print(f'triple_legal_downsets={result["triple_legal_downsets"]}', flush=True)
    print(f'rectangle_cases={result["rectangle_cases"]}', flush=True)
    print(f'rectangle_max_case_objective={result["rectangle_max_case"][3]}', flush=True)
    print('exact_full_no_topstar_certificate_ok=True', flush=True)
if __name__=='__main__': main()
