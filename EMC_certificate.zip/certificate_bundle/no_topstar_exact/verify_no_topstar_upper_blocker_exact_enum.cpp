#include <algorithm>
#include <array>
#include <chrono>
#include <cstring>
#include <cstdint>
#include <iostream>
#include <utility>
#include <vector>
using namespace std;
// Fast exact branch-and-bound checker for no-top-star upper blocker.
// It verifies a size-48 feasible witness and exhausts all down-sets C in {0,1,2}^4
// with |C|>=49, proving none satisfy the no-upper-3-matching constraints.
int h[3][3][3];
array<int,3> posn[27];
vector<pair<unsigned long long,unsigned long long>> matchMasks;
unsigned long long UNIT_LO=0, UNIT_HI=0;
long long leaves_ge49=0, tested=0, unit_pass=0;
int best=0;

inline int bitid(int a,int b,int c,int d){ return (((a*3+b)*3+c)*3+d); }
inline void setbit(unsigned long long &lo, unsigned long long &hi, int id){ if(id<64) lo |= 1ULL<<id; else hi |= 1ULL<<(id-64); }

inline void build_mask(unsigned long long &lo, unsigned long long &hi){
    lo=hi=0;
    for(int a=0;a<3;a++) for(int b=0;b<3;b++) for(int c=0;c<3;c++){
        int ht=h[a][b][c];
        for(int d=0; d<ht; ++d) setbit(lo,hi,bitid(a,b,c,d));
    }
}

inline bool contains_mask(unsigned long long lo,unsigned long long hi,unsigned long long mlo,unsigned long long mhi){
    return ((lo&mlo)==mlo) && ((hi&mhi)==mhi);
}

bool has_matching(unsigned long long lo,unsigned long long hi){
    for(auto &mm: matchMasks){ if(contains_mask(lo,hi,mm.first,mm.second)) return true; }
    return false;
}

bool validate_witness(){
    // A monotone witness of size 48 found by the exact search: h[a][b][c] = max(0, 3 - floor((a+b+c)/2)) would be too small;
    // use the following explicit height matrix.
    int w[3][3][3] = {
      {{3,3,2},{3,3,2},{2,2,0}},
      {{3,3,2},{3,3,2},{2,2,0}},
      {{2,2,0},{2,2,0},{0,0,0}}
    };
    int sz=0;
    for(int a=0;a<3;a++) for(int b=0;b<3;b++) for(int c=0;c<3;c++){ h[a][b][c]=w[a][b][c]; sz+=h[a][b][c]; }
    // Check monotone decreasing in coordinates.
    for(int a=0;a<3;a++) for(int b=0;b<3;b++) for(int c=0;c<3;c++){
        if(a>0 && h[a][b][c]>h[a-1][b][c]) return false;
        if(b>0 && h[a][b][c]>h[a][b-1][c]) return false;
        if(c>0 && h[a][b][c]>h[a][b][c-1]) return false;
    }
    unsigned long long lo,hi; build_mask(lo,hi);
    bool ok = (sz==48) && contains_mask(lo,hi,UNIT_LO,UNIT_HI) && !has_matching(lo,hi);
    if(ok) best=48;
    return ok;
}

// Greedy upper bound for the maximum additional size from cells pos..26, using current assigned h.
int rem_upper_bound(int pos){
    int tmp[3][3][3];
    memset(tmp,0,sizeof(tmp));
    // copy assigned prefix
    for(int i=0;i<pos;i++){ auto [a,b,c]=posn[i]; tmp[a][b][c]=h[a][b][c]; }
    int ub=0;
    for(int i=pos;i<27;i++){
        auto [a,b,c]=posn[i];
        int maxv=3;
        if(a>0) maxv=min(maxv,tmp[a-1][b][c]);
        if(b>0) maxv=min(maxv,tmp[a][b-1][c]);
        if(c>0) maxv=min(maxv,tmp[a][b][c-1]);
        tmp[a][b][c]=maxv;
        ub += maxv;
    }
    return ub;
}

void rec(int pos, int size){
    if(size + rem_upper_bound(pos) <= 48) return;
    if(pos==27){
        if(size<=48) return;
        leaves_ge49++;
        unsigned long long lo,hi; build_mask(lo,hi);
        if(!contains_mask(lo,hi,UNIT_LO,UNIT_HI)) return;
        unit_pass++;
        tested++;
        if(!has_matching(lo,hi)){
            cerr << "counterexample_size=" << size << "\n";
            for(int a=0;a<3;a++){ for(int b=0;b<3;b++){ for(int c=0;c<3;c++) cerr << h[a][b][c]; cerr << ' '; } cerr << '\n'; }
            exit(1);
        }
        return;
    }
    auto [a,b,c]=posn[pos];
    int maxv=3;
    if(a>0) maxv=min(maxv,h[a-1][b][c]);
    if(b>0) maxv=min(maxv,h[a][b-1][c]);
    if(c>0) maxv=min(maxv,h[a][b][c-1]);
    // Add forced unit-top constraints as lower bounds on heights.
    int minv=0;
    if((a==2 && b==0 && c==0) || (a==0 && b==2 && c==0) || (a==0 && b==0 && c==2)) minv=1;
    if(a==0 && b==0 && c==0) minv=3;
    for(int v=maxv; v>=minv; --v){
        h[a][b][c]=v;
        rec(pos+1, size+v);
    }
}

int main(){
    int id=0; for(int a=0;a<3;a++)for(int b=0;b<3;b++)for(int c=0;c<3;c++)posn[id++]={a,b,c};
    setbit(UNIT_LO,UNIT_HI,bitid(2,0,0,0));
    setbit(UNIT_LO,UNIT_HI,bitid(0,2,0,0));
    setbit(UNIT_LO,UNIT_HI,bitid(0,0,2,0));
    setbit(UNIT_LO,UNIT_HI,bitid(0,0,0,2));
    vector<array<int,3>> perms; array<int,3> base={0,1,2};
    do{perms.push_back(base);}while(next_permutation(base.begin(),base.end()));
    for(auto p0:perms)for(auto p1:perms)for(auto p2:perms){
        unsigned long long lo=0,hi=0;
        for(int t=0;t<3;t++) setbit(lo,hi,bitid(t,p0[t],p1[t],p2[t]));
        matchMasks.push_back({lo,hi});
    }
    auto st=chrono::steady_clock::now();
    if(!validate_witness()){
        cerr << "witness_failed\n"; return 1;
    }
    memset(h,0,sizeof(h));
    rec(0,0);
    auto en=chrono::steady_clock::now();
    cout << "witness_size=48\n";
    cout << "searched_downsets_with_size_at_least_49=" << leaves_ge49 << "\n";
    cout << "unit_top_candidates_tested=" << unit_pass << "\n";
    cout << "max_C=48\n";
    cout << "min_MU=33\n";
    cout << "exact_upper_blocker_branch_bound_ok=True\n";
    cerr << "time_sec=" << chrono::duration<double>(en-st).count() << "\n";
}
