#!/usr/bin/env python3
"""Exact enumeration checker for the pair Ferrers lemma.

For a fixed pair support, a present pair family is a down-set in [4]^2.  A bad
pair obstruction is a pair of points with distinct coordinates in both directions
such that in at least one direction the two used values do not contain both 0 and 1.
Such an obstruction would combine with a seed and the two remaining columns to give
five disjoint traces.  This script enumerates all Ferrers down-sets in [4]^2 and
verifies that every down-set avoiding this obstruction has size at most 4.
"""
from itertools import product, combinations

V = list(product(range(4), repeat=2))

def require(cond, msg):
    if not cond:
        raise RuntimeError(msg)

def is_bad_pair(a, b):
    if a[0] == b[0] or a[1] == b[1]:
        return False
    for j in range(2):
        if not ({0, 1} <= {a[j], b[j]}):
            return True
    return False

def downset_from_heights(h):
    return {(x, y) for x in range(4) for y in range(h[x])}

def generate_heights():
    out = []
    def rec(prefix, last):
        if len(prefix) == 4:
            out.append(tuple(prefix)); return
        for v in range(last, -1, -1):
            rec(prefix + [v], v)
    rec([], 4)
    return out

max_size = -1
legal = []
all_heights = generate_heights()
for h in all_heights:
    S = downset_from_heights(h)
    ok = True
    for a, b in combinations(S, 2):
        if is_bad_pair(a, b):
            ok = False; break
    if ok:
        legal.append((h, len(S)))
        max_size = max(max_size, len(S))
print('pair_ferrers_downsets_checked:', len(all_heights))
print('pair_ferrers_legal_downsets:', len(legal))
print('pair_ferrers_max_legal_size:', max_size)
print('pair_ferrers_equality_shapes:')
for h, size in legal:
    if size == max_size:
        print(h)
require(len(all_heights) == 70, f'unexpected number of pair Ferrers down-sets: {len(all_heights)}')
require(max_size == 4, f'unexpected pair Ferrers maximum legal size: {max_size}')
print('pair_ferrers_ok=True')
