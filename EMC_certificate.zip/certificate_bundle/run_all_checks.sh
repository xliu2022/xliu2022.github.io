#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
LOG_DIR="$ROOT/logs"
LOG="$LOG_DIR/run_all_checks.log"
SUMMARY="$LOG_DIR/verification_summary.txt"
FULL_NO_TOPSTAR=0
ONLY_FULL_NO_TOPSTAR=0

usage() {
  cat <<'EOF'
Usage:
  bash run_all_checks.sh
      Run the standard fast verification.

  bash run_all_checks.sh --full-no-topstar
      Run the fast verification and then rerun the exact no-top-star
      branch-and-bound searches from source.

  bash run_all_checks.sh --only-full-no-topstar
      Run only the exact no-top-star branch-and-bound rerun.
EOF
}

for arg in "$@"; do
  case "$arg" in
    --full-no-topstar|--publication) FULL_NO_TOPSTAR=1 ;;
    --only-full-no-topstar) ONLY_FULL_NO_TOPSTAR=1 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "unknown argument: $arg" >&2; usage >&2; exit 2 ;;
  esac
done

mkdir -p "$LOG_DIR"
: > "$LOG"

log() {
  printf '%s\n' "$*" | tee -a "$LOG"
}

run_step() {
  local label="$1"
  shift
  log ""
  log "$label"
  "$@" 2>&1 | tee -a "$LOG"
}

run_upper_blocker() {
  cd "$ROOT/no_topstar_exact"
  "${CXX:-g++}" -O2 -std=c++17 verify_no_topstar_upper_blocker_exact_enum.cpp -o verify_no_topstar_upper_blocker_exact_enum
  ./verify_no_topstar_upper_blocker_exact_enum
}

run_full_no_topstar() {
  python3 "$ROOT/no_topstar_exact/verify_no_topstar_exact_threshold_certificate.py"
}

write_summary() {
  local mode="$1"
  cat > "$SUMMARY" <<EOF
ALL CHECKS COMPLETED SUCCESSFULLY
Mode: $mode
Combined log: logs/run_all_checks.log
EOF

  if [ "$mode" = "full-no-topstar-only" ]; then
    cat >> "$SUMMARY" <<'EOF'
Expected markers:
- Full no-top-star rerun: exact_no_topstar_threshold_certificate_ok=True
EOF
  else
    cat >> "$SUMMARY" <<'EOF'
Expected markers:
- Pair Ferrers: pair_ferrers_ok=True
- Triple Ferrers: Maximum legal size: 32
- Top-star: all_ok=True
- 15-board: board15_labelled_residual_rebuild status ok
- 11-board: board11_semantic status ok
- No-top-star upper blocker: exact_upper_blocker_branch_bound_ok=True
- No-top-star threshold fast: exact_no_topstar_threshold_fast_ok=True
EOF
    if [ "$mode" = "full" ]; then
      cat >> "$SUMMARY" <<'EOF'
- Full no-top-star rerun: exact_no_topstar_threshold_certificate_ok=True
EOF
    fi
  fi
  cat "$SUMMARY" | tee -a "$LOG"
}

log "Certificate bundle verification"
if [ "$ONLY_FULL_NO_TOPSTAR" -eq 1 ]; then
  run_step '[1/1] full no-top-star exact branch-and-bound rerun' run_full_no_topstar
  write_summary "full-no-topstar-only"
  exit 0
fi

run_step '[1/7] pair Ferrers auxiliary exact enumeration' \
  python3 "$ROOT/pair_ferrers/verify_pair_ferrers.py"

run_step '[2/7] triple Ferrers exact enumeration' \
  python3 "$ROOT/triple_ferrers/verify_triple_ferrers.py"

run_step '[3/7] top-star common-denominator Farkas certificates' \
  bash "$ROOT/topstar/verify_topstar_all_ranges.sh"

run_step '[4/7] 15-board labelled residual/closure reconstruction and quotient arithmetic' \
  python3 "$ROOT/board15/rebuild_15board_certificate_from_definition.py"

run_step '[5/7] 11-board residual-cut semantic witnesses and arithmetic' \
  python3 "$ROOT/board11/rebuild_11board_residual_cuts.py"

run_step '[6/7] no-top-star upper blocker exact branch-and-bound' \
  run_upper_blocker

run_step '[7/7] no-top-star exact threshold certificate, fast arithmetic/transcript check' \
  python3 "$ROOT/no_topstar_exact/verify_no_topstar_exact_threshold_fast.py"

if [ "$FULL_NO_TOPSTAR" -eq 1 ]; then
  run_step '[8/8] full no-top-star exact branch-and-bound rerun' run_full_no_topstar
  write_summary "full"
else
  write_summary "fast"
fi
