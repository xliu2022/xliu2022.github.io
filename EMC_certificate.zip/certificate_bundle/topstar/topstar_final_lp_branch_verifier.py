#!/usr/bin/env python3
"""Self-contained top-star branch LP builder for exact Farkas certificate checks.

This module reconstructs the linear relaxation used for the top-star leading-layer
certificate. It is intentionally deterministic: row order and row type labels match
those in topstar_common_den_farkas_certificates_complete.json.
"""
from itertools import product, combinations
from functools import lru_cache
import numpy as np
from scipy.sparse import lil_matrix, csr_matrix

V3 = list(product(range(4), repeat=3))
vidx = {x: i for i, x in enumerate(V3)}
Z = {x for x in V3 if 0 in x}
LOWER = [(x, t) for x in V3 for t in range(3)]
midx = {qt: i for i, qt in enumerate(LOWER)}
TSUPPS = list(combinations(range(4), 3))
PSUPPS = list(combinations(range(4), 2))
TRIPLES = [(tuple(s), v) for s in TSUPPS for v in product(range(4), repeat=3)]
PAIRS = [(tuple(s), v) for s in PSUPPS for v in product(range(4), repeat=2)]
tidx = {tv: i for i, tv in enumerate(TRIPLES)}
pidx = {pv: i for i, pv in enumerate(PAIRS)}

OFF_Y = 0
OFF_M = 64
OFF_T = OFF_M + len(LOWER)
OFF_P = OFF_T + len(TRIPLES)
NVAR = OFF_P + len(PAIRS)

target_var = np.zeros(NVAR, dtype=int)
target_var[OFF_Y:OFF_M] = 625
target_var[OFF_M:OFF_T] = -625
target_var[OFF_T:OFF_P] = 300
target_var[OFF_P:] = 144

def y_var(x): return OFF_Y + vidx[tuple(x)]
def m_var(x,t): return OFF_M + midx[(tuple(x), int(t))]
def t_var(supp, vals): return OFF_T + tidx[(tuple(supp), tuple(vals))]
def p_var(supp, vals): return OFF_P + pidx[(tuple(supp), tuple(vals))]
def trace_dict(supp, vals): return dict(zip(tuple(supp), tuple(vals)))

def is_bad_triple_matching(comb):
    for a in range(3):
        if len({v[a] for v in comb}) < 3:
            return False
    for a in range(3):
        unused = {0,1,2,3} - {v[a] for v in comb}
        if len(unused)==1 and next(iter(unused)) in (0,1):
            return True
    return False

@lru_cache(maxsize=None)
def diagonal_matchings_for_occ(key):
    occ = {j:set(key[j]) for j in range(4)}
    avail = [[v for v in range(4) if v not in occ.get(j,set())] for j in range(4)]
    if any(len(a)<3 for a in avail): return tuple()
    choices=[list(combinations(a,3)) for a in avail]
    out=[]
    for S0 in choices[0]:
      for S1 in choices[1]:
       for S2 in choices[2]:
        for S3 in choices[3]:
         S=[tuple(S0),tuple(S1),tuple(S2),tuple(S3)]
         for alpha in range(3):
          for beta in range(3):
           for gamma in range(3):
            out.append(tuple((S[0][t], S[1][(t+alpha)%3], S[2][(t+beta)%3], S[3][(t+gamma)%3]) for t in range(3)))
    return tuple(out)

def _make_matrix(rows):
    A=lil_matrix((len(rows), NVAR), dtype=np.int64)
    b=[]; names=[]
    for r,(typ, coeff, ub) in enumerate(rows):
        for j,val in coeff.items():
            if val:
                A[r,int(j)] = int(val)
        b.append(int(ub)); names.append(typ)
    return A.tocsr(), np.array(b, dtype=np.int64), names

def build_base(include_aggregates=True):
    rows=[]
    def add(typ, coeff, ub):
        coeff={int(k): int(v) for k,v in coeff.items() if v}
        if coeff:
            rows.append((typ, coeff, int(ub)))
        else:
            if 0 > ub:
                raise RuntimeError('constant infeasibility')

    # C subset Z.
    for x in V3:
        if x not in Z:
            add('C_subset_Z', {y_var(x):1}, 0)

    # C down-set.
    for x in V3:
        for j in range(3):
            if x[j] > 0:
                xx=list(x); xx[j]-=1
                add('C_down', {y_var(x):1, y_var(tuple(xx)):-1}, 0)

    # lower missing compatible with C.
    for x,t in LOWER:
        add('compat', {m_var(x,t):1, y_var(x):1}, 1)

    # lower missing up-set, including top-slice missing indicator 1-y_x.
    for x,t in LOWER:
        full=x+(t,); v1=m_var(x,t)
        for j in range(4):
            if full[j] < 3:
                q=list(full); q[j]+=1; q=tuple(q)
                if q[3] == 3:
                    add('low_to_top', {v1:1, y_var(q[:3]):1}, 1)
                else:
                    add('low_up', {v1:1, m_var(q[:3], q[3]):-1}, 0)

    # budget lowM <= c+2.
    budget={m_var(x,t):1 for x,t in LOWER}
    budget.update({y_var(x):-1 for x in V3})
    add('budget', budget, 2)

    # Trace down-set.
    for supp,vals in TRIPLES:
        v=t_var(supp, vals)
        for a in range(3):
            if vals[a] > 0:
                vv=list(vals); vv[a]-=1
                add('T_down', {v:1, t_var(supp, tuple(vv)):-1}, 0)
    for supp,vals in PAIRS:
        v=p_var(supp, vals)
        for a in range(2):
            if vals[a] > 0:
                vv=list(vals); vv[a]-=1
                add('P_down', {v:1, p_var(supp, tuple(vv)):-1}, 0)

    # Closure.
    for supp,vals in TRIPLES:
        d=trace_dict(supp, vals); rem=[j for j in range(4) if j not in d][0]
        v=t_var(supp, vals)
        for val in range(4):
            q=tuple(d[j] if j in d else val for j in range(4))
            if q[3] == 3:
                add('T_cl_top', {v:1, y_var(q[:3]):-1}, 0)
            else:
                add('T_cl_low', {v:1, m_var(q[:3], q[3]):1}, 1)
    for supp,vals in PAIRS:
        d=trace_dict(supp, vals); rem=[j for j in range(4) if j not in d]
        v=p_var(supp, vals)
        for a in range(4):
            for b in range(4):
                q=[None]*4
                for j in range(4): q[j]=d[j] if j in d else None
                q[rem[0]]=a; q[rem[1]]=b; q=tuple(q)
                if q[3] == 3:
                    add('P_cl_top', {v:1, y_var(q[:3]):-1}, 0)
                else:
                    add('P_cl_low', {v:1, m_var(q[:3], q[3]):1}, 1)

    # Pair Ferrers cuts.
    vals2=list(product(range(4), repeat=2))
    for supp in PSUPPS:
        for a,b in combinations(vals2,2):
            if a[0]!=b[0] and a[1]!=b[1]:
                if any((0 not in {a[i],b[i]} or 1 not in {a[i],b[i]}) for i in range(2)):
                    add('pair_cut', {p_var(supp,a):1, p_var(supp,b):1}, 1)

    # Bad triple matching cuts.
    vals3=list(product(range(4), repeat=3))
    bads=[comb for comb in combinations(vals3,3) if is_bad_triple_matching(comb)]
    for supp in TSUPPS:
        for comb in bads:
            add('bad3', {t_var(supp, comb[0]):1, t_var(supp, comb[1]):1, t_var(supp, comb[2]):1}, 2)

    # Diagonal residual seed cuts.
    def add_residual(trace_variable, d):
        for j in range(4):
            for u in (0,1):
                if d.get(j,None)==u: continue
                occ={col:{val} for col,val in d.items()}
                occ.setdefault(j,set()).add(u)
                key=tuple(tuple(sorted(occ.get(k,set()))) for k in range(4))
                for mat in diagonal_matchings_for_occ(key):
                    coeff={trace_variable:1}; top_count=0
                    for q in mat:
                        if q[3] == 3:
                            coeff[y_var(q[:3])] = coeff.get(y_var(q[:3]),0) + 1
                            top_count += 1
                        else:
                            coeff[m_var(q[:3], q[3])] = coeff.get(m_var(q[:3], q[3]),0) - 1
                    add('diag', coeff, top_count)
    for supp,vals in TRIPLES:
        add_residual(t_var(supp, vals), trace_dict(supp, vals))
    for supp,vals in PAIRS:
        add_residual(p_var(supp, vals), trace_dict(supp, vals))

    if include_aggregates:
        for supp in PSUPPS:
            add('P_agg', {p_var(supp, vals):1 for vals in product(range(4), repeat=2)}, 4)
        for supp in TSUPPS:
            add('T_agg', {t_var(supp, vals):1 for vals in product(range(4), repeat=3)}, 32)

    return _make_matrix(rows)

def _le(a,b): return all(ai<=bi for ai,bi in zip(a,b))

def branch_constraints(c, ell=None):
    rows=[]
    def add(typ, coeff, ub):
        coeff={int(k): int(v) for k,v in coeff.items() if v}
        if coeff:
            rows.append((typ, coeff, int(ub)))
    # fixed c: sum y <= c and >= c.
    add('fix_c_le', {y_var(x):1 for x in V3}, c)
    add('fix_c_ge', {y_var(x):-1 for x in V3}, -c)
    # top-slice ideal cardinality forcing in the deterministic set-iteration order used by the certificates.
    Zlist=list(Z)
    for x in Zlist:
        d=sum(1 for z in Z if _le(z,x))
        u=sum(1 for z in Z if _le(x,z))
        if d > c:
            add('top_forbid', {y_var(x):1}, 0)
        if c > len(Z)-u:
            add('top_force', {y_var(x):-1}, -1)
    if ell is not None:
        add('fix_l_le', {m_var(x,t):1 for x,t in LOWER}, ell)
        add('fix_l_ge', {m_var(x,t):-1 for x,t in LOWER}, -ell)
        L=[x+(t,) for x,t in LOWER]
        for q in L:
            U=sum(1 for z in L if _le(q,z))
            D=sum(1 for z in L if _le(z,q))
            if U > ell:
                add('low_forbid', {m_var(q[:3],q[3]):1}, 0)
            if ell > len(L)-D:
                add('low_force', {m_var(q[:3],q[3]):-1}, -1)
    return _make_matrix(rows)

if __name__=='__main__':
    A,b,n=build_base(True)
    print(A.shape, len(n), n[:5], n[-10:])
