#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
python3 "$HERE/verify_topstar_common_den_certificates_fast.py" --start 0 --end 23
python3 "$HERE/verify_topstar_common_den_certificates_fast.py" --start 23 --end 49
python3 "$HERE/verify_topstar_common_den_certificates_fast.py" --start 49
