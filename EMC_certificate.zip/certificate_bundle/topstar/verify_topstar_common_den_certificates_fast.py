#!/usr/bin/env python3
import json, sys, argparse
import numpy as np
from scipy.sparse import vstack
import pathlib
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import topstar_final_lp_branch_verifier as v
CERT=str(HERE/'topstar_common_den_farkas_certificates_complete.json')
BASE_A, BASE_B, BASE_NAMES = v.build_base(True)
BASE_N = BASE_A.shape[0]
ROW_CACHE = {}

def require(cond, msg):
    if not cond:
        raise RuntimeError(msg)

def exact_int(value, what):
    x = float(value)
    r = round(x)
    if abs(x - r) > 1e-9:
        raise RuntimeError(f"{what} is not integral after reconstruction: {value!r}")
    return int(r)

def row_entries_from(A, i, key):
    ck=(key,int(i))
    if ck in ROW_CACHE: return ROW_CACHE[ck]
    row=A.getrow(int(i))
    ent=[]
    for j,val in zip(row.indices,row.data):
        if abs(float(val)) <= 1e-12:
            continue
        ent.append((int(j), exact_int(val, f'row {i} coefficient {j}')))
    ROW_CACHE[ck]=ent
    return ent

def branch_data(c,ell):
    A2,b2,n2=v.branch_constraints(c,ell)
    if A2.shape[0]:
        A=vstack([BASE_A,A2]).tocsr(); b=np.concatenate([BASE_B,b2]); names=list(BASE_NAMES)+list(n2)
    else:
        A=BASE_A; b=BASE_B; names=list(BASE_NAMES)
    return A,b,names

def expected_branches():
    out={f"c{i}" for i in range(38) if i != 23}
    out.update({f"c23_ell{i}" for i in range(26)})
    return out

def expected_branch_name(c, ell):
    return f"c23_ell{ell}" if c == 23 else f"c{c}"

def load_records():
    with open(CERT, encoding='utf-8') as f:
        records=json.load(f)
    require(isinstance(records, list), 'certificate root must be a list')
    actual=[rec.get('branch') for rec in records]
    require(len(actual) == len(set(actual)), f'duplicate branch records: {actual}')
    expected=expected_branches()
    require(set(actual) == expected, f'branch coverage mismatch: missing={sorted(expected-set(actual))} extra={sorted(set(actual)-expected)}')
    return records

def validate_record_metadata(rec, A, b, names):
    branch=rec.get('branch')
    require(branch == expected_branch_name(int(rec['c']), rec.get('ell')), f"{branch}: branch name does not match c/ell")
    D=int(rec['denominator'])
    require(D > 0, f"{branch}: denominator must be positive")
    require(A.shape[0] == len(b) == len(names), f"{branch}: relaxation row metadata mismatch")

    rows=rec.get('row_multipliers_common_den', [])
    uppers=rec.get('upper_multipliers_common_den', [])
    repairs=rec.get('repair_upper_multipliers_common_den', [])
    require(isinstance(rows, list), f"{branch}: row multipliers must be a list")
    require(isinstance(uppers, list), f"{branch}: upper multipliers must be a list")
    require(isinstance(repairs, list), f"{branch}: repair upper multipliers must be a list")
    if 'row_support_size' in rec:
        require(int(rec['row_support_size']) == len(rows), f"{branch}: row_support_size mismatch")
    if 'upper_support_size_after_repair' in rec:
        require(int(rec['upper_support_size_after_repair']) == len(uppers), f"{branch}: upper_support_size_after_repair mismatch")
    if 'repair_upper_count' in rec:
        require(int(rec['repair_upper_count']) == len(repairs), f"{branch}: repair_upper_count mismatch")

    for rm in rows:
        i=int(rm['row_index'])
        w=int(rm['numerator'])
        require(0 <= i < A.shape[0], f"{branch}: row index out of range: {i}")
        require(w >= 0, f"{branch}: negative row multiplier at row {i}")
        require(rm.get('type') == names[i], f"{branch}: row {i} type mismatch {rm.get('type')} vs {names[i]}")
        if 'rhs' in rm:
            require(int(rm['rhs']) == exact_int(b[i], f'{branch} row {i} rhs'), f"{branch}: row {i} rhs mismatch")
    for um in uppers:
        j=int(um['var_index'])
        w=int(um['numerator'])
        require(0 <= j < v.NVAR, f"{branch}: variable upper-bound index out of range: {j}")
        require(w >= 0, f"{branch}: negative upper-bound multiplier at variable {j}")
    for um in repairs:
        j=int(um['var_index'])
        w=int(um.get('added_numerator', um.get('numerator', 0)))
        require(0 <= j < v.NVAR, f"{branch}: repair upper-bound index out of range: {j}")
        require(w >= 0, f"{branch}: negative repair upper-bound multiplier at variable {j}")
    return D

def check_record(rec):
    # Keep memory bounded across the 63 branch checks.
    ROW_CACHE.clear()
    A,b,names=branch_data(rec['c'],rec['ell'])
    D=validate_record_metadata(rec,A,b,names)
    coeff=[0]*v.NVAR; rhs=0
    key=(rec['c'],rec['ell'])
    for rm in rec['row_multipliers_common_den']:
        i=int(rm['row_index']); w=int(rm['numerator'])
        rhs += w*exact_int(b[i], f"{rec['branch']} row {i} rhs")
        for j,aij in row_entries_from(A,i,key): coeff[j]+=w*aij
    for um in rec['upper_multipliers_common_den']:
        j=int(um['var_index']); w=int(um['numerator'])
        coeff[j]+=w; rhs+=w
    min_gap=min(coeff[j]-int(v.target_var[j])*D for j in range(v.NVAR))
    rhs_gap=40000*D-rhs
    return min_gap,rhs_gap

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--start',type=int,default=0); ap.add_argument('--end',type=int,default=None)
    args=ap.parse_args()
    records=load_records(); subset=records[args.start:args.end]
    bad=[]; min_gap=None; min_rhs=None
    for idx,rec in enumerate(subset,args.start):
        print('check',idx,rec['branch'],flush=True)
        g,r=check_record(rec)
        if g<0 or r<0: bad.append((rec['branch'],g,r))
        min_gap=g if min_gap is None else min(min_gap,g)
        min_rhs=r if min_rhs is None else min(min_rhs,r)
    out=f"range={args.start}:{args.end} count={len(subset)} all_ok={not bad} min_gap={min_gap} min_rhs_gap={min_rhs} min_rhs_gap_float={None if min_rhs is None else min_rhs/1_000_000:.9f}\n"
    if bad: out += 'bad='+repr(bad)+'\n'
    print(out)
    open(HERE/f'topstar_common_den_verify_range_{args.start}_{args.end or "end"}.txt','w').write(out)
if __name__=='__main__': main()
