#!/usr/bin/env python3
"""
Verification script for the corrected triple Ferrers lemma used in the 19-point board route.

Lemma checked:
Let T be a down-set in [4]^3 = {0,1,2,3}^3. Call a 3-matching bad if it consists
of three points with pairwise distinct coordinates in each direction and the unique
unused value in at least one coordinate is 0 or 1. If T contains no bad 3-matching,
then |T| <= 32.

The script enumerates all Ferrers down-sets in [4]^3 via 4x4 height matrices and checks
avoidance using the inclusion-minimal down-closures of all bad 3-matchings.
"""
from itertools import product, combinations, permutations
from collections import Counter

V = list(product(range(4), repeat=3))
idx = {p: i for i, p in enumerate(V)}

def require(cond, msg):
    if not cond:
        raise RuntimeError(msg)

def is_disjoint_matching(points):
    return all(len({p[j] for p in points}) == len(points) for j in range(3))

def is_bad_matching(points):
    if not is_disjoint_matching(points):
        return False
    for j in range(3):
        used = {p[j] for p in points}
        unused = ({0, 1, 2, 3} - used).pop()
        if unused in {0, 1}:
            return True
    return False

def closure_height(points):
    h = [[0] * 4 for _ in range(4)]
    for x, y, z in points:
        for i in range(x + 1):
            for j in range(y + 1):
                h[i][j] = max(h[i][j], z + 1)
    return tuple(tuple(row) for row in h)

def ht_leq(a, b):
    return all(a[i][j] <= b[i][j] for i in range(4) for j in range(4))

def mask_from_height(h):
    m = 0
    for x in range(4):
        for y in range(4):
            for z in range(h[x][y]):
                m |= 1 << idx[(x, y, z)]
    return m

def generate_heights():
    h = [[0] * 4 for _ in range(4)]
    out = []
    def rec(pos):
        if pos == 16:
            out.append(tuple(tuple(row) for row in h))
            return
        i, j = divmod(pos, 4)
        maxv = 4
        if i > 0:
            maxv = min(maxv, h[i - 1][j])
        if j > 0:
            maxv = min(maxv, h[i][j - 1])
        for val in range(maxv, -1, -1):
            h[i][j] = val
            rec(pos + 1)
    rec(0)
    return out

# all bad 3-matchings and their minimal down-closures
bad_matchings = [c for c in combinations(V, 3) if is_bad_matching(c)]
forb = sorted(set(closure_height(c) for c in bad_matchings))
minimal_forb = []
for h in forb:
    if not any(g != h and ht_leq(g, h) for g in forb):
        minimal_forb.append(h)
min_forb_masks = [mask_from_height(h) for h in minimal_forb]

max_size = -1
equality = []
legal_count = 0
size_dist = Counter()
all_heights = generate_heights()
for h in all_heights:
    m = mask_from_height(h)
    legal = not any((m & f) == f for f in min_forb_masks)
    if legal:
        legal_count += 1
        size = sum(map(sum, h))
        size_dist[size] += 1
        if size > max_size:
            max_size = size
            equality = [h]
        elif size == max_size:
            equality.append(h)

print("Ferrers down-sets checked:", len(all_heights))
print("Bad 3-matchings:", len(bad_matchings))
print("Minimal forbidden down-closures:", len(minimal_forb))
print("Legal down-sets:", legal_count)
print("Maximum legal size:", max_size)
print("Number of equality diagrams:", len(equality))
print("Equality height matrices:")
for h in equality:
    print(h)
require(len(all_heights) == 232848, f'unexpected number of triple Ferrers down-sets: {len(all_heights)}')
require(max_size == 32, f'unexpected triple Ferrers maximum legal size: {max_size}')
require(len(equality) == 4, f'unexpected number of triple Ferrers equality diagrams: {len(equality)}')
