#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo "[1/2] Explicit r=4 threshold"
python3 threshold/verify_r4_explicit_threshold.py

echo "[2/2] Publication-grade certificate bundle verification"
(
  cd certificate_bundle
  bash run_all_checks.sh --full-no-topstar
  cp logs/run_all_checks.log logs/run_all_checks_full_no_topstar.log
  cp logs/verification_summary.txt logs/verification_summary_full_no_topstar.txt
  bash run_all_checks.sh
  rm -f no_topstar_exact/exact_no_topstar_hitting_solver \
        no_topstar_exact/exact_no_topstar_pattern_solver \
        no_topstar_exact/verify_no_topstar_upper_blocker_exact_enum
)

echo "ALL PROOF CHECKS COMPLETED SUCCESSFULLY"
