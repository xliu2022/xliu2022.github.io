#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo "[1/6] Build manuscript"
pdflatex -interaction=nonstopmode emc4_mathematical_programming_submission.tex
bibtex emc4_mathematical_programming_submission
pdflatex -interaction=nonstopmode emc4_mathematical_programming_submission.tex
pdflatex -interaction=nonstopmode emc4_mathematical_programming_submission.tex

echo "[2/6] Explicit r=4 threshold"
python3 threshold/verify_r4_explicit_threshold.py

echo "[3/6] Certificate bundle full verification"
(
  cd certificate_bundle
  bash run_all_checks.sh --full-no-topstar
  cp logs/run_all_checks.log logs/run_all_checks_full_no_topstar.log
  cp logs/verification_summary.txt logs/verification_summary_full_no_topstar.txt
  bash run_all_checks.sh
  rm -f no_topstar_exact/exact_no_topstar_hitting_solver \
        no_topstar_exact/exact_no_topstar_pattern_solver \
        no_topstar_exact/verify_no_topstar_upper_blocker_exact_enum
)

echo "[4/6] Refresh archived log checksums"
(
  cd certificate_bundle
  tmp="$(mktemp)"
  awk '{print $2}' SHA256SUMS_LOGS.txt | sed 's#^\./##' | while read -r f; do
    if [ -f "$f" ]; then
      shasum -a 256 "./$f"
    fi
  done > "$tmp"
  mv "$tmp" SHA256SUMS_LOGS.txt
)

echo "[5/6] Verify certificate-bundle checksum manifests"
(
  cd certificate_bundle
  shasum -a 256 -c SHA256SUMS_RELEASE.txt
  shasum -a 256 -c SHA256SUMS_LOGS.txt
)

echo "[6/6] Refresh and verify top-level checksum manifests"
shasum -a 256 \
  README_SUBMISSION.md \
  README_REPRODUCIBILITY.md \
  Dockerfile \
  .dockerignore \
  environment.yml \
  requirements.txt \
  run_all_proof_checks.sh \
  run_all_submission_checks.sh \
  emc4_mathematical_programming_submission.tex \
  emc4_mathematical_programming_submission.pdf \
  matching.bib \
  threshold/verify_r4_explicit_threshold.py \
  certificate_bundle/README.md \
  certificate_bundle/requirements.txt \
  certificate_bundle/run_all_checks.sh \
  certificate_bundle/no_topstar_exact/verify_no_topstar_exact_threshold_fast.py \
  certificate_bundle/no_topstar_exact/verify_no_topstar_exact_threshold_certificate.py \
  certificate_bundle/SHA256SUMS_RELEASE.txt \
  certificate_bundle/SHA256SUMS_LOGS.txt \
  > SHA256SUMS_ALL.txt
cp SHA256SUMS_ALL.txt SHA256SUMS_SUBMISSION.txt
shasum -a 256 -c SHA256SUMS_ALL.txt
shasum -a 256 -c SHA256SUMS_SUBMISSION.txt

echo "ALL SUBMISSION CHECKS COMPLETED SUCCESSFULLY"
