#!/usr/bin/env python3
"""Exact checker for the explicit r=4 threshold used in the paper.

It verifies that for every s >= 3481,
    25*(n4(s)-4*s-3) <= 12*(s-3),
by proving b4(m(s),s) >= a4(s), where
    m(s)=floor((112*s+39)/25).
The proof is by residue classes modulo 25.  For each residue a, the
corresponding polynomial in u is shifted to the first valid representative
s_a and all coefficients of the shifted polynomial are checked nonnegative.

It also checks the symbolic algebra used in the printed proof: the
admissibility identity, the gap subtraction formula, the monotonicity in N of
the gap polynomial, the displayed lower-bound polynomial, and the weight
monotonicity and inequalities implied by q/(s-3) <= 12/25.
"""
from math import comb

try:
    import sympy as sp
except ImportError as exc:
    raise SystemExit("sympy is required for this exact polynomial checker") from exc

FIRST_VALID = {
    0:3025,  1:2401,  2:2977,  3:2353,  4:2929,
    5:3505,  6:2881,  7:3457,  8:2833,  9:3409,
    10:2785, 11:3361, 12:2737, 13:3313, 14:2689,
    15:3265, 16:2641, 17:3217, 18:2593, 19:3169,
    20:2545, 21:3121, 22:2497, 23:3073, 24:2449,
}

def require(condition, label):
    if not condition:
        raise AssertionError(label)

def C_poly(x, k):
    out = sp.Integer(1)
    for i in range(k):
        out *= x - i
    return sp.expand(out / sp.factorial(k))

def P_for_residue(a):
    u = sp.symbols('u', integer=True, nonnegative=True)
    s = a + 25*u
    if a == 0:
        # positive s in residue 0 have u>=1; the same formula works.
        pass
    m = 112*u + ((112*a + 39) // 25)
    P = C_poly(m,4) - C_poly(m-s,4) - C_poly(4*s+3,4)
    return sp.Poly(sp.expand(P), u)

def value_at_s(s):
    m = (112*s + 39)//25
    return comb(m,4) - comb(m-s,4) - comb(4*s+3,4)

def assert_identity(lhs, rhs, label):
    require(sp.simplify(lhs - rhs) == 0, label)

def assert_shifted_nonnegative(expr, var, lower, label):
    tail = sp.symbols(f"{var.name}_tail", integer=True, nonnegative=True)
    shifted = sp.together(sp.expand(expr.subs(var, lower + tail)))
    num, den = sp.fraction(shifted)
    require(den.subs(tail, 0) > 0, f"{label}: denominator at start")
    require(
        all(c >= 0 for c in sp.Poly(sp.expand(den), tail).all_coeffs()),
        f"{label}: denominator positivity",
    )
    require(all(c >= 0 for c in sp.Poly(sp.expand(num), tail).all_coeffs()), label)

def assert_shifted_nonnegative_2vars(expr, var1, lower1, var2, lower2, label):
    tail1 = sp.symbols(f"{var1.name}_tail", integer=True, nonnegative=True)
    tail2 = sp.symbols(f"{var2.name}_tail", integer=True, nonnegative=True)
    shifted = sp.together(sp.expand(expr.subs({var1: lower1 + tail1, var2: lower2 + tail2})))
    num, den = sp.fraction(shifted)
    require(den.subs({tail1: 0, tail2: 0}) > 0, f"{label}: denominator at start")
    require(
        all(c >= 0 for c in sp.Poly(sp.expand(den), tail1, tail2).coeffs()),
        f"{label}: denominator positivity",
    )
    require(
        all(c >= 0 for c in sp.Poly(sp.expand(num), tail1, tail2).coeffs()),
        label,
    )

# Tail verification by nonnegative shifted coefficients.
for a, s0 in FIRST_VALID.items():
    require(s0 % 25 == a, f"first representative residue {a}")
    u = sp.symbols('u', integer=True, nonnegative=True)
    v = sp.symbols('v', integer=True, nonnegative=True)
    P = P_for_residue(a).as_expr()
    u0 = (s0 - a)//25
    Q = sp.Poly(sp.expand(P.subs(u, u0 + v)), v)
    coeffs = Q.all_coeffs()
    if any(c < 0 for c in coeffs):
        raise AssertionError((a, s0, coeffs))
    require(value_at_s(s0) >= 0, (a, s0, value_at_s(s0)))

# Verify the advertised last failure.
last_failure = None
for s in range(4, 3481):
    if value_at_s(s) < 0:
        last_failure = s
require(last_failure == 3480, ("last_failure", last_failure))
require(value_at_s(3481) >= 0, "value_at_s(3481)")

# Symbolic checks from the printed proof.
s, N = sp.symbols('s N', integer=True, positive=True)

admissibility_lhs = (
    C_poly(4*s + 3, 4)
    - (C_poly(4*s + 4, 4) - C_poly(3*s + 4, 4))
)
admissibility_rhs = s*(s - 1)*(81*s**2 + 95*s + 26) / 24
assert_identity(admissibility_lhs, admissibility_rhs, "admissibility identity")
assert_shifted_nonnegative(admissibility_rhs, s, 2, "admissibility positivity")

Delta_s_N = C_poly(N, 4) - C_poly(N - s, 4) - C_poly(4*s + 3, 4)
Delta_s_minus_1_N_minus_2 = (
    C_poly(N - 2, 4)
    - C_poly(N - s - 1, 4)
    - C_poly(4*s - 1, 4)
)
gap_poly = (
    -N**3 - 3*N**2*s + 9*N**2 + 3*N*s**2 + 12*N*s - 26*N
    + 255*s**3 - 102*s**2 + 45*s + 18
)
assert_identity(
    6*(Delta_s_minus_1_N_minus_2 - Delta_s_N),
    gap_poly,
    "gap subtraction formula",
)

h, u = sp.symbols('h u', integer=True, nonnegative=True)
gap_first_difference = sp.expand(gap_poly.subs(N, N + 1) - gap_poly)
negative_gap_difference = sp.expand(
    (-gap_first_difference).subs(N, 4*s + 4 + h).subs(s, 1 + u)
)
require(
    all(c >= 0 for c in sp.Poly(negative_gap_difference, h, u).coeffs()),
    "gap polynomial decreasing for N >= 4s+4",
)

# Gap lower-bound polynomial from the paper.
gap_num = 1848647*s**3 + 18927*s**2 + 516094*s - 69594
gap_upper_N = sp.Rational(112, 25)*s + sp.Rational(39, 25)
assert_identity(
    gap_poly.subs(N, gap_upper_N),
    gap_num / 15625,
    "gap lower-bound polynomial",
)
require(gap_num.subs(s, 1) > 0, "gap lower-bound at s=1")
assert_shifted_nonnegative(gap_num, s, 1, "gap lower-bound positivity")

# Weight inequalities.  For s >= 3481 and 1 <= q <= A*(s-3), all relevant
# weight functions are increasing in q, so it is enough to check q=A*(s-3).
A = sp.Rational(12, 25)
q = sp.symbols('q', integer=True, positive=True)
weight_functions = [
    ("T3", q/(s - 3)),
    ("P2", q*(q - 1)/((s - 2)*(s - 3))),
    ("T2", 2*q/(s - 2)),
    ("P1", 3*q*(q - 1)/((s - 1)*(s - 2))),
    ("T1", 3*q/(s - 1)),
    ("P0", 6*q*(q - 1)/(s*(s - 1))),
]
for label, expr in weight_functions:
    assert_shifted_nonnegative_2vars(
        sp.expand(expr.subs(q, q + 1) - expr),
        s, 3481,
        q, 1,
        f"weight monotonicity {label}",
    )

q_max = A*(s - 3)
assert_shifted_nonnegative(q_max - 1, s, 3481, "q upper endpoint at least 1")
weight_bounds = [
    ("T3", sp.Rational(12, 25) - A),
    ("P2", sp.Rational(144, 625) - q_max*(q_max - 1)/((s - 2)*(s - 3))),
    ("T2", sp.Rational(24, 25) - 2*q_max/(s - 2)),
    ("P1", sp.Rational(432, 625) - 3*q_max*(q_max - 1)/((s - 1)*(s - 2))),
    ("T1", sp.Rational(36, 25) - 3*q_max/(s - 1)),
    ("P0", sp.Rational(864, 625) - 6*q_max*(q_max - 1)/(s*(s - 1))),
]
for label, expr in weight_bounds:
    assert_shifted_nonnegative(expr, s, 3481, f"weight bound {label}")

print("r4_explicit_threshold_ok=True")
print("r4_symbolic_checks_ok=True")
print("r4_threshold_S4=3481")
print("r4_global_s4=6961")
